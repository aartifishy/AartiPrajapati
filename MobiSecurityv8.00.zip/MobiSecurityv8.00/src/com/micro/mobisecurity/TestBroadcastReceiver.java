package com.micro.mobisecurity;



import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;

public class TestBroadcastReceiver extends BroadcastReceiver
{
	public String pname;
	
	  @SuppressWarnings("unused")
	public void onReceive(Context ctx, Intent intent) {
		  
		  System.out.println("......OnReceive.......");
		
		  
		  
		  String action = intent.getAction();
		  pname=intent.getDataString();
	
		  System.out.println("****Package name retrieved*****"+pname);
		 
		
	  
		
		  String TAG;
		
		  
		 
		  if (Intent.ACTION_PACKAGE_REMOVED.equals(action)&& pname.equals("package:com.micro.android.unlock"))
		  {
			  
			  System.out.println("..PACKAGE MATCHED TO REMOVE ..........");
			 
			 
			  
	 boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);

			  Intent startActivity = new Intent();
	       	     startActivity.setClass(ctx, BlockOnly.class);
	       	     startActivity.setAction(BlockOnly.class.getName());
	       	     startActivity.setFlags(
	       	     Intent.FLAG_ACTIVITY_NEW_TASK
	       	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	       	     ctx.startActivity(startActivity);  
			
		  
		
			
	  }
}
	  
}
	



