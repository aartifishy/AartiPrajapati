package com.micro.mobisecurity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class AfterDeactSMS extends Activity{
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	   
	    moveTaskToBack(true);
	    System.exit(0);
	   
	}
}
