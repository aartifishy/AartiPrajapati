
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 					AutoStart at every boot up
					when sms receive NO Activity black sceen
					Receiver can change frm Sending sms setnewrec12345
					
					29 Aug // setnewrec12345 Getlog12345 Wipe12345
							  Find12345 Block12345
					Edit For Bhavik		  
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

package com.micro.mobisecurity;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.telephony.gsm.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MicroScout extends Activity implements OnClickListener 

{
	Thread t;
	   
    ProgressDialog dialog;
	private final int NOTIFICATION_ID = 1010;
	ImageButton submitsmsButton,submitgprsButton;
	Button actkeyOkButton,actkeyCanButton,mobilenoOkButton,mobilenoCanButton;
    //EditText observer;
	EditText MobileNoEdit,ActivationKeyEdit;
    String actkeyStr="",response,licennceKey;
    Context context;
    private ProgressDialog prog = null;
    int actkeyInt,calactkeyInt;
    public String MobileNoString,ConfermPinString,fullString,observerNo,observerNostr="",MobileNoStr="";
	public int ed1int,ed2int;
	int date,month,year,finalDate,finalImei,producesActKey,flag;
    String imsi="",imei="",FullString="";
    File standardIMSI = new File("data/data/com.micro.mobisecurity/MicroIMSI");
    File startDateFile = new File("data/data/com.micro.mobisecurity/MicroStartDate");
	File endDateFile = new File("data/data/com.micro.mobisecurity/MicroEndDate");
    File PhoneInfoFile=new File("data/data/com.micro.mobisecurity/PhoneInfoFile");
    File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
	File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
	/*File UnPinFile=new File("data/data/com.micro.android.unlock/UnPIN");
	File SystemFile = new File("c:/program1/syspin");*/
	File sdFile = new File("/sdcard/sdpin");
	 File scoutRecFile=new File("data/data/com.micro.mobisecurity/ScoutRecFile");
	 File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
    //File MobileNoFile=new File("data/data/com.micro.mobisecurity/mobile");
	//AddBuddy add=new AddBuddy();
	//AddEditBuddies addedit=new AddEditBuddies();
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    
    
    {	
    	super.onCreate(savedInstanceState);
        System.out.println("******** app start ********");
        
        //triggerNotification();
    	
        
        
       
        
         if( ToggleAutoLockOnSIMchng.exists()   )
    	{
    	
    		System.out.println("********* if scout rec file exist *********");
    		
    		Intent intent = new Intent(Intent.ACTION_VIEW);
   			intent.setClassName(this, MDsuccess.class.getName());
   			startActivity(intent);
   		    System.out.println("System.exit(0);");
    		
    		
    	}
         
        else if ( PhoneInfoFile.exists() )
		{
			enterActKeyProcess();
        	//FetchIMEInIMSI();
        	//FileWrite(PhoneInfoFile,FullString);
        	//AfterSuccess();
		}
    	else
    	{	
    		
    	System.out.println("********* Else No scout rec file exist *********");	
    
    	
    	
    	
       
    	
      /*  requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                                WindowManager.LayoutParams.FLAG_FULLSCREEN);*/
    	//enterActKeyProcess();
    	FetchIMEInIMSI();
    	FileWrite(PhoneInfoFile,FullString);
    	enterActKeyProcess();
    	//AfterSuccess();
    	}
		
        
       
        
    }
    private void selectMode() {
		// TODO Auto-generated method stub
    	setContentView(R.layout.verifyviagprssms);
        System.out.println("inside retrieveFormField");
    
 
	    
	    //MobileNoEdit = (EditText)this.findViewById(R.id.regmobileno);
        
	    
	    submitsmsButton = (ImageButton)this.findViewById(R.id.viasms_button);
	    submitgprsButton = (ImageButton)this.findViewById(R.id.viagprs_button);
	    submitsmsButton.setOnClickListener(this);
	    submitgprsButton.setOnClickListener(this);
	}
	private void enterActKeyProcess() {
		// TODO Auto-generated method stub
		//System.out.println("############"+startDateFile.exists()+"###########");
		System.out.println ("Inside if");
		setContentView(R.layout.actkeyregistration);
		System.out.println ("Inside if11");
		actkeyOkButton = (Button)this.findViewById(R.id.ActOkButton);
		actkeyOkButton.setOnClickListener(this);
		//System.out.println ("Inside if22"+actOK);
    	//actOK.setOnClickListener(this);
    	System.out.println ("Inside if33");
    	actkeyCanButton = (Button)this.findViewById(R.id.ActCancelButton);
    	actkeyCanButton.setOnClickListener(this);
		System.out.println ("Inside if22");
    	//actCan.setOnClickListener(this);
    	System.out.println ("Inside if33");
	}
    public void onClick(View v)
    {
    	if (v == submitsmsButton)
    	{	
    	//click on verify via sms
    		 System.out.println("..Use click on create PIN");
			    
			   // MobileNoString = MobileNoEdit.getText().toString();
		       // System.out.println("@@@ SetPinString is "+MobileNoString);
		        
		       
    		
		    	/*	if ( (MobileNoString.length() < 8)  )
		    		{
		    			
		    			System.out.println("please enter all the details Correctly.");
		    			alertbox1("MicroScout","Please Enter Correct Number !");
		    		}
		    		else*/
		    		{
		    			System.out.println("user click on submit Button");
		    	    	System.out.println("user click on submit Button");
		    	        //File scoutRecFile=new File("data/data/com.Multipartsms.com/ScoutRecFile");
		
		    	    	//MobileNoString   = MobileNoEdit.getText().toString();
		    			
		    			//FileWrite(scoutRecFile,observerNostr+"?");
		    			
		    			//FileWrite(MobileNoFile,MobileNoString);
		    			
		    			//System.out.println("@@@@@@@OBserver is "+observerNostr+"?");
		    	    	
		    	    	FetchIMEInIMSI();
		    	    	
		    	    	//alertbox("MicroScout","Registration Successful!!");
		    	    	
		    	    	 try
			    		 {
			    			 //SendMultiPartSms("+919223187878","M2MLOGIN;"+imei.trim());
			    			   //SendMultiPartSms(srecipients1St,surName.trim()+ " has added you as recipient on MicroMCS. You will get alert message in case of his/her phone lost or stolen. More Visit www.micromcs.net" );
								//SendMultiPartSms(srecipients2Nd,surName.trim()+ " has added you as recipient on MicroMCS. You will get alert message in case of his/her phone lost or stolen. More Visit www.micromcs.net" );
			    			 // sendSMS("7666839049","8 LMIR2A "+pinNo.trim()+"."+imei.trim()+"_MODEL"+"."+imsi.trim()+"."+surName.trim()+"."+"PH"+"."+"+91"+srecipients1St.trim()+"."+"+91"+srecipients2Nd.trim()+"."+semailId.trim()+"."+cardNo.trim());
		    	    		 FileWrite(PhoneInfoFile,FullString);
			    		 }
			    		 catch(Exception e)
			    		 {
			    			 //alertbox("MicroMCS","Connection problem please try again..");
			    		 }
		    	    	
			    		 alertbox2("Mobi Security", "Registration request sent successfully.Shortly you will receive registration password via SMS & via E-mail.");
		    		}
    
    	}
    	else if (v == submitgprsButton)
    	{
    		//click on verify via gprs
    		System.out.println ("Inside if");
    		setContentView(R.layout.mobilenoregistration);
    		System.out.println ("Inside if11");
    		mobilenoOkButton = (Button)this.findViewById(R.id.MobNoOkButton);
    		mobilenoOkButton.setOnClickListener(this);
    		//System.out.println ("Inside if22"+actOK);
        	//actOK.setOnClickListener(this);
        	System.out.println ("Inside if33");
        	mobilenoCanButton = (Button)this.findViewById(R.id.MobNoCancelButton);
        	mobilenoCanButton.setOnClickListener(this);
    		System.out.println ("Inside if22");
        	//actCan.setOnClickListener(this);
        	System.out.println ("Inside if33");
    			/* */
        	
    	}
    	else if (v==actkeyOkButton)
		{
    		//click on password ok button
			System.out.println ("User had entered the activation key");
			ActivationKeyEdit = (EditText)this.findViewById(R.id.EditActKey);
			actkeyStr = ActivationKeyEdit.getText().toString();
			System.out.println ("User entered"+actkeyStr);
			 if ( actkeyStr.equals("")) {
					alertbox1("Mobi Security", "Please enter password!!");
				}
				else if(actkeyStr.length()>=10 || actkeyStr.length()<=3)
				{
					alertbox1("Mobi Security", "Please enter valid password!!");
				}
				else if (actkeyStr.length()>0)
			{
				actkeyInt = Integer.parseInt(actkeyStr);
				calactkeyInt = generateActivationKey();
				System.out.println ("Calculated ActKey is"+calactkeyInt);
				callIMEI();
				if(imsi=="" || imsi==null)
				{
					alertbox1("Mobi Security", "Please insert SIM after check password");
				}
				else
				{
					callIMEI();
					System.out.println ("@@@@@@@inside if condition");
		    		try
		    		{
		    			callIMEI();
		    			standardIMSI.createNewFile();
		    			PrintWriter out = new PrintWriter(standardIMSI);
		    			out.write(imsi);
		    			out.flush();
		    			out.close();
		    			System.out.println ("After writing imsi");
		    			//alertbox("Mobile Control System","Sucessfully Registread");
		    			
		    		}
		    		catch (IOException ioe)
		    		{
		    			
		    			ioe.printStackTrace();
		    		}
		    		try
		    		{
		    			startDateFile.createNewFile();
		    			GregorianCalendar startDay = new GregorianCalendar();
		    			int ey1 = startDay.get(Calendar.YEAR);
		    			int em1 = startDay.get(Calendar.MONTH)+1;
		    			int ed1 = startDay.get(Calendar.DAY_OF_MONTH);
		    			System.out.println (ed1+":"+em1+":"+ey1);
		    			ObjectOutputStream objectOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("data/data/com.micro.mobisecurity/MicroStartDate")));  

		    			objectOut.writeObject(startDay); // Write object
		    			
		    			objectOut.close(); // Close the output stream 
		    			System.out.println (startDay);
		    		    System.out.println ("After writing start date to file");
		    		      
		    		}
		    		catch (IOException ioe)
		    		{
		    			ioe.printStackTrace();  
		    		}
		    		
		    		try
		    		{
		    			endDateFile.createNewFile();
		    			GregorianCalendar endDay = new GregorianCalendar();
		    			endDay.roll(Calendar.YEAR,1);
		    			System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		    			int ey = endDay.get(Calendar.YEAR);
		    			int em = endDay.get(Calendar.MONTH)+1;
		    			int ed = endDay.get(Calendar.DAY_OF_MONTH);
		    			System.out.println (ed+":"+em+":"+ey);
		    			ObjectOutputStream objectOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("data/data/com.micro.mobisecurity/MicroEndDate")));

		    			objectOut.writeObject(endDay); // Write object
		    			
		    			objectOut.close(); // Close the output stream 
		    			System.out.println (endDay);
		    		    System.out.println ("After writing end date to file");
		    		    //Intent intent = new Intent(this,StandardService.class);
		            	//startService(intent);
		    		    FileWrite(PinFile,actkeyStr);
		    		    
		    		    FileWrite(sdFile,actkeyStr);
		    		    alertbox3("Mobi Security","Password created! Just one more step to make your mobile secure.");  
		    		   // setContentView(R.layout.standsucc);
		    		    //setContentView(R.layout.main);
		    		    //setContentView(R.layout.standsucc);
		    			//alertbox2("Mobi Secure","Dear "+surName+", MicroMCS lite Full Version is activated on your handset with receipients : "+srecipients1St+" and "+srecipients2Nd+". You may now Exit the Application as it works silently on background!");
		    			//alertbox2("MicroMCS", "Full Version Registration successful of MicroMCS with recipient numbers "+ srecipients1St+"&"+" "+srecipients2Nd +".Now your application works silently on background!");
		    		}
		    		catch (IOException ioe)
		    		{
		    			ioe.printStackTrace();
		    		}
				}
				
				/*else
		    	{
					//alertbox("Information","wrong activation key"+actKey);
		    		System.out.println ("You have entered wrong activation key");
		    		//alertbox("Information","You have entered wrong activation key, Please enter correct activation key");
		    		//setContentView(R.layout.ungetactivationkey);
		    		//Activation unsuccessful! Set your phone Date to Todays Date and enter correct activation key.
		    		alertbox1("Mobi Security", "Oops! This number doesn�t match with the registered mobile number.");
		    		//setContentView(R.layout.ungetactivationkey);
		    	}*/  
			}
				
			
		}
    	else if(v==actkeyCanButton)
		{  
			//click on password cancel button
    		selectMode();
			
		}
		else if(v==mobilenoCanButton)
		{  
			//
			selectMode();
			
		}
		
		else if(v==mobilenoOkButton)
    	{
			MobileNoEdit= (EditText)this.findViewById(R.id.EditMobileNo);	
			MobileNoStr = MobileNoEdit.getText().toString();
			System.out.println(MobileNoStr);
			 if ( MobileNoStr.equals("")) {
					alertbox1("Mobi Security", "Please enter mobile number!!");
				}
				else if(MobileNoStr.length()>=14 || MobileNoStr.length()<=8  )
				{
					alertbox1("Mobi Security", "Please enter valid mobile number!!");
				}
				else if(v==mobilenoOkButton)
		    	{
					MobileNoEdit= (EditText)this.findViewById(R.id.EditMobileNo);	
					MobileNoStr = MobileNoEdit.getText().toString();
					System.out.println(MobileNoStr);
					 if ( MobileNoStr.equals("")) {
							alertbox1("Mobi Security", "Please enter mobile number!!");
						}
						else if(MobileNoStr.length()>=14 || MobileNoStr.length()<=8  )
						{
							alertbox1("Mobi Security", "Please enter valid mobile number!!");
						}
						else if(MobileNoStr.startsWith("+"))
						{
							// new TheTask().execute();
					         showDialog(0);
		                    /* t=new Thread() {
		                           public void run() {*/
		                        	   ServerAuthtication();
		                          /* }
		                     };
		               t.start();*/
					            
		    	        }
						else
						{
							alertbox1("Mobi Security", "Please enter valid mobile number!!");
						}
		    	}
				else
				{
					alertbox1("Mobi Security", "Please enter valid mobile number!!");
				}
    	}
    }
    @Override
    protected Dialog onCreateDialog(int id) {
          switch (id) {
                case 0: {
                      dialog = new ProgressDialog(this);
                      dialog.setMessage("Authenticating...");
                      dialog.setIndeterminate(true);
                      dialog.setCancelable(true);
                      return dialog;
                }
          }
          return null;
    }
    private Handler handler = new Handler() {
          @Override
          public void handleMessage(Message msg) {
                String loginmsg=(String)msg.obj;
                if(loginmsg.equals("Success")) {
                      removeDialog(0);
                      AfterSuccess();
                      //finish();
                }
                else if(loginmsg.equals("FAIL"))
                {
                	 removeDialog(0);
 		    		alertbox1("Mobi Security","Oops! This number doesn�t match with the registered mobile number.");
                }
                
          }
    };
    public void ServerAuthtication()
    {
    	try
    	{    	
    		FetchIMEInIMSI();
    		//https://mylife.microlifeline.net/test/mobilepages/register.aspx?Name=sandy&password=123456&mobileno=&vericode=&Platform=Android&version=3.01&type=signin
    		//URL connectURL = new URL("http://www.microlifeline.net/Login.aspx?ID="+user+"&Password="+pass); 
    		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/activation.aspx?mobileno="+MobileNoStr+"&imei="+imei);    		
    		// connectURL is a URL object
    		System.out.println ("After heating url from firstHit()");
    		
    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
    		// allow inputs 
    		conn.setDoInput(true); 
    		
    		// allow outputs 
    		conn.setDoOutput(true);
    		
    		// don't use a cached copy 
    		conn.setUseCaches(false); 
    		
    		// use a post method 
    		conn.setRequestMethod("POST");
    		
    		// set post headers 
    		conn.setRequestProperty("Connection","Keep-Alive"); 
    		  		
    		// open data output stream 
    		OutputStream dos ; 
    		
    		dos=conn.getOutputStream();
    		
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 
	    		
	    		b.append( (char)ch);
	    		
	    	} 
	    	try
	    	{
	    	response=b.toString(); 
	    	System.out.println ("Response"+response);
	    	actkeyStr = response.substring(0,(response.indexOf(',')));
	    	System.out.println ("********************"+actkeyStr);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
	    	 if(response.contains("Success"))
		    	{
		    		 Message myMessage=new Message();
                  myMessage.obj="Success";
                  handler.sendMessage(myMessage);
		    		
		    		// addBuddies();
		    	}
		    	
		    	else if(response.contains("FAIL"))
		    	{
		    		Message myMessage=new Message();
                 myMessage.obj="FAIL";
                 handler.sendMessage(myMessage);
		    		
		    	}
		    	else
		    	{         
		    		System.out.println("inside gprs problem");
		    		alertbox1("Mobi Security","Check your GPRS connection");
		    	}
	    	}
	    	catch(Exception e)
	    	{
	    		 removeDialog(0);
	    		alertbox1("Mobi Security","Check your GPRS connection");
	    	}
	    	
	    	
    	} 
    	
    	catch (UnknownHostException uhe)
    	{
    		System.out.println("Inside catch");
    		 removeDialog(0);
    		alertbox1("Mobi Security","Check your GPRS connection");
    		System.out.println("after alert");
    	}
    	catch (MalformedURLException ex)
    	{ 
    		System.out.println("Inside catch MalformedURLException");
    		//alertbox("MobiBackup","Check your GPRS connection");
    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		System.out.println("Inside catch IOException");
    		//alertbox("MobiBackup","Check your GPRS connection");
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	} 
    }
 
    private void AfterSuccess() {
		// TODO Auto-generated method stub
    	 callIMEI();
    	 FileWrite(PhoneInfoFile,FullString);
			System.out.println ("@@@@@@@inside if condition");
 		try
 		{
 			callIMEI();
 			standardIMSI.createNewFile();
 			PrintWriter out = new PrintWriter(standardIMSI);
 			if(imsi != null)
 				out.write(imsi);
 			out.flush();
 			out.close();
 			System.out.println ("After writing imsi");
 			//alertbox("Mobile Control System","Sucessfully Registread");
 			
 		}
 		catch (IOException ioe)
 		{
 			
 			ioe.printStackTrace();
 		}
 		try
 		{
 			startDateFile.createNewFile();
 			GregorianCalendar startDay = new GregorianCalendar();
 			int ey1 = startDay.get(Calendar.YEAR);
 			int em1 = startDay.get(Calendar.MONTH)+1;
 			int ed1 = startDay.get(Calendar.DAY_OF_MONTH);
 			System.out.println (ed1+":"+em1+":"+ey1);
 			ObjectOutputStream objectOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("data/data/com.micro.mobisecurity/MicroStartDate")));  

 			objectOut.writeObject(startDay); // Write object
 			
 			objectOut.close(); // Close the output stream 
 			System.out.println (startDay);
 		    System.out.println ("After writing start date to file");
 		      
 		}
 		catch (IOException ioe)
 		{
 			ioe.printStackTrace();  
 		}
 		
 		try
 		{
 			endDateFile.createNewFile();
 			GregorianCalendar endDay = new GregorianCalendar();
 			endDay.roll(Calendar.YEAR,1);
 			System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
 			int ey = endDay.get(Calendar.YEAR);
 			int em = endDay.get(Calendar.MONTH)+1;
 			int ed = endDay.get(Calendar.DAY_OF_MONTH);
 			System.out.println (ed+":"+em+":"+ey);
 			ObjectOutputStream objectOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("data/data/com.micro.mobisecurity/MicroEndDate")));

 			objectOut.writeObject(endDay); // Write object
 			
 			objectOut.close(); // Close the output stream 
 			System.out.println (endDay);
 		    System.out.println ("After writing end date to file");
 		    //Intent intent = new Intent(this,StandardService.class);
         	//startService(intent);
 		   FileWrite(PinFile,actkeyStr);
		    
		    FileWrite(sdFile,actkeyStr);
 		  alertbox3("Mobi Security","Verification is completed! Just one more step to make your mobile secure. & Your system generated password is "+actkeyStr+". Dial the same password to make application visible");  
 		   // setContentView(R.layout.standsucc);
 		    //setContentView(R.layout.main);
 		    //setContentView(R.layout.standsucc);
 			//alertbox2("Mobi Secure","Dear "+surName+", MicroMCS lite Full Version is activated on your handset with receipients : "+srecipients1St+" and "+srecipients2Nd+". You may now Exit the Application as it works silently on background!");
 			//alertbox2("MicroMCS", "Full Version Registration successful of MicroMCS with recipient numbers "+ srecipients1St+"&"+" "+srecipients2Nd +".Now your application works silently on background!");
 		}
 		catch (IOException ioe)
 		{
 			ioe.printStackTrace();
 		}
	}
	public void FetchIMEInIMSI()
	{
		
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		imei = mTelephonyMgr.getDeviceId(); 
		imsi = mTelephonyMgr.getSubscriberId(); 
		
		FullString += imei;
		FullString += "?";
		FullString += imsi;
			
		
		
		
		System.out.println("IMEI Is "+imei);
		System.out.println("IMSI Is "+imsi);
		System.out.println("Full String is "+FullString);
		
		//moveTaskToBack(true);
	    
	    //finish();
	}
    
    public  void FileWrite(File aPath,String aBody)
	{
		try 
    	{
			 System.out.println("@@@@ Inside Try FileWrite @@@@");
			 
			 aPath.createNewFile();
			 PrintWriter out1 = new PrintWriter(aPath);
			 out1.write(aBody);  
			 System.out.println (aBody.trim());
			 out1.flush();
			 out1.close();
    	}
    	catch (IOException ioe)
		 {
    		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
    		ioe.printStackTrace();
		 }
		
	}
    
    public void CallLMTS()
    {
    	
    	Intent intent = new Intent(this,LMTS.class);
    	startActivity(intent);
    
    }
    
    protected void alertbox(String title, String mymessage)     
	{
    	new AlertDialog.Builder(this)   
		.setMessage(mymessage)   
		//.setTitle(title)   
		.setCancelable(true)   
		.setNeutralButton(android.R.string.ok,   
		new DialogInterface.OnClickListener() {   
		public void onClick(DialogInterface dialog, int whichButton)
		{
			/*moveTaskToBack(true);
		    
		    finish();*/
			
			CallListActivity();

		}   
		})   
		.show();   
	}
    
    protected void alertbox1(String title, String mymessage)     
	{
    	new AlertDialog.Builder(this)   
		.setMessage(mymessage)   
		//.setTitle(title)   
		.setCancelable(true)   
		.setNeutralButton(android.R.string.ok,   
		new DialogInterface.OnClickListener() {   
		public void onClick(DialogInterface dialog, int whichButton)
		{
			 
		}   
		})   
		.show();   
	}
    protected void alertbox2(String title, String mymessage) {
		new AlertDialog.Builder(this)
				.setMessage(mymessage)
				//.setTitle(title)
				.setCancelable(true)
				.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								enterActKeyProcess();
							}
						}).show();
	}
    protected void alertbox3(String title, String mymessage) {
		new AlertDialog.Builder(this)
				.setMessage(mymessage)
				//.setTitle(title)
				.setCancelable(true)
				.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								addBuddies();
							}

							
						}).show();
	}
    public void addBuddies() {
		// TODO Auto-generated method stub
    	Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setClassName(this, AddBuddiesPinRegTime.class.getName());
		startActivity(intent);
	}
    public void CallListActivity()
    {
    	
    	Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setClassName(this, listActivity.class.getName());
			startActivity(intent);
			//stoActivity(intent);
			finish();
    }
    
    private void triggerNotification()
    {
        CharSequence title = "Mobi Security";
        CharSequence message = "Your Security Is Our Concern.";
 
        NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification notification = new Notification(R.drawable.mobisecurityicon, "Mobi Security! ", System.currentTimeMillis());
 
        Intent notificationIntent = new Intent(this, MicroScout.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
 
        notification.setLatestEventInfo(MicroScout.this, title, message, pendingIntent);
        notificationManager.notify(NOTIFICATION_ID, notification);
        
      
    }
    public int generateActivationKey()
    {
    
    	Date today = new Date();  
    
    	date = today.getDate();
    	String date1 = Integer.toString(date);
    	System.out.println (date1.length());
    	if (date1.length()<= 1)
    	{
    		date1 = "0"+date1;
    		
    	}
    	else
    	{
    		date1 = date1;
    	}
    	
    	month = today.getMonth()+1;
    	String month1 = Integer.toString(month);
    	System.out.println (month1.length());
    	if (month1.length()<= 1)
    	{
    		month1 = "0"+month1;
    		
    	}
    	else
    	{
    		month1 = month1;
    	}
    	
    	year = today.getYear()+1900;
    	    	
    	System.out.println (date1+"/"+month1+"/"+year);  
    	String date2 = month1+date1;
    	System.out.println ("date2 is "+date2);
    	int date3 =Integer.parseInt(date2);
    	System.out.println ("Now date 2 is"+date3);
    	
    	finalDate = year+date3;
    	System.out.println ("Final date is "+finalDate);  
    	
    		
    		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
    	    
    	    String myIMEI = mTelephonyMgr.getDeviceId();
    	
	    	
	    	String imei1 = myIMEI.substring(0,5);
	    	
	    	String imei2 = myIMEI.substring(5,10);
	    	String imei3 = myIMEI.substring(10);
	    	System.out.println (imei1+":"+imei2+":"+imei3);
	    	int im1 = Integer.parseInt(imei1);
	    	int im2 = Integer.parseInt(imei2);
	    	int im3 = Integer.parseInt(imei3);  
	    	finalImei = im1+im2+im3;
	    	System.out.println ("!!!!!!!!!!"+finalImei);
	    	 
	    	producesActKey = finalImei-finalDate;
	    	System.out.println ("############"+producesActKey);
	    	   	
    	
    	return producesActKey;
    	
    } 
    public void callIMEI()
	{ 
    	try
    	{
	    	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		    imsi = mTelephonyMgr.getSubscriberId(); 
		    imei = mTelephonyMgr.getDeviceId(); 
		    
		    System.out.println("i am in callimi method");
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
	}
    public void SendMultiPartSms(String add,String msgbdy)
	{
		
    	SmsManager smsManager = SmsManager.getDefault();
    	
        String destAddr = add, scAddr = null, mMessageText =msgbdy;
        
        System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
        
        PendingIntent sentIntent = null, deliveryIntent = null;
        
        try 
        {
        	
        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
        	
        	
        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

        
        	

        for (int i=0; i < messages.size(); i++)
        {

        	
        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        listOfIntents.add(pi);
        }
        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

        } catch (Exception e) 
        {
        Log.i("TEST", e.toString());
        }
    
	}	
}