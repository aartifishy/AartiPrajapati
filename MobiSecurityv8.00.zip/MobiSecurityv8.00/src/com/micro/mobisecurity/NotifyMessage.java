package com.micro.mobisecurity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class NotifyMessage extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		TextView txt=new TextView(this);
		
		txt.setText("Your operation is succesfull!");
		setContentView(txt);
	}
}
