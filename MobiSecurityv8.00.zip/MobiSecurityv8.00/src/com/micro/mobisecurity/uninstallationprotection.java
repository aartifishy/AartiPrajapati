package com.micro.mobisecurity;


import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.text.util.Linkify;
import android.widget.TextView;
public class uninstallationprotection extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.unprotection);
		setAppInfo();
	}
	 private void setAppInfo() {
         TextView txtInfo = (TextView)findViewById(R.id.app_info);
 
 txtInfo.setText(Html.fromHtml(getString(R.string.unprot_info)));
 
 Linkify.addLinks(txtInfo, Linkify.ALL);
 }
}
