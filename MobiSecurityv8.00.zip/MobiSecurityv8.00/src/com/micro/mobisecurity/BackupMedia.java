package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


@SuppressWarnings("unused")
public class BackupMedia extends  Activity implements OnClickListener, OnItemClickListener
{
	 String fileNamei,fileNames,fileNamev,base64String,imageStr;
	 String inputLine;
	 private List<String> item = null;
	 private List<String> path = null;
	 private String root="/";
	// private TextView myPath;
	 File myFile ; 
	 ImageButton backup,image,audio,video;
	 File encodedimageFile = new File("data/data/com.micro.mobisecurity/encodedimageFile.txt");
	 File encodedmp3File = new File("data/data/com.micro.mobisecurity/encodedmp3File.txt");
	 File encodedmp4File = new File("data/data/com.micro.mobisecurity/encodedmp4File.txt");  
	 PrintWriter out;
	 private int count=0;
	 private static final int NOTIFY_ME_ID=1337;
		Handler mHandler = new Handler();
	 
	 int t,readLimit,read,encodedImageChunks,encodedmp3Chunks,encodedmp4Chunks;
		File mf = new File("c:/program1/9.jpg");
	String imageName;
	/*private LayoutInflater mInflater;
	private Vector<Rowdata> data;
	Rowdata rd;
	*/
	
	//################ myVar Declarations #################
	
	//Images
	int cnt=0;
	private int counti;
	private Bitmap[] thumbnails;
	private boolean[] thumbnailsselection;
	private String[] arrPath;
	//private ImageAdapter imageAdapter;
	
	private List<String> imagelist = new ArrayList<String>();
	private List<String> images = new ArrayList<String>();
	private List<String> selimages = new ArrayList<String>();
	String imgarr[];
	String selimgarr[];
	private String[] myimages;
	 String imagepatharr,sngName;
	ListView lvimg;
	int ilen;
	String[] imgname,splittedimgarr;
	String[] imagepatharray;
	String imgpath,imei;
	String myi;
	int imlen=0;
	//Audio
	private List<String> songs = new ArrayList<String>();
	List<String> selsng= new ArrayList<String>();
	List<String> cursorsng= new ArrayList<String>();
	private String[] mysongs;
	private String[] ms;
	ListView lvsng;
	int slen;
	String[] sng;
	String[] arrsng;
	String[] myarrspath;
	
	ArrayList<String> sngpatharr=new ArrayList<String>();
	
	//Video
	private List<String> videos = new ArrayList<String>();
	List<String> selvdo= new ArrayList<String>();
	List<String> cursorvdo= new ArrayList<String>();
	private String[] myvideos;
	private String[] mv;
	ListView lvvdo;
	int vlen;
	String vdopatharr[];
	String vdopath, selvdopath,sngpath;
	String myv;
	
	
	Button sngbtn;
	
	
	Button imgbtn;
	Button vdobtn;
	/** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState)
   {
   	
   	System.out.println ("Inside onCreate method");
       super.onCreate(savedInstanceState);
       requestWindowFeature(Window.FEATURE_PROGRESS);
       setProgress(10000); // Turn it off for now
       try
       {
       	setContentView(R.layout.backuporrestoreimages);
       }
       catch (Exception ioe)
       {
       	ioe.printStackTrace();
       }
       //myPath = (TextView)findViewById(R.id.path);
       //getDir(root);
       calCulateIMEI();
       selectButton();
       //setContentView(R.layout.mediastoreonserver);
       
   }
   private void calCulateIMEI() {
		// TODO Auto-generated method stub
   	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	}
   public void onSaveInstanceState(Bundle savedInstanceState)
   {
   	super.onSaveInstanceState(savedInstanceState);
   }
   
   public void onRestoreInstanceState(Bundle savedInstanceState)
   {
   	  super.onRestoreInstanceState(savedInstanceState);
   }
   
   public void selectButton()
   {
   	 image = (ImageButton)findViewById(R.id.backupimage_button);
        audio = (ImageButton)findViewById(R.id.backupaudio_button);
        video = (ImageButton)findViewById(R.id.backupvideo_button);
        
        image.setOnClickListener(this);
        audio.setOnClickListener(this);
        video.setOnClickListener(this);
        
        
   }
   
   public void onClick(View v)
   {
   	if (v==image)
   	{
   		System.out.println ("User click on image ");
   		 try
   	        {
   	        	
   			 	 callImage();
   	           
   	        }
   	        catch (Exception ioe)
   	        {
   	        	ioe.printStackTrace();
   	        }
   	}
   	
   	else if (v==audio)
   	{
   		System.out.println ("User click on audio");
   		try
   		{
   			
   			 callAudio();
	            
	        }
	        catch (Exception ioe)
	        {
	        	ioe.printStackTrace();
	        }
   	}
   	
   	else if (v==video)
   	{
   		System.out.println ("User click on video");
   		try
   		{
   			
   			 callVideo();
	            
   		}
   		catch (Exception ioe)
	        {
	        	ioe.printStackTrace();
	        }
   	}
   	
   	else if(v==sngbtn)
   	{
   		
   		if(sngpath==null || sngpath=="")
  		{
  			alertbox("Mobi Security","Songs not available in your phone.");
  		}
  		else
  		{
  			getDirs(sngpath);
  		}
   		
   	}
   	
  	else if(v==imgbtn)
  	{
  
  		System.out.println("----------------again image path to pass:::::::::;;;"+imgpath);
  		//Toast.makeText(getBaseContext(), "you have selected "+myi+" image to upload", Toast.LENGTH_SHORT).show();
  		if(imgpath==null || imgpath=="")
  		{
  			alertbox("Mobi Security","Images not available in your phone.");
  		}
  		else
  		{
  		getDiri(imgpath);
  		}
  		
  	}
   	
  	else if(v == vdobtn)
  	{
  		//Toast.makeText(getBaseContext(), "you have selected "+myv+" video to upload", Toast.LENGTH_SHORT).show();
  		
  		if(vdopath==null ||vdopath=="")
  		{
  			alertbox("Mobi Security","Video's not available in your phone.");
  		}
  		else
  		{
  			getDirv(vdopath);
  		}
  	}
   }
   
   private void getDirv(String vdopath2) {
		// TODO Auto-generated method stub
   	String[] myvdo;
   	myvdo=vdopath2.split("/");
   	int l=0;
   	l=myvdo.length;
		selvdopath=myvdo[l-1];
		  File fv = new File(vdopath2);
		  fileNamev = fv.getPath();
		  sendmp4();
	}

	private void getDiri(String selimg) {
		// TODO Auto-generated method stub
   	System.out.println("---------------inside getDiri()-------");
	     //myPath.setText("Location: " + selsng2);
	     System.out.println("-------------- full img path string-"+selimg);
	     String sngpatharray[];
	    
	     myimages =selimg.split("/");
	     int l=0;
	     l=myimages.length;
	  //sngpatharr.add(selsng2);    
	     imagepatharr= myimages[l-1];
	  System.out.println("----------------"+imagepatharr);
	  System.out.println("---before sendmp3()---------");
	  File fi = new File(selimg);
	  System.out.println("----after song file creation------------");
	  System.out.println("----after song file creation------------");
	  fileNamei = fi.getPath();
	  System.out.println("---------after getting created files path---------");
	  System.out.println("---------after getting created files path---------");
	  sendImage();
	}

	private void callVideo() {
		// TODO Auto-generated method stub		
	
   	 System.gc();
        String[] vproj = {// MediaStore.Video.Media._ID,
       		 MediaStore.Video.Media.DATA,
       		// MediaStore.Video.Media.DISPLAY_NAME,
       		// MediaStore.Video.Media.SIZE 
       		 };
       Cursor vcursor = managedQuery(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
       		vproj, null, null, null);
		//List<String> songs = new ArrayList<String>();
		while(vcursor.moveToNext())
		{
			System.out.println("------------"+vcursor.getString(0));
			cursorvdo.add(vcursor.getString(0));
			mv=vcursor.getString(0).split("/");
			int mvlen=mv.length;
			videos.add(mv[mvlen-1] );
			
		}
		vlen= videos.size();
		
		System.out.println("---------------size of arraylist of videos----"+vlen);
		System.out.println("aaaaaa" +videos);
		
		
		myvideos=new String[vlen];
		vdopatharr=new String[cursorvdo.size()];
		for(int i=0; i<myvideos.length;i++)
		{
			System.out.println("------------inside for---------");
			myvideos[i]=videos.get(i);
		System.out.println("================"+myvideos[i]);
		vdopatharr[i]= cursorvdo.get(i);
		}
		
		setContentView(R.layout.vdomain);
		System.out.println("---------------ssssssssssssssssssss------------");
		
		lvvdo=(ListView) findViewById(R.id.ListView02);
		vdobtn=(Button)findViewById(R.id.btnvdoupload);
		System.out.println("-----------after set listview layout------------");

		lvvdo.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice, myvideos));
		System.out.println("--------------ddddddddddddddddddddddddd----------");
		lvvdo.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		System.out.println("------------------------aaaaaaaaaaaaaaa-------");
		lvvdo.setOnItemClickListener(this);
		vdobtn.setOnClickListener(this);
		System.out.println("-------------ddddddddddddrrrrrrrrrrrrrrrpppppppppp");
	//	System.out.println(""				-------------ddddddddddddrrrrrrrrrrrrrrrpppppppppp");
		System.out.println("-------------ddddddddddddrrrrrrrrrrrrrrrpppppppppp");
		/*lv.setOnItemClickListener(this);
		System.out.println("----------------------bbbbbbbbbbbbbbbbb-------");*/
	}

	private void callAudio() {
		// TODO Auto-generated method stub

		System.out.println("---------inside callAudio()-------");
		String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

		String[] sngprojection = {
		        //MediaStore.Audio.Media._ID,
		       // MediaStore.Audio.Media.ARTIST,
		       // MediaStore.Audio.Media.TITLE,
		        MediaStore.Audio.Media.DATA,
		        //MediaStore.Audio.Media.DISPLAY_NAME,
		       // MediaStore.Audio.Media.DURATION
		};

		final Cursor scursor = this.managedQuery(
		        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
		        sngprojection,
		        selection,
		        null,
		        null);

		while(scursor.moveToNext())
		{
			cursorsng.add(scursor.getString(0));
			//System.out.println("----------------sng with full path------"+cursorsng);
			//System.out.println("-------------"+scursor.getString(0));
			ms=scursor.getString(0).split("/");
			int mslen=ms.length;
			songs.add(ms[mslen-1] );
		
		}
		slen= songs.size(); 
		
		System.out.println("---------------size of arraylist of songs----"+slen);
		System.out.println("aaaaaa" +songs);
		System.out.println("=====###############--------");
			//System.out.println("------------songs on position 12"+songs.get(12));
		System.out.println("=====###############--------");
		
		mysongs=new String[slen];
		myarrspath=new String[slen];
		for(int i=0; i<mysongs.length;i++)
		{
			System.out.println("------------inside for---------");
			mysongs[i]=songs.get(i);
		System.out.println("================"+mysongs[i]);
		myarrspath[i]=cursorsng.get(i);
		System.out.println("******"+myarrspath[i]);
		System.out.println("=====$$$$$$$$$$$$$$$$$$$$$--------");
			
		}
		
		setContentView(R.layout.sngmain);
		System.out.println("---------------ssssssssssssssssssss------------");
		
		lvsng=(ListView) findViewById(R.id.ListView01);
		sngbtn=(Button) findViewById(R.id.btnsngupload);
		
		System.out.println("-----------after set listview layout------------");

		lvsng.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice, mysongs));
		System.out.println("--------------ddddddddddddddddddddddddd----------");
		lvsng.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		System.out.println("------------------------aaaaaaaaaaaaaaa-------");
		lvsng.setOnItemClickListener(this);
		System.out.println("-------------ddddddddddddrrrrrrrrrrrrrrrpppppppppp");
					
		sngbtn.setOnClickListener(this);
	
	}
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		
		
	try {
			if(arg0==lvsng)
			{
		System.out.println("----1234---------------");
			//String aaaa=(String) ((AdapterView<ListAdapter>) cursorsng).getItemAtPosition(arg2);
		selsng.add( myarrspath[arg2]);
		sngpath=myarrspath[arg2];
		sngName=mysongs[arg2];
		//selsng.add(mysongs[arg2]);
		System.out.println("---------------selected songs list with path-----"+sngpath+"-------------");
			}
			else if(arg0==lvvdo)
			{
				System.out.println("-----------7890--------------");
							//String s= cursorsng.get(arg2);
				//selvdo.add(s);
				vdopath=vdopatharr[arg2];
				myv=myvideos[arg2];
			}
			else if(arg0==lvimg)
			{
				System.out.println("-----------78901111--------------");
					//String s= cursorsng.get(arg2);
				//selvdo.add(s);
				imgpath=imagepatharray[arg2];
				System.out.println("--------------------image path to upload::::::::"+imgpath);
				 myi=imgarr[arg2];
			}
		} 
		catch(Exception e) 
		{
			Log.v(getString(R.string.app_name), e.getMessage());
		} 
	
	
	System.out.println("-------------------------"+selsng);
	System.out.println("-------------------------"+selvdo);
	}

	private void callImage()
	{
		// TODO Auto-generated method stub
			
       setContentView(R.layout.imgmain);
     /*  mInflater=(LayoutInflater)getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
       data= new Vector<Rowdata>();*/
		final String[] columns = { MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID };
		//final String orderBy = MediaStore.Images.Media._ID;
		
		Cursor imagecursor = managedQuery(
				MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, null,
				null, null);
		
		int image_column_index = imagecursor.getColumnIndex(MediaStore.Images.Media._ID);
		this.counti = imagecursor.getCount();
		this.thumbnails = new Bitmap[this.counti];
		this.arrPath = new String[this.counti];
		this.thumbnailsselection = new boolean[this.counti];
		
	
	while(imagecursor.moveToNext())
	{
		//String imgstr=imagecursor.getString(0);
		//System.out.println("--------image namewith full path:::::::::::"+imgstr);
		imagelist.add(imagecursor.getString(0));
		System.out.println("-image list:::::::::::::::###########"+imagelist);
		//cursorsng.add(scursor.getString(0));
		//System.out.println("----------------sng with full path------"+cursorsng);
		//System.out.println("-------------"+scursor.getString(0));
		//ms=scursor.getString(0).split("/");
		splittedimgarr=imagecursor.getString(0).split("/");
		//System.out.println("-----------------------splittedimgarr::::::::;"+splittedimgarr);
		int size=splittedimgarr.length;
		System.out.println("--------------------size::::::"+size);
		images.add(splittedimgarr[size-1]);
		System.out.println("--------------------images:::::::"+images);
		
		System.out.println("--------------after list images-------");
	
	}
	imlen=images.size();
	System.out.println("--------------imlen:::::;"+imlen);
	imgarr=new String[imlen];
	imagepatharray=new String[imlen];
	for(int i=0;i<imlen;i++)
	{		
		imgarr[i]=images.get(i);
		System.out.println("-----------------------image array:::::::::"+imgarr[i]);
		imagepatharray[i]=imagelist.get(i);
		System.out.println("------splitted image name:::::::::"+imagepatharray[i]);
	
	}
		
	
		lvimg=(ListView) findViewById(R.id.ListView03);
		lvimg.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, imgarr));
		lvimg.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		lvimg.setOnItemClickListener(this);
		imgbtn=(Button) findViewById(R.id.btnimgupload);
		imgbtn.setOnClickListener(this);
	}
	
	
	private void getDirs(String selsng2)
   {
		System.out.println("---------------inside getDir()-------");
	     //myPath.setText("Location: " + selsng2);
	     System.out.println("-------------- full sng path string-"+selsng2);
	     String sngpatharray[];
	     String sngpatharr;
	     sngpatharray= selsng2.split("/");
	     int l=0;
	     l=sngpatharray.length;
	  //sngpatharr.add(selsng2);    
	     sngpatharr= sngpatharray[l-1];
	  System.out.println("----------------"+sngpatharr);
	  System.out.println("---before sendmp3()---------");
	  File fs = new File(selsng2);
	  System.out.println("----after song file creation------------");
	  System.out.println("----after song file creation------------");
	  fileNames = fs.getPath();
	  System.out.println("---------after getting created files path---------");
	  System.out.println("---------after getting created files path---------");
	  sendmp3();
	  //####################################################
   }

	public void sendImage()
	{ 
		System.out.println ("Inside sendImage()");
		 Thread t = new Thread(){
			   public void run()
			   {
				   	encodeImage();
			 		encodedImageChunks = (int)encodedimageFile.length();
			 		encodedImageChunks = encodedImageChunks+1;
					
			 		System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			 		
			 		
			 		sendData(imei+"_P~"+imagepatharr+"~START~"+encodedImageChunks);
			 		System.out.println 
			 		(imei+"_P~"+imagepatharr+"~START~"+encodedImageChunks);
					
					readImageFile();			
					sendData(imei+"_P~"+imagepatharr+"~END~"+encodedImageChunks);
					System.out.println ("########################");
					System.out.println (imei+"_P~"+imagepatharr+"~END~"+encodedImageChunks);
					System.out.println ("Image uploaded successfully");
					//setContentView(R.layout.mediastoreonserver);
					encodedimageFile.delete();
					encodedmp3File.delete();
					encodedmp4File.delete();
					notifyMe();

					finish();
					 				   
				   }
				};
				
				t.start();
				try{
					setContentView(R.layout.mediatoserver);
						//setContentView(R.layout.mediafromserver);
				}catch (Exception e){e.printStackTrace();}
					//alertbox("Information","Image stored on server");
	}
	
	public String getImageName()
	{
		System.out.println ("##############################");
		System.out.println (fileNames);
		String[] arr = fileNames.split("/");
		System.out.println (arr.length);
		imageName = arr[arr.length-1];
		return imageName;
	}
	
	public void encodeImage()
	{
		try
		{
			encodedimageFile.createNewFile();
			out = new PrintWriter(encodedimageFile);
			myFile = new File(fileNamei);
			InputStream inputStream =  new FileInputStream (fileNamei);
			System.out.println ("##############"+fileNamei);
			
		
			
			byte[] b = new byte[1023];
			while((read= inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out.print(encoded);			
				out.flush();	
				System.out.println ("After flushing");
							
			}
			out.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
		
		//readFile();

	}
	
	 public void readImageFile()
    {    	
    	
    	 try
    	 {
        		   		 
     		 int chunkno=0;
    		 byte[] byteArray = new byte[102400];
    		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/encodedimageFile.txt"); 
    		 int bytesRead = 0;
    		 while((bytesRead = fstream.read(byteArray)) != -1)
    		 {  
    			 imageStr = new String(byteArray,0,bytesRead);  
    			 sendData(imei+"_P~"+imagepatharr+"~"+chunkno+"~"+imageStr);
    			 chunkno++;
    		 }

	                
         }
         catch (IOException ioe)
         {
        	 ioe.printStackTrace(); 
         }
        
         
         
    }
   
	 public void sendmp3()
	 {
		System.out.println ("Inside sendmp3()");
		 Thread t = new Thread(){
			   public void run()
			   {
				   	encodemp3();
			 		encodedmp3Chunks = (int)encodedmp3File.length();
			 		encodedmp3Chunks = encodedmp3Chunks+1;
					
			 		System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			 		
			 		
			 		//sendData(Login.licennceKey+"_M~"+imageName+"~START~"+encodedmp3Chunks);
			 		sendData(imei+"_M~"+sngName+"~START~"+encodedmp3Chunks);
			 		//System.out.println (Login.licennceKey+"_M~"+imageName+"~START~"+encodedmp3Chunks);
			 		System.out.println (imei+"_M~"+sngName+"~START~"+encodedmp3Chunks);
					readmp3File();			
					//sendData(Login.licennceKey+"_M~"+imageName+"~END~"+encodedmp3Chunks);
					sendData(imei+"_M~"+sngName+"~END~"+encodedmp3Chunks);
					System.out.println ("########################");
					System.out.println (imei+"_M~"+sngName+"~END~"+encodedmp3Chunks);
					System.out.println ("Music uploaded successfully");
					//setContentView(R.layout.mediastoreonserver);
					encodedimageFile.delete();
					encodedmp3File.delete();
					encodedmp4File.delete();
					notifyMe();
					finish();
					 				   
				   }
				};
				
				t.start();
				try{
					setContentView(R.layout.mediatoserver);
				}catch (Exception e){e.printStackTrace();}
					//alertbox("Information","Image stored on server");
	 }
	 
	public void encodemp3()
	{
		try
		{
			encodedmp3File.createNewFile();
			out = new PrintWriter(encodedmp3File);
			myFile = new File(fileNames);
			InputStream inputStream =  new FileInputStream (fileNames);
			System.out.println ("##############"+fileNames);
			
		
			
			byte[] b = new byte[1023];
			while((read= inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out.print(encoded);			
				out.flush();	
				System.out.println ("After flushing");
							
			}
			out.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
		
		//readFile();

	}
	
	public void readmp3File()
   {    	
   	
   	 try
   	 {
       		   		 
    		 int chunkno=0;
   		 byte[] byteArray = new byte[102400];
   		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/encodedmp3File.txt"); 
   		 int bytesRead = 0;
   		 while((bytesRead = fstream.read(byteArray)) != -1)
   		 {  
   			 imageStr = new String(byteArray,0,bytesRead);  
   			// sendData(Login.licennceKey+"_M~"+imageName+"~"+chunkno+"~"+imageStr);
   			 sendData(imei+"_M~"+sngName+"~"+chunkno+"~"+imageStr);
   			 chunkno++;
   		 }
	                
        }
        catch (IOException ioe)
        {
       	 ioe.printStackTrace(); 
        }
        
   }
	
	
	public void encodemp4()
	{
		try
		{
			encodedmp4File.createNewFile();
			out = new PrintWriter(encodedmp4File);
			myFile = new File(fileNamev);
			InputStream inputStream =  new FileInputStream (fileNamev);
			System.out.println ("##############"+fileNamev);
			
		
			
			byte[] b = new byte[1023];
			while((read= inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out.print(encoded);			
				out.flush();	
				System.out.println ("After flushing");
				
			}
			out.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
		
		//readFile();

	}
	
	public void readmp4File()
   {    	
   	
   	 try
   	 {
       		   		 
    		 int chunkno=0;
   		 byte[] byteArray = new byte[102400];
   		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/encodedmp4File.txt"); 
   		 int bytesRead = 0;
   		 while((bytesRead = fstream.read(byteArray)) != -1)
   		 {  
   			 imageStr = new String(byteArray,0,bytesRead);  
   			 sendData(imei+"_V~"+selvdopath+"~"+chunkno+"~"+imageStr);
   			 chunkno++;
   		 }
	                
        }
        catch (IOException ioe)
        {
       	 ioe.printStackTrace(); 
        }
        
   }
	
	
	public void sendmp4()
	{
		System.out.println ("Inside sendmp4");
		 Thread t = new Thread(){
			   public void run()
			   {
				   	encodemp4();
			 		encodedmp4Chunks = (int)encodedmp4File.length();
			 		encodedmp4Chunks = encodedmp4Chunks+1;
					
			 		System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			 		
			 		
			 		sendData(imei+"_V~"+selvdopath+"~START~"+encodedmp4Chunks);
			 		System.out.println (imei+"_V~"+selvdopath+"~START~"+encodedmp4Chunks);
					
					readmp4File();			
					sendData(imei+"_V~"+selvdopath+"~END~"+encodedmp4Chunks);
					System.out.println ("########################");
					System.out.println (imei+"_V~"+selvdopath+"~END~"+encodedmp4Chunks);
					System.out.println ("Music uploaded successfully");
					//setContentView(R.layout.mediastoreonserver);
					encodedimageFile.delete();
					encodedmp3File.delete();
					encodedmp4File.delete();
					notifyMe();
					finish();					 				   
				   }
				};
				t.start();
				try
				{
					setContentView(R.layout.mediatoserver);
				}
				catch 
				(
						
						Exception e){e.printStackTrace();
						
				}
					//alertbox("Information","Image stored on server");
	}
   
	
   public void sendData(String line)
   {
   	try
   	{
   		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/DumpData.aspx"); 
   		//URL connectURL = new URL("http://www.microlifeline.net/new/DumpData.aspx"); 
   		// connectURL is a URL object
   		System.out.println ("After heating url");
   		
   		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
   		// allow inputs 
   		conn.setDoInput(true); 
   		
   		// allow outputs 
   		conn.setDoOutput(true); 
   		
   		// don't use a cached copy 
   		conn.setUseCaches(false); 
   		
   		// use a post method 
   		conn.setRequestMethod("POST"); 
   		
   		// set post headers 
   		conn.setRequestProperty("Connection","Keep-Alive"); 
   		   		
   		// open data output stream 
   		OutputStream dos ; 
   		
   		dos=conn.getOutputStream();
   		
   		System.out.println ("Before if statement");
   		
   			byte[] arr = line.getBytes();
   		
   			System.out.println ("arr auccesfully created"+arr.length);
   	      	    
   			dos.write(arr);
   	    
   			System.out.println ("write to the page");
   		    	   	   		
   		System.out.println ("After if statement");
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 	    		
	    		b.append( (char)ch);
	    		
	    	} 
	    	String s=b.toString(); 
	    	System.out.println (s);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
	    	
   	} 
   	catch (MalformedURLException ex)
   	{ 
   		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
   	} 
   	catch (IOException ioe)
   	{ 
   		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
   	}

   }
   
   public void restoreImage()
   {
   	try
   	{
   	 	System.out.println ("Inside restoreImage");
   		    	
   	   	System.out.println ("Inside restoreImage method");
   	 	URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/masterlist.txt");
   	   	//URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/masterlist.txt"); 
           BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream()));
           
           System.out.println ("Before while");
           while ((inputLine = in.readLine()) != null) 
       
           {            	
       			System.out.println (inputLine);
       			
       			System.out.println ("***");
       			 TableLayout table = (TableLayout) findViewById(R.id.TableLayout01);
       			 
       		        // create a new TableRow
       		        TableRow row = new TableRow(this);
       		 
       		        // count the counter up by one
       		       
       		 
       		        // create a new TextView
       		        TextView t = new TextView(this);
       		        // set the text to "text xx"
       		        t.setText("text " + inputLine);
       		 
       		        // create a CheckBox
       		        Button b = new Button(this);
       		        b.setText("sangram");
       		 
       		        // add the TextView and the CheckBox to the new TableRow
       		        row.addView(t);
       		        row.addView(b);
       		 
       		        // add the TableRow to the TableLayout
       		        table.addView(row,new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
           } 
          
           	//out.flush();
   			//out.close();
           
           
           System.out.println ("At the end of try");
   	}
   	catch (Exception e)
   	{
   		e.printStackTrace();
   	}
   	
   	//setContentView(R.layout.backuporrestoreimages);
   	}
   
   protected void alertbox(String title, String mymessage)   
   {   
  	 new AlertDialog.Builder(this)   
      .setMessage(mymessage)   
      //.setTitle(title)   
      .setCancelable(true)   
      .setNeutralButton(android.R.string.ok,   
         new DialogInterface.OnClickListener() {   
         public void onClick(DialogInterface dialog, int whichButton){}   
         })   
      .show();   
   }
   
   private void notifyMe()
	{
   	//setContentView(R.layout.mediastoreonserver);
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your Media part are stored successfully", i);
	
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}

	
   	
	}
	    	 

