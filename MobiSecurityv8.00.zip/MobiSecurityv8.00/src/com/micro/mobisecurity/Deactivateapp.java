package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;

public class Deactivateapp extends Activity{
	 File ToggleBatteryOnOff=new File("data/data/com.micro.mobisecurity/BattInfo");
		File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
		File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
		File SettingFileNameField=new File("data/data/com.micro.mobisecurity/NameField");
		File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
		File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
		File BuddyListFile=new File("data/data/com.micro.mobisecurity/buddylist");
		 File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
		 File PhoneInfoFile=new File("data/data/com.micro.mobisecurity/PhoneInfoFile");
			File scoutRecFile=new File("data/data/com.micro.mobisecurity/ScoutRecFile");
			String strLine1;
			public String SenderId="",Ccnumber,fullString,ThirdPartyNo,observerNo,MsgBody;
			File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	   
	    //moveTaskToBack(true);
	  
	    ToggleBatteryOnOff.delete();
	    BuddyFile.delete();
	    PinFile.delete();
	    SettingFileNameField.delete();
	    ToggleSirenOnSIMchng.delete();
	    ToggleAutoLockOnSIMchng.delete();
	    BuddyListFile.delete();
	    appactFile.delete();
	    PhoneInfoFile.delete();
	    if(Cc.exists())
		{
        	ReadIncSmsFile();
		}
	}
	 public void ReadIncSmsFile()
	    {
			SenderId=SmsReceiver.IncommingNumber;
			
			try
			 {
				//File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
				 System.out.println("ReadIncSmsFile 1");
				 byte[] strL=new byte[102400];
				 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/IncommingSms");
				 int strLine=0;
				 	
				 while ((strLine =fstream.read(strL)) != -1)
				
				 {
					
					 System.out.println (strLine);
					 strLine1 =new String(strL,0,strLine);
					 
					 strLine1 += " ~Received From "+ SenderId;
					 
					 System.out.println("***** Rec complete ********"+strLine1);
					 
				 }
				 
				 readCcFile();
				 
				 SendMultiPartSms(Ccnumber,strLine1);

				
				 
				 // finish();
			  }
			  catch (IOException ioe)
			  {
				  ioe.printStackTrace(); 
			  }

	    }
		public void readCcFile() {
			try {
				FileInputStream fstream = new FileInputStream(
						"data/data/com.micro.mobisecurity/CarbonCopy");

				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in),8192);
				String strLine;
				while ((strLine = br.readLine()) != null) {

					Ccnumber = strLine.toString();
				}
				in.close();

				
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		public void SendMultiPartSms(String add,String msgbdy)
		{
			
	    	SmsManager smsManager = SmsManager.getDefault();
	    	
	        String destAddr = add, scAddr = null, mMessageText =msgbdy;
	        
	        System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
	        
	        PendingIntent sentIntent = null, deliveryIntent = null;
	        
	        try 
	        {
	        	
	        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
	        	
	        	
	        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

	        
	        	

	        for (int i=0; i < messages.size(); i++)
	        {

	        	
	        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
		        listOfIntents.add(pi);
	        }
	        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
	        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

	        } catch (Exception e) 
	        {
	        Log.i("TEST", e.toString());
	        }
	    
		}
}
