package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TwoLineListItem;

import com.micro.mobisecurity.R;
import com.micro.mobisecurity.Contact.RowData;

public class ContactListDemo extends ListActivity implements Runnable{
 
    private List<Contact1> contacts = null;
    private Contact1 con;
    private ContactArrayAdapter cAdapter;
    private ProgressDialog prog = null;
    private Context thisContext = this;
    private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	String name;
	//AddBuddiesPinRegTime ad=new AddBuddiesPinRegTime();
	String[]arr1;
	String recno,FullString,mobnumber,recnm,recName,recfullString,uname;
	static final int DIALOG_Rec = 1;
	private Dialog editorDialog = null;
	String phoneNumber;
	static final int CUSTOM_DIALOG_ID = 0;
	 public static String serverRec="";
	TextView customDialog_TextView;
	EditText customnoDialog_EditText, customnmDialog_EditText;
	Button customokDialog_Update,customcanDialog_Dismiss,customdelDialog_Dismiss;
	File BuddyListFile=new File("data/data/com.micro.mobisecurity/buddylist");
	File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       AddBuddyClick.mPref = getSharedPreferences(AddBuddyClick.PREFS, 0);
        prog = ProgressDialog.show(this, "Mobi Security", "Getting contacts from phonebook", true, false);
        Thread thread = new Thread(this);
        thread.start();
 
    }
 
    public void run() {
        if (contacts == null)
        {
            contacts = fillContactsList();
 
        }
        handler.sendEmptyMessage(0);
    }
 
    private List<Contact1> fillContactsList() {
        List<Contact1> tmpList = new ArrayList<Contact1>();
        Cursor c = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        while(c.moveToNext()){
            String ContactID = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
           name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String hasPhone =c.getString(
                    c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
            if(Integer.parseInt(hasPhone) == 1){
                Cursor phoneCursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID+"='"+ContactID+"'",
                        null, null);
                while(phoneCursor.moveToNext()){
                    String number = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    con = new Contact1();
                    con.setName(name);
                    con.setNumber(number);
                    tmpList.add(con);
                }
                phoneCursor.close();
            }
 
        }
        c.close();
        Collections.sort(tmpList);
        return tmpList;
    }
 
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            prog.dismiss();
            cAdapter = new ContactArrayAdapter(thisContext, R.layout.listitemlayout, contacts);
            getListView().setFastScrollEnabled(true);
            setListAdapter(cAdapter);
 
        }
    };
 
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        TextView label = ((TwoLineListItem) v).getText2();
        TextView label1 = ((TwoLineListItem) v).getText1();
        recno = label.getText().toString();
        System.out.println(recno);
        recName=label1.getText().toString();
        System.out.println(recName);
       
        //showDialog(CUSTOM_DIALOG_ID);
        //customnoDialog_EditText.setText(recno);
        //customnmDialog_EditText.setText(recName);
        //Toast.makeText(this, "Selected "+recName + phoneNumber, Toast.LENGTH_SHORT).show();
        //showDialog(DIALOG_Rec);
        //alertbox1("Add Buddy","Buddy Name ::"+recName+"\n\rMobile Number ::"+recno);
        alertboxAddBuddyInfo("Buddy Number Error","Buddy number selected has been modified to international standard format please correct the number if it's incorrect!");
    }
   
 
    public void writebuddies()
    {
    
    	try
    	{
    		AddBuddyClick.cnt = AddBuddyClick.mPref.getInt("numRun",0);
    		AddBuddyClick.cnt++;
    		AddBuddyClick.mPref.edit().putInt("numRun",AddBuddyClick.cnt).commit();
    		 //AddBuddyClick.cnt++;
    	      System.out.println("Counter::"+AddBuddyClick.cnt);
    		BuddyFile.createNewFile();
    	
		  FileWriter out1 = new FileWriter(BuddyFile,true);
		  serverRec+=recno+";";
		  
		 out1.write(";"+recno);  
		 System.out.println (";"+recno.trim());
		 out1.flush();
		 out1.close();
		 //System.out.println ("Name is?"+name);
		 System.out.println ("Number is?"+recno);
    	}
    	 catch (IOException ioe)
    	 {
    		 ioe.printStackTrace();
    	 }
    	 try
	    	{
	    		//cnt++;
	    		//ad.RegisterButton.setEnabled(true);
	    		BuddyListFile.createNewFile();
	    	
			  FileWriter out1 = new FileWriter(BuddyListFile,true);
			  
			 out1.write("?"+recName+" "+recno);  
			 
			 System.out.println ("?"+recno.trim()+" "+recName);
			 out1.flush();
			 out1.close();
			 //System.out.println ("Name is?"+name);
			 System.out.println ("Number is?"+recno);
	    	}
	    	 catch (IOException ioe)
	    	 {
	    		 ioe.printStackTrace();
	    	 } 
    	
    } 
    protected void alertboxFinish(String title, String mymessage)     
	{
    	new AlertDialog.Builder(this)   
		.setMessage(mymessage)   
		//.setTitle(title)   
		.setCancelable(true)   
		.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
		
		{   
		public void onClick(DialogInterface dialog, int whichButton)
			{
	    	
			}   
		}
		)   
		.show();   
	}
    protected void alertboxAddBuddyInfo(String title, String mymessage)     
	{
    	new AlertDialog.Builder(this)   
		.setMessage(mymessage)   
		//.setTitle(title)   
		.setCancelable(true)   
		.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
		
		{   
		public void onClick(DialogInterface dialog, int whichButton)
			{
			//showDialog(DIALOG_Rec);
			  showDialog(CUSTOM_DIALOG_ID);
			}   
		}
		)   
		.show();   
	}
    private void callContactList() {
		// TODO Auto-generated method stub
    	 Intent intent = new Intent(Intent.ACTION_VIEW);
  			intent.setClassName(this, ContactListDemo.class.getName());
  			startActivity(intent);
	}
    protected void alertboxAfterBuddyAdd(String title, String mymessage)     
	{
	// Code here to display alert box
       	// Create the alert box
              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
              //alertbox.setTitle(mymessage);
              // Set the message to display
              alertbox.setMessage(mymessage);

              // Add a neutral button to the alert box and assign a click listener
              alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
              {

                  // Click listener on the neutral button of alert box
                  public void onClick(DialogInterface arg0, int arg1) 
                  {
                	// The neutral button was clicked
                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
                	 // Lock();
                	  //moveTaskToBack(true);
                	  try
                	  {
                		  readNameFile();
                		  SendMultiPartSms(recno,uname+ " has added you as recipient on Mobi Security. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.mobisecurity.net" );
                		  alertboxAfterBuddySucc("Mobi Security","Buddy added successfully!Do you want to another buddy?");
                		  //alertboxAfterBuddySucc("Buddy Number Error","Buddy number selected has been modified to international standard format please correct the number if it's incorrect!");
                		  //finish();
                		  //ReadScoutRecFile();
                	  }
                	  catch(Exception e)
                	  {
                		  System.out.println("send sms "+e);
                	  }
                  }
              }
              
              
              
              );
              
              // Set a negative/no button and create a listener

              alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

                  // Click listener

                  public void onClick(DialogInterface arg0, int arg1) 
                  {

                      //Toast.makeText(getApplicationContext(), "'You Press No button.", Toast.LENGTH_SHORT).show();
                      alertboxAfterBuddySucc("Mobi Security","Do you want to add another buddy");
                     
      	   			//callContactList();
                  }

				

              }
              
              );
               // show the alert box
              alertbox.show();  
	}	 
    protected void alertboxAfterBuddySucc(String title, String mymessage)     
	{
	// Code here to display alert box
       	// Create the alert box
              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
              //alertbox.setTitle(mymessage);
              // Set the message to display
              alertbox.setMessage(mymessage);

              // Add a neutral button to the alert box and assign a click listener
              alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
              {

                  // Click listener on the neutral button of alert box
                  public void onClick(DialogInterface arg0, int arg1) 
                  {
                	// The neutral button was clicked
                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
                	 // Lock();
                	  //moveTaskToBack(true);
                	  try
                	  {
                		  /*readNameFile();
                		  SendMultiPartSms(recno,uname+ " has added you as recipient on Mobi Security. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.microm2m.net" );
                	      finish();*/
                		  //ReadScoutRecFile();
                		  callContactList();
                	  }
                	  catch(Exception e)
                	  {
                		  System.out.println("send sms "+e);
                	  }
                  }
              }
              
              
              
              );
              
              // Set a negative/no button and create a listener

              alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

                  // Click listener

                  public void onClick(DialogInterface arg0, int arg1) 
                  {

                      //Toast.makeText(getApplicationContext(), "'You Press No button.", Toast.LENGTH_SHORT).show();
                      finish();
      	   			callAddbuddyclick();
                  }

				

				

              }
              
              );
               // show the alert box
              alertbox.show();  
	}	 
    
    private void callAddbuddyclick() {
		// TODO Auto-generated method stub
    	 Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setClassName(this, AddBuddyClick.class.getName());
			startActivity(intent);
	}
    private Button.OnClickListener customDialog_UpdateOnClickListener
    = new Button.OnClickListener(){
  
  @Override
  public void onClick(View arg0) {
   // TODO Auto-generated method stub
   //customDialog_TextView.setText(customDialog_EditText.getText().toString());
	 
      if (  AddBuddyClick.cnt<5) 
      {
                  //FullString += recno;
              //FullString += "  ";
              //FullString += recno;
              //System.out.println(FullString);
              recno=customnoDialog_EditText.getText().toString();
             System.out.println("recno::"+recno);
              	if( recno!=null)
					{
                      //dataAdapter.add(FullString);
              		if(recno.startsWith("+"))
                      	
                      {
                      	//mobnumber=number.substring(number.indexOf("+"),number.indexOf("+")+2);
                      	//mobnumber=recno.substring(3,recno.length());
                      	//System.out.println("with out+91::"+mobnumber);
                      	//recno="";
                          //recno=mobnumber;
                          System.out.println("convert in number"+recno);
                          //ad.RegisterButton.setEnabled(true);
                          writebuddies();
                          alertboxAfterBuddyAdd("Inform Buddies?","Send an SMS to your (new) buddies? This is to tell them that they will be notified if an unkown SIM is inserted in your device");
                      }
              		else
              		{
              			alertboxFinish("Mobi Security","This contact doesn't contain Country Code");
              		}
                     
					}else
					{
						alertboxFinish("Mobi Security","This contact doesn't contain Name or Contact number");
					}
                      
                      //FullString="";
            
             
			
			
            
              /*txtContacts.setText(name);
              numbers_contacts.setText(number);*/
              
      }else
  	{
  		alertboxFinish("Mobi Security","Maximum limit to add buddies is reached");
  	}
  }
     
    };
    
    private Button.OnClickListener customDialog_DismissOnClickListener
    = new Button.OnClickListener(){
  
  @Override
  public void onClick(View arg0) {
   // TODO Auto-generated method stub
   //dismissDialog(CUSTOM_DIALOG_ID);
	  callAddbuddyclick();
	 
  }
     
    };
    
    
    public void ReadScoutRecFile()
    {
    	
    	try
    	 {
    		    
    		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/arpfile");
    		 DataInputStream in = new DataInputStream(fstream);
    		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
    		 String strLine;
    		 while ((strLine = br.readLine()) != null)
    		 {
    			 System.out.println ("@@@@ while STRLINE is "+strLine);
    			 recfullString = strLine.toString();
    		 }
    	     in.close();
    	     
    	     arr1 = recfullString.split("\\;");
    	       			
    	     for (int i=0;i<arr1.length;i++)
    	     {	
    	    	 
    	    	 SendMultiPartSms(arr1[i],uname+ " has added you as recipient on Mobi Security. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.mobisecurity.net" );
    	    	 //SendMultiPartSms(arr[i],uname+ " has added you as recipient on Micro Secure. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.microsecure.net" );
    				
    	     }
    	     
    	  }
    	  catch (IOException ioe)
    	  {
    		  ioe.printStackTrace(); 
    	  }
    }
  /* private Button.OnClickListener customDialog_DeleteOnClickListener
    = new Button.OnClickListener(){
  
  @Override
  public void onClick(View arg0) {
	  customnoDialog_EditText.setText("");
      System.out.println("after set customnmDialog_EditText");
      customnmDialog_EditText.setText("");
      System.out.println("after set customnmDialog_EditText");
   // TODO Auto-generated method stub
   //dismissDialog(CUSTOM_DIALOG_ID);
  }
     
    }; */
 @Override
 protected Dialog onCreateDialog(int id) {
  // TODO Auto-generated method stub
  Dialog dialog = null;;
     switch(id) {
     case CUSTOM_DIALOG_ID:
    	 dialog = new Dialog(ContactListDemo.this);
    	  System.out.println("call dialog");
         dialog.setContentView(R.layout.customlayout);
         System.out.println("after layout");
         dialog.setTitle("Add Buddies");
         System.out.println("after set layout");
         customnoDialog_EditText = (EditText)dialog.findViewById(R.id.dialogeditnotext);
         System.out.println("after customnoDialog_EditText");
         customnmDialog_EditText = (EditText)dialog.findViewById(R.id.dialogeditnmtext);
         System.out.println("after customnmDialog_EditText");
         customnoDialog_EditText.setText(recno);
         System.out.println("after set customnmDialog_EditText");
         customnmDialog_EditText.setText(recName);
         System.out.println("after set customnmDialog_EditText");
         //customDialog_TextView = (TextView)dialog.findViewById(R.id.dialogtextview);
         customokDialog_Update = (Button)dialog.findViewById(R.id.okButt);
         System.out.println("after set customokDialog_Update");
         customcanDialog_Dismiss = (Button)dialog.findViewById(R.id.canButt);
         System.out.println("after set customcanDialog_Dismiss");
         //customdelDialog_Dismiss = (Button)dialog.findViewById(R.id.deleteButt);
         System.out.println("after set customdelDialog_Dismiss");
         customokDialog_Update.setOnClickListener(customDialog_UpdateOnClickListener);
         System.out.println("after set customnmDialog_EditText");
         customcanDialog_Dismiss.setOnClickListener(customDialog_DismissOnClickListener);
         System.out.println("after set customnmDialog_EditText");
         /*customdelDialog_Dismiss.setOnClickListener(customDialog_DeleteOnClickListener);
        System.out.println("after set customnmDialog_EditText");*/
         break;
     }
     return dialog;
 } 
 public void readNameFile()
 {

 	try
 	 {
 		 System.out.println ("INSIDE THE READRECFILE");
 		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/NameField");
 		 System.out.println ("INSIDE THE READRECFILE2");	
 		 DataInputStream in = new DataInputStream(fstream);
 		 System.out.println ("INSIDE THE READRECFILE3");	
 		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
 		 String strLine;
 		 System.out.println ("INSIDE THE READRECFILE4");	
 		 while ((strLine = br.readLine()) != null)
 		 {
 			 System.out.println (strLine);
 			 uname = strLine.toString();
 		 }
 	     in.close();
 	     System.out.println ("Full String is:- " +uname);
 	    
 	    
 	     
 	  }
 	  catch (IOException ioe)
 	  {
 		  ioe.printStackTrace(); 
 	  }
 }
 public void SendMultiPartSms(String add,String msgbdy)
	{
		
 	SmsManager smsManager = SmsManager.getDefault();
 	
     String destAddr = add, scAddr = null, mMessageText =msgbdy;
     
     System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
     
     PendingIntent sentIntent = null, deliveryIntent = null;
     
     try 
     {
     	
     	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
     	
     	
     	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
     	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

     
     	

     for (int i=0; i < messages.size(); i++)
     {

     	
     	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        listOfIntents.add(pi);
     }
     System.out.println ("******** inside TRY FOR SendMultiPartSms10");
     smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

     } catch (Exception e) 
     {
     Log.i("TEST", e.toString());
     }
 
	}	
}