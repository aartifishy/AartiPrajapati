package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import com.micro.mobisecurity.R;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class VideoList extends ListActivity {
	
	String inputLine,wholeVideo;
    String str1,str2,str3;
    String folderName,bkuFolder,type,fileName,newFileName;          
    String strLine,str,imei;
	File video = new File("data/data/com.micro.mobisecurity/video.3gp");
    File videoFile = new File("data/data/com.micro.mobisecurity/videoFile.txt");
    int a,size,total,deo,deo1;
    private int count=0;
	 private static final int NOTIFY_ME_ID=1337;
    FileOutputStream out1;
	@SuppressWarnings("rawtypes")
	public Vector data;
	/*
	@SuppressWarnings("rawtypes")
	public MyList(Vector rawData)
	{
		data=rawData;
	}*/
	/** Called when the activity is first created. */
	
	
	@SuppressWarnings("unchecked")
	public void onCreate(Bundle icicle) {
		
		data=VideoRestore.vct2;
		System.out.println("inside oncreate MyList1");
		super.onCreate(icicle);
		// Request the progress bar to be shown in the title
	       requestWindowFeature(Window.FEATURE_PROGRESS);
	       setProgress(10000); // Turn it off for now
	       calCulateIMEI();
		System.out.println("inside oncreate MyList2");
		// Create an array of Strings, that will be put to our ListActivity
		//String[] names = new String[] { "AddCode", "Display Code", "Setting" };
		// Use your own layout and point the adapter to the UI elements which
		// contains the label
		//System.out.println("data"+data.elementAt(2));
	 this.setListAdapter(new ArrayAdapter<String>(this, R.layout.rowlayout,
				R.id.label, data));
	}
	 private void calCulateIMEI() {
			// TODO Auto-generated method stub
	   	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			imei = mTelephonyMgr.getDeviceId();
		} 
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		// Get the item that was clicked
		Object o = this.getListAdapter().getItem(position);
		 str1 = o.toString();
		//Toast.makeText(this, "You selected: " + keyword, Toast.LENGTH_LONG)
				//.show();
		//setContentView(R.layout.mediafromserver);  
		 Thread t = new Thread(){
			   public void run()
			   {
	     deo = str1.indexOf('~')+1;
		 deo1 = str1.indexOf('\\');
		folderName =str1.substring(deo,deo1);
		String remainingString = str1.substring(deo1+1);
		
		System.out.println ("Folder name is "+folderName);
		System.out.println ("Remaining string is"+remainingString);
		int deo2 = remainingString.indexOf('\\');
		System.out.println (deo2);
		type = remainingString.substring(0,deo2);
		System.out.println (type);
		
	    fileName = remainingString.substring(deo2+1);
		System.out.println (fileName);
		byte[] fileArray = fileName.getBytes();
		newFileName = Base64.encode(fileArray);
		System.out.println ("$$$$$$$$$$$$$$$$$$"+newFileName);
		restoreImage();
		video.delete();
		videoFile.delete();
		notifyMe();
		//finish();
			   }
			};
			
			t.start();
			try{
				setContentView(R.layout.mediafromserver);
					//setContentView(R.layout.mediafromserver);
			}catch (Exception e){e.printStackTrace();}
		//setContentView(R.layout.mediastoreonphone);  
	}
	 public void restoreImage()
	    {
	    	
	    	System.out.println ("inside restoreImage");
	    	 try
	    	 { 
	    		 videoFile.createNewFile();
	    		 PrintWriter out = new PrintWriter(videoFile);
	             URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/Encode.aspx?UserID="+imei+"&Folder="+folderName+"&Type="+type+"&File="+newFileName); 
	    		// URL yahoo = new URL("www.microlifeline.net/new/Encode.aspx?UserID=0213456789&Folder="+folderName+"&Type="+type+"&File="+newFileName);
	             BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream())); 
	                        
	             char[] buffer = new char[2048];

	             ByteArrayOutputStream baos = new ByteArrayOutputStream();
	             BufferedWriter bw = new BufferedWriter(out);

	             while ((size = in.read(buffer, 0, buffer.length)) != -1)
	             {
	            	 System.out.println ("Inside while!!!!!!!!!!!!");
	                     total += size ;
	                     bw.write(buffer, 0, size) ;
	                     
	             } 
	             
		      		out.flush();
		      		baos.close();
	          
	         }
	    	 catch (MalformedURLException me)
	    	 { 
	             System.out.println(me); 
	     
	         }
	    	 catch (IOException ioe)
	    	 {  
	             System.out.println(ioe); 
	         }  
	    	 System.out.println ("############################################################");
	    	decodeImage();
	     	//alertbox("information","Video restored succesfully");

	    }
	 public void decodeImage()
	    {
	    	System.out.println ("Now decoding image");
	    
	    	try
	   	 	{
	    		video.createNewFile();
		   		 byte[] byteArray = new byte[102300];
		   		 FileInputStream fstream = new FileInputStream(videoFile); 
		   		out1 = new FileOutputStream(video);  
		   		 int bytesRead = 0;
		   		 while((bytesRead = fstream.read(byteArray)) != -1)
		   		 {  
		   			str = new String(byteArray,0,bytesRead);  
		   			byte[] im = Base64.decode(str);
		   			
		    		 try
		    		 {  
		    		     out1.write(im);  
		    		     out1.flush();
		    		 }
		    		 catch (Exception e)
		    		 {
		    			 e.printStackTrace();
		    		 }
		   		 }
		   		 
		   		 
		   		 out1.close();
		   		 
	   	 	}
	    	catch (Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	 protected void alertbox(String title, String mymessage)   
	    {   
	   	 new AlertDialog.Builder(this)   
	       .setMessage(mymessage)   
	       //.setTitle(title)   
	       .setCancelable(true)   
	       .setNeutralButton(android.R.string.cancel,   
	          new DialogInterface.OnClickListener() {   
	          public void onClick(DialogInterface dialog, int whichButton){}   
	          })   
	       .show();   
	    }
	 private void notifyMe()
		{
	    	//setContentView(R.layout.mediastoreonserver);
			final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
			Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
			PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
			
			note.setLatestEventInfo(this, "Mobi Security",	"Your Media part are restored successfully", i);
		
	
			note.number=++count;
			
			mgr.notify(NOTIFY_ME_ID, note);
		}
}
		