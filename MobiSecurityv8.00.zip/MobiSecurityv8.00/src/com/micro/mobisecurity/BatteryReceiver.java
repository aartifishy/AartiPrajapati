package com.micro.mobisecurity;
/* <!-- 
* Copyright (C) 2009 AlmondMendoza
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
-->
*/
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class BatteryReceiver extends BroadcastReceiver {

	 String filedata4;
        @Override
        public void onReceive(Context context, Intent intent) {
                // TODO Auto-generated method stub
        	readToggleBattInfoOnSIMchngFile();
        	//BatteryOn
        	if(filedata4.equals("BatteryOn"))
        	{
                PrefsActivity.connectToBatteryService(context);
        	}
        	else
        	{
        		
        		System.exit(0);
        	}
        }
        public void readToggleBattInfoOnSIMchngFile()
        {
        	try
        	 {
        		 System.out.println ("INSIDE THE READRECFILE");
        		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/BattInfo");
        		 System.out.println ("INSIDE THE READRECFILE2");	
        		 DataInputStream in = new DataInputStream(fstream);
        		 System.out.println ("INSIDE THE READRECFILE3");	
        		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
        		 String strLine;
        		 System.out.println ("INSIDE THE READRECFILE4");	
        		 while ((strLine = br.readLine()) != null)
        		 {
        			 System.out.println (strLine);
        			 filedata4 = strLine.toString();
        		 }
        	     in.close();
        	     System.out.println ("Full String is:- " +filedata4);
        	    
        	    
        	     
        	  }
        	  catch (IOException ioe)
        	  {
        		  ioe.printStackTrace(); 
        	  }
        }
}
