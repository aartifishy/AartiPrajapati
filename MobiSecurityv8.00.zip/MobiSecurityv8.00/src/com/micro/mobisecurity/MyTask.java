package com.micro.mobisecurity;
import android.app.ProgressDialog;
import android.os.AsyncTask;

public class MyTask extends AsyncTask<Void, Void, Void> {
  private ProgressDialog progress;

public MyTask(ProgressDialog progress) {
    this.progress = progress;
  }

  public void onPreExecute() {
    progress.show();
  }

  

  public void onPostExecute(Void unused) {
    progress.dismiss();
  }

@Override
protected Void doInBackground(Void... arg0) {
	// TODO Auto-generated method stub
	return null;
}
}
