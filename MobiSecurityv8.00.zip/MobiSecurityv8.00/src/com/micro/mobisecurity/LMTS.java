package com.micro.mobisecurity;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;

public class LMTS extends Activity

{	
	String imsi="",imei="",FullString="";
	File PhoneInfoFile=new File("data/data/com.micro.mobisecurity/PhoneInfoFile");
	File scoutRecFile=new File("data/data/com.micro.mobisecurity/ScoutRecFile");
	
	//File PhoneInfoFile=new File("/sdcard/PhoneInfoFile");
	@Override
	
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        
        System.out.println("@@@@@ LMTS @@@@@");
        
        if(scoutRecFile.exists())
        {
		  
			    System.out.println ("@@@@ if PhoneInfoFile is exist @@@@");
			    
			    StartSimChangClass();
	    }
        else
        {
        	System.out.println ("@@@@ else PhoneInfoFile is not exist @@@@");	
        	
        	//FetchIMEInIMSI();
         
        }
        
  
       
    }
	
	public void FetchIMEInIMSI()
	{
		
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		imei = mTelephonyMgr.getDeviceId(); 
		imsi = mTelephonyMgr.getSubscriberId(); 
		
		FullString += imei;
		FullString += "?";
		FullString += imsi;
			
		System.out.println("IMEI Is "+imei);
		System.out.println("IMSI Is "+imsi);
		System.out.println("Full String is "+FullString);
		
		FileWrite(PhoneInfoFile,FullString);
	  
		
		//moveTaskToBack(true);
	    
	    //finish();
	}
	
	public void FileWrite(File aPath,String aBody)
	{
		try 
    	{
			 System.out.println("@@@@ Inside Try FileWrite @@@@");
			 
			 aPath.createNewFile();
			 PrintWriter out1 = new PrintWriter(aPath);
			 out1.write(aBody);  
			 System.out.println (aBody.trim());
			 out1.flush();
			 out1.close();
    	}
    	catch (IOException ioe)
		 {
    		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
    		ioe.printStackTrace();
		 }
		
	}
	
	public void StartSimChangClass()
	{
		
		Intent intent = new Intent(this,LMTScheckSIM.class);
    	startActivity(intent);
	}

}
