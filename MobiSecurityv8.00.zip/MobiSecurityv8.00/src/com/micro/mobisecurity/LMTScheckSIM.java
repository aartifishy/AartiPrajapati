package com.micro.mobisecurity;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Timer;
import java.util.TimerTask;

import com.micro.mobisecurity.Find.listenLocation;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.CellLocation;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;

public class LMTScheckSIM extends Activity

{	
	String imsi,imei,serviceProvider,strLine1,strLine2;
	public String fullString,IMEIfromFile,IMSIfromFile,recfullString;
	GregorianCalendar endDay,now,startDay;
	//File ToggleSirenOnSIMchng=new File("data/data/com.Multipartsms.com/SirenToggle");
	//File ToggleAutoLockOnSIMchng=new File("data/data/com.Multipartsms.com/LockToggle");
	File SirenStart=new File("data/data/com.micro.mobisecurity/sirendone");
	String location_context="",strProvider="";
	LocationManager locationManager;
	Criteria criteria=null;
	private static boolean locUpdateStatus=false;
	File stdAppExpiredFile = new File(
	"data/data/com.micro.mobisecurity/StandardAppExpired");
	File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
	File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
	File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
	File BlockStart=new File("data/data/com.micro.mobisecurity/block");
	public String rec1,rec2,timsi,uname,networkOperator,countrycode;
	int  mcc,mnc,c=0,intCount=0,intWait=0;
	String passString;
	//public static Telnumber="";
	public static String  Telnumber="";
	public static String  Num="";
	String[]arr,arr1;
	Location location;
	GsmCellLocation location1; 
	int cellID,lac,serviceState=0, signal = 0;
	  String strLine,sendrec1,sendrec2,sendrec3,sendrec4,sendrec5;
	  public String filedata1,filedata2,filedata3,filedata4; 
	  double lat=0.0,lng=0.0,speed;
	  TelephonyManager mTelephonyMgr;
	@Override
	
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        //moveTaskToBack(true);
      if(appactFile.exists())
        {
        	moveTaskToBack(true);
        	System.exit(0);
        }
      else if(BlockStart.exists())
      {
  		System.out.println("block start");
    	  Intent intent = new Intent(Intent.ACTION_VIEW);
  		intent.setClassName(this, BlockOnly.class.getName());
  		startActivity(intent);
  		
  		
      }
      else if(SirenStart.exists())
      {
      	System.out.println("siren start");
    	  Intent intent = new Intent(Intent.ACTION_VIEW);
  		intent.setClassName(this, SirenBlock.class.getName());
  		startActivity(intent);
  		
  		
      }
        else
        {
        	 
        System.out.println("@@@@@ LMTScheckSIM Activity @@@@@");
        System.out.println ("Inside onCreate()");
		location_context = Context.LOCATION_SERVICE;
		 System.out.println("location context"+location_context);
	    locationManager = (LocationManager)getSystemService(location_context);
	    System.out.println("location Manager"+locationManager);
        
       
        
        System.out.println("...........Number to send sms is......."+Num);
        
        System.out.println("@@@@@ checkIMSI @@@@@");
        checkIMSI();
        
        System.out.println("@@@@@ ReadScoutPhoneInfoFile @@@@@");
        ReadScoutPhoneInfoFile(); // IMEI IMSI
       // ReadScoutPhoneInfoFile()
        //ReadSirenToggleFile();
        //ReadLockToggleFile();
        try
		{
			readStartDateFile();
			readEndDateFile();
		}
		catch (ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
        
        System.out.println("****** strLine1"+strLine1);
        System.out.println("****** strLine2"+strLine2);
        
        System.out.println("@@@@@ CompareIMSI @@@@@");
        CompareIMSI();
        
       // System.exit(0);
        
        //moveTaskToBack(true);
	    
	    //finish();
      
        }
    }
	
	

	public void CompareIMSI()
	{
		try
		{
		System.out.println("@@@@ compare imsi 1 @@@@"); 
		System.out.println("@@@@ compare imsi 2 @@@@"+imsi);
		System.out.println("@@@@ compare imsi 3 @@@@"+IMSIfromFile);
		now = new GregorianCalendar();
		System.out.println(now);
		if (imsi.equals(IMSIfromFile))
		 {
			 if (endDay.after(now)) 
			 {
				 System.out.println ("First condition is true");
				 if ((now.after(startDay)))
				 {
					 System.out.println ("Sim has not changed");
					 //sendSMS("7709640709","Sim has not changed");
					 //sendSMS(rec1,"Sim has not changed");
					 //sendSMS(rec2,"Sim has not changed");
				 }
				else
				{
					System.out.println ("Sim has not changed, But date is changed therefore application is expired");
					try {
						stdAppExpiredFile.createNewFile();
					} catch (IOException ioe) {
						ioe.printStackTrace();
					}
					Intent intent = new Intent(Intent.ACTION_VIEW);
			  		intent.setClassName(this, PeriodExpired.class.getName());
			  		startActivity(intent);
					//sendSMS(rec1,"Sim has not changed, But date is changed therefore application is expired");
					//sendSMS(rec2,"Sim has not changed, But date is changed therefore application is expired");
					//sendSMS("7709640709","Sim has not changed, But date is changed therefore application is expired");
				}
			}
			else
			{
				System.out.println ("Sim has not changed but application is expired");
				//sendSMS(rec1,"Sim has not changed but application is expired");
				//sendSMS(rec2,"Sim has not changed but application is expired");
				//sendSMS("7709640709","Sim has not changed but application is expired");
				try {
					stdAppExpiredFile.createNewFile();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				Intent intent = new Intent(Intent.ACTION_VIEW);
		  		intent.setClassName(this, PeriodExpired.class.getName());
		  		startActivity(intent);
			}
			
		 }
		 else
		 {
			 networkOperator = mTelephonyMgr.getNetworkOperator();
			 System.out.println("network operator::"+networkOperator);
			 mcc = Integer.parseInt(networkOperator.substring(0, 3));
			 System.out.println("mcc::"+mcc);
		        countrycode = Integer.toString(mcc);
		        System.out.println("cc::"+countrycode);
		        //System.out.println("mcc"+countrycode);
	         mnc = Integer.parseInt(networkOperator.substring(3));
	         System.out.println("nc::"+mnc);
			 SmsReceiver sr=new SmsReceiver();
		        
		        Num=sr.IncommingNumber;
			
			 if (endDay.after(now)) 
			 { 
			 if ((now.after(startDay)))
			 {
				 readToggleSirenOnSIMchngFile();
			        readToggleSirenOffSIMchngFile();
			        readToggleAutoLockOnSIMchngFile();
			        readToggleAutoLockOffSIMchngFile();
				
				 CalculateLatandLang();
				 System.out.println("@@@@ SIM is Changed @@@@");
				 System.out.println("@@@@ strLine1 Siren " +strLine1);
				 System.out.println("@@@@ strLine2 Lock" +strLine2);
				 
				 readNameFile();
				 
				 System.out.println("********filedata1*********"+filedata1);
				 System.out.println("********filedata2*********"+filedata2);
				 System.out.println("********filedata3*********"+filedata3);
				 System.out.println("********filedata4*********"+filedata4);
				 //SimChange;IMEI;IMSI;CELLID;LAT;LONG;SERVICEPROVIDER
				 passString ="M2MSimChange;"+imei+";"+imsi+";"+mcc+lac+cellID+";"+lat+";"+lng+";"+serviceProvider;
				 
				// sendSMS(Num,"MicroSecure Alert-SIM change on " + " phone with IMEI-" + imei + ",NEW SIM IMSI-" + imsi + ", + Cell Id-"+lac+cellID);
				
				 //if(strLine1.equals("SirenOn")&& strLine2.equals("LockOff"))
				 if(filedata2.equals("SirenOff")&& filedata3.equals("LockOn"))
				 {
					 try
					 {
					 //SendMultiPartSms("+919223187878",passString);
					 }
					 catch(Exception e)
					 {
						 
					 }
					 System.out.println("@@@@ SirenOff &&  LockOn @@@@");
					 
					 ReadScoutRecFile();
					 LockWithoutSiren();
				 }
				 else if(filedata1.equals("SirenOn")&& filedata3.equals("LockOn"))
				 {
					 try
					 {
					 //SendMultiPartSms("+919223187878",passString);
					 }
					 catch(Exception e)
					 {
						 
					 }
					 System.out.println("@@@@ LockOn &&  SirenOn @@@@");
					 
					 ReadScoutRecFile();
					 LockWithSiren();
				 }
				 
				 else if(filedata2.equals("SirenOff")&& filedata4.equals("LockOff"))
				 {
					 try
					 {
					// SendMultiPartSms("+919223187878",passString);
					 }
					 catch(Exception e)
					 {
						 
					 }
					 System.out.println("@@@@ LockOff &&  SirenOff @@@@");
					 
					 ReadScoutRecFile();
			
				 }
			 }
			else
			{
				System.out.println ("Sim has not changed, But date is changed therefore application is expired");
				 try
				 {
				// SendMultiPartSms("+919223187878",passString);
				 }
				 catch(Exception e)
				 {
					 
				 }
				try {
					stdAppExpiredFile.createNewFile();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				Intent intent = new Intent(Intent.ACTION_VIEW);
		  		intent.setClassName(this, PeriodExpired.class.getName());
		  		startActivity(intent);
				//sendSMS(rec1,"Sim has not changed, But date is changed therefore application is expired");
				//sendSMS(rec2,"Sim has not changed, But date is changed therefore application is expired");
				//sendSMS("7709640709","Sim has not changed, But date is changed therefore application is expired");
			}
			 }
				else
				{
					System.out.println ("Sim has not changed but application is expired");
					 try
					 {
					// SendMultiPartSms("+919223187878",passString);
					 }
					 catch(Exception e)
					 {
						 
					 }
					//sendSMS(rec1,"Sim has not changed but application is expired");
					//sendSMS(rec2,"Sim has not changed but application is expired");
					//sendSMS("7709640709","Sim has not changed but application is expired");
					try {
						stdAppExpiredFile.createNewFile();
					} catch (IOException ioe) {
						ioe.printStackTrace();
					}
					Intent intent = new Intent(Intent.ACTION_VIEW);
			  		intent.setClassName(this, PeriodExpired.class.getName());
			  		startActivity(intent);
				} 
			 
			 
		 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		 
	}
synchronized  public void   CalculateLatandLang()
	
    {          
		try
		{
			System.out.println("************Inside CalculatelatLong*****************");
			locUpdateStatus=false;
			System.out.println("************Inside CalculatelatLong***22222222**************");
			System.gc();
		
	   	 	//Setting Criteria
	   	 	criteria = new Criteria();
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setAccuracy(Criteria.ACCURACY_FINE);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setAltitudeRequired(false);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setBearingRequired(false);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setCostAllowed(true);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	criteria.setPowerRequirement(Criteria.POWER_LOW);
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	strProvider = locationManager.getBestProvider(criteria, true);
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	//mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	try
			{
			 		System.out.println("***GPS Provider IS NOT NULL********** ");
			 		listenLocation locationListener=new listenLocation();
					locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,15000, 10, locationListener);
					System.out.println("*******Location Listner thread Is started*****");
			}
			catch (Exception e) 
			{
				TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
		  		//lat=0.0;
		        //  lng=0.0;
		                 
		  		//---obtain the CellID and LAC of the device---
		  	        CellLocation.requestLocationUpdate();        
		  	        cellID = location1.getCid();
		  	         lac = location1.getLac();

		  	       
		  	        
		  	        try {
		  	            if (!displayMap(cellID, lac))
		  	            {
		  	                lat=0.0;
		  	                lng=0.0;
		  	            }
		  	                
		  	        } catch (Exception e1) {                    
		  	            e1.printStackTrace();
		  	        } 
					dataSendTimeInterval();
			  	
			}	
			
			System.out.println("gps provider is ---"+locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
			
			Timer timer=new Timer();
			TimerTask task=new TimerTask() {
				
				@Override
				public void run() 
				{
					System.out.println("locUpdateStatus--"+locUpdateStatus);
					if(locUpdateStatus==false)
					{
						System.out.println("inside imer locupdate status");
					System.out.println("Inside While....Thread sleep for-"+c+"-times");
					TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
			  		//lat=0.0;
			        //  lng=0.0;
			                 
			  		//---obtain the CellID and LAC of the device---
			  	        CellLocation.requestLocationUpdate();        
			  	        cellID = location1.getCid();
			  	         lac = location1.getLac();

			  	       
			  	        
			  	        try {
			  	            if (!displayMap(cellID, lac))
			  	            {
			  	                lat=0.0;
			  	                lng=0.0;
			  	            }
			  	                
			  	        } catch (Exception e) {                    
			  	            e.printStackTrace();
			  	        } 
						dataSendTimeInterval();
				  	}
					else
					{
						dataSendTimeInterval();
					}
					c++;
				}
			};
			timer.schedule(task, 0, 15000);
		
		}
		catch(Exception e)
		{
			
		System.out.println("error 4-->"+e);
	
		}
		
		
     } 
private void updateWithNewLocation( Location location)
{
	  this.location=location;
	  System.out.println("--------------updateWithNewLocation-------------------");
	  if (location != null) 
	  {
		  lat = location.getLatitude();
		  //strLat1 = Double.toString(dblLat);
		  lng = location.getLongitude();
		  //strLng1 = Double.toString(dblLng);
		  this.location=location;
		  
		  //dblLat = location.getLatitude();
		  //strLat1 = Double.toString(dblLat);
	   	  //dblLng = location.getLongitude();
	      //strLng1 = Double.toString(dblLng);
	 	  //dblSpeed=location.getSpeed();
	 	  //strSpeed1 = Double.toString(dblSpeed);
		  //dblSpeed=location.getSpeed();
		  //strSpeed1 = Double.toString(dblSpeed);
		  locUpdateStatus=true;
		  System.out.println("**************************  2");
		  dataSendTimeInterval();
	    	
		 
	  }
		
	  else 
		  
	  {
		  System.out.println("inside lat lng got it zero");
		  TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
	  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
	  		//lat=0.0;
	        //  lng=0.0;
	                 
	  		//---obtain the CellID and LAC of the device---
	  	        CellLocation.requestLocationUpdate();        
	  	        cellID = location1.getCid();
	  	         lac = location1.getLac();

	  	       
	  	        
	  	        try {
	  	            if (!displayMap(cellID, lac))
	  	            {
	  	                lat=0.0;
	  	                lng=0.0;
	  	            }
	  	                
	  	        } catch (Exception e) {                    
	  	            e.printStackTrace();
	  	        } 
			dataSendTimeInterval();
	  		 //sb.append("No Location");
	}
			
}
private void ProviderDisable(String provider)
{
	  try
	  {
		  System.out.println("provider disable falseeeeeeeeeeeeeee");
		  locUpdateStatus=false;
		  TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
	  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
	  		//lat=0.0;
	        //  lng=0.0;
	                 
	  		//---obtain the CellID and LAC of the device---
	  	        CellLocation.requestLocationUpdate();        
	  	        cellID = location1.getCid();
	  	         lac = location1.getLac();

	  	       
	  	        
	  	        try {
	  	            if (!displayMap(cellID, lac))
	  	            {
	  	                lat=0.0;
	  	                lng=0.0;
	  	            }
	  	                
	  	        } catch (Exception e) {                    
	  	            e.printStackTrace();
	  	        } 
		  	dataSendTimeInterval();
		  	//Thread.sleep(8000);
		  	// CalculateLatandLang();
	  }
	  catch(Exception e)
	  {
		  System.out.println("provider disable ERROR--"+e);
		  CalculateLatandLang();
	  }
}

class listenLocation implements LocationListener
{
	@Override
	public void onLocationChanged(Location location)
	{
		
		updateWithNewLocation(location);
				
	}
	@Override
	public void onProviderDisabled(String provider)
	{		
		ProviderDisable(provider);
		/* bring up the GPS settings */
		/*Intent intent = new Intent(
				android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(intent);*/
	
	}
	@Override
	public void onProviderEnabled(String provider) {
		System.out.println("*************Provider Enable***********");
		locUpdateStatus=true;
	//	CalculateLatandLang();
		
	}
	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		locUpdateStatus=true;
		System.out.println("on provider Changed--**provider--"+provider);
		System.out.println("on provider Changed--**status--"+status);
		System.out.println("on provider Changed--**Bundle Extras--"+extras.describeContents());
		//CalculateLatandLang();
		
	}
}
    private boolean displayMap(int cellID, int lac) throws Exception 
    {
        String urlString = "http://www.google.com/glm/mmap";            
    
        //---open a connection to Google Maps API---
        URL url = new URL(urlString); 
        URLConnection conn = url.openConnection();
        HttpURLConnection httpConn = (HttpURLConnection) conn;        
        httpConn.setRequestMethod("POST");
        httpConn.setDoOutput(true); 
        httpConn.setDoInput(true);
        httpConn.connect(); 
        
        //---write some custom data to Google Maps API---
        OutputStream outputStream = httpConn.getOutputStream();
        WriteData(outputStream, cellID, lac);       
        
        //---get the response---
        InputStream inputStream = httpConn.getInputStream();  
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        
        //---interpret the response obtained---
        dataInputStream.readShort();
        dataInputStream.readByte();
        int code = dataInputStream.readInt();
        if (code == 0) {
            lat = (double) dataInputStream.readInt() / 1000000D;
            lng = (double) dataInputStream.readInt() / 1000000D;
            dataInputStream.readInt();
            dataInputStream.readInt();
            dataInputStream.readUTF();
            
            //---display Google Maps---
           /* String uriString = "geo:" + lat
                + "," + lng;
            System.out.println("Gps location::"+uriString);
            Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
                Uri.parse(uriString));
            startActivity(intent);*/
            return true;
        }
        else
        {        	
        	return false;
        }
    }  

    private void WriteData(OutputStream out, int cellID, int lac) 
    throws IOException
    {    	
        DataOutputStream dataOutputStream = new DataOutputStream(out);
        dataOutputStream.writeShort(21);
        dataOutputStream.writeLong(0);
        dataOutputStream.writeUTF("en");
        dataOutputStream.writeUTF("Android");
        dataOutputStream.writeUTF("1.0");
        dataOutputStream.writeUTF("Web");
        dataOutputStream.writeByte(27);
        dataOutputStream.writeInt(0);
        dataOutputStream.writeInt(0);
        dataOutputStream.writeInt(3);
        dataOutputStream.writeUTF("");

        dataOutputStream.writeInt(cellID);  
        dataOutputStream.writeInt(lac);     

        dataOutputStream.writeInt(0);
        dataOutputStream.writeInt(0);
        dataOutputStream.writeInt(0);
        dataOutputStream.writeInt(0);
        dataOutputStream.flush();    	
    }
	public void checkIMSI()
	{
		
		while(true)
		{
			try
			{
				intWait++;
		mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
		System.out.println("imei"+imei);
		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
		serviceProvider = mTelephonyMgr.getSimOperatorName();
		System.out.println("service provider"+serviceProvider);
		  imsi = mTelephonyMgr.getSubscriberId(); 
		  System.out.println("imsi::"+imsi);
		//cellID = location.getCid();
		//lac = location.getLac();
		
		 System.out.println("network operator::"+networkOperator);
         serviceState = mTelephonyMgr.getSimState();
         System.out.println("service state::"+serviceState);
 		SignalStrength t = new SignalStrength();
 		signal = t.mGsmSignalStrength;
 		System.out.println("inside si8gnal::"+signal);
 		networkOperator = mTelephonyMgr.getNetworkOperator();
		 System.out.println("network operator::"+networkOperator);
		 if(networkOperator.equals("") || networkOperator.equals(null))
		 {
			 System.out.println("block start");
	    	  Intent intent = new Intent(Intent.ACTION_VIEW);
	  		intent.setClassName(this, BlockOnly.class.getName());
	  		startActivity(intent);
		 }
		 else if( !serviceProvider.equals("") && !serviceProvider.equals(null) && !imsi.equals("") &&   !imsi.equals(null)&& serviceState>=1)
 		{
 			System.out.println("inside service provider break");
 			break;
 		}
 		
 		try
 		{
 		Thread.sleep(5000);
 		System.out.println("waitingggggggggggggggg");
 		}
 		catch(Exception e)
 		{
 			System.out.println("waitttttttttttttttttttttttttttttttttttttttttttt"+e);
 		}
			}
 		catch (Exception cnfe)
		{
			cnfe.printStackTrace();
		} 
		}
		
		

	}
	
	public void ReadScoutPhoneInfoFile()
	 {
		
  	try
		 {
			    
  			 System.out.println ("##### ReadScoutPhoneInfoFile 1  ");
  		
  			 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/PhoneInfoFile");
  			 System.out.println ("##### ReadScoutPhoneInfoFile 2  ");
  			 DataInputStream in = new DataInputStream(fstream);
  			 System.out.println ("##### ReadScoutPhoneInfoFile 3  ");
  			 BufferedReader br = new BufferedReader(new InputStreamReader(in));
  			 System.out.println ("##### ReadScoutPhoneInfoFile 4  ");
  			 String strLine;
			 while ((strLine = br.readLine()) != null)
			 {
				 System.out.println ("@@@@ while STRLINE is "+strLine);
				 fullString = strLine.toString();
			 }
		     in.close();
		     
		     arr = fullString.split("\\?");
		       			
		     for (int i=0;i<arr.length;i++)
		     	
		     IMEIfromFile=arr[0];	 
		     IMSIfromFile=arr[1];	
		     
		     System.out.println ("##### IMEI FROM FILE IS  "+IMEIfromFile);
		     System.out.println ("##### IMSI FROM FILE IS  "+IMSIfromFile);
		    
		     
		  }
		  catch (IOException ioe)
		  {
			  ioe.printStackTrace(); 
		  }
	 }
	
	
	 public void SendMultiPartSms(String add,String msgbdy)
		{
			
	    	SmsManager smsManager = SmsManager.getDefault();
	    	
	        String destAddr = add, scAddr = null, mMessageText =msgbdy;
	        
	        System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
	        
	        PendingIntent sentIntent = null, deliveryIntent = null;
	        
	        try 
	        {
	        	
	        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
	        	
	        	
	        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

	        
	        	

	        for (int i=0; i < messages.size(); i++)
	        {

	        	
	        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
		        listOfIntents.add(pi);
	        }
	        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
	        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

	        } catch (Exception e) 
	        {
	        Log.i("TEST", e.toString());
	        }
	    
		}	
	

public void ReadSirenToggleFile()
{
	
	
	try
	 {
		
		 System.out.println("ReadIncSmsFile 1");
		 byte[] strL=new byte[102400];
		 //FileInputStream fstream = new FileInputStream("data/data/com.Multipartsms.com/SirenToggle");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/SirenToggle");
		 int strLine=0;
		 	
		 while ((strLine =fstream.read(strL)) != -1)
		
		 {
			
			 System.out.println (strLine);
			 strLine1 =new String(strL,0,strLine);
			 
		
			 
			 System.out.println("***** Rec complete ********"+strLine1);
			 
		 }
		 
		
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }

}

public void ReadScoutRecFile()
{
	
	try
	 {
		    
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/arpfile");
		 DataInputStream in = new DataInputStream(fstream);
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println ("@@@@ while STRLINE is "+strLine);
			 recfullString = strLine.toString();
		 }
	     in.close();
	     
	     arr1 = recfullString.split("\\;");
	       			
	     for (int i=0;i<arr1.length;i++)
	     {	
	    try
	    {
	    	 SendMultiPartSms(arr1[i],"Mobi Security Alert-SIM change on " + uname
						+ " phone with IMEI-" + imei
						+ ",NEW SIM IMSI-" + imsi
						+ ",Cell Id-"+mcc+lac+cellID+" Visit http://www.microappstore.net/page/gmap.aspx?latlong="+lat+","+lng+" for your phone location. & Other Commands 1)Help<Password>-To know information about Mobi Security other commands." );
	    	 //SendMultiPartSms(arr[i],uname+ " has added you as recipient on Micro Secure. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.microsecure.net" );
	    }
	    catch(Exception e)
	    {
	    	
	    }
	     }
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void ReadLockToggleFile()
{
	
	
	try
	 {
		
		 System.out.println("ReadIncSmsFile 1");
		 byte[] strL=new byte[102400];
		 //FileInputStream fstream = new FileInputStream("data/data/com.Multipartsms.com/LockToggle");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/LockToggle");
		 
		 
		 int strLine=0;
		 	
		 while ((strLine =fstream.read(strL)) != -1)
		
		 {
			
			 System.out.println (strLine);
			 strLine2 =new String(strL,0,strLine);
			 
		
			 
			 System.out.println("***** Rec complete ********"+strLine2);
			 
		 }
		 
		
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }

}
public void LockWithoutSiren()
{
	  Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setClassName(this, BlockOnly.class.getName());
		startActivity(intent);
		
		finish();
}

public void LockWithSiren()
{
	  	Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setClassName(this, SirenBlock.class.getName());
		startActivity(intent);
		
		finish();
}
public void readNameFile()
{

	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/NameField");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 uname = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +uname);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void readToggleSirenOnSIMchngFile()
{

	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/SirenToggle");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 filedata1 = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +filedata1);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void readToggleSirenOffSIMchngFile()
{

	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/SirenToggle");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 filedata2 = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +filedata2);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void readToggleAutoLockOnSIMchngFile()
{
 
	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/LockToggle");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 filedata3 = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +filedata3);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void readToggleAutoLockOffSIMchngFile()
{
	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/LockToggle");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 filedata4 = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +filedata4);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void readEndDateFile() throws ClassNotFoundException 
{
	 try
	 {
		 ObjectInputStream objectIn1 = null;
		 boolean test = true;															
			
		 objectIn1 = new ObjectInputStream(new BufferedInputStream(new FileInputStream("data/data/com.micro.mobisecurity/MicroStartDate")));
		
		 while (test)  
		 {
			 startDay = (GregorianCalendar) objectIn1.readObject();
			 System.out.println ("within while loop of start date file");
			 System.out.println (startDay);
			 System.out.println ("After reading start date from file");
			 test=false;
		 }

		 objectIn1.close();

		 int year = startDay.get(Calendar.YEAR);
		 int month = startDay.get(Calendar.MONTH)+1;
		 int day = startDay.get(Calendar.DAY_OF_MONTH);

		 System.out.println ("***********************************************");
		 System.out.println (year+":"+month+":"+day);
			
		}
		catch (IOException ioe)
    	{
    		ioe.printStackTrace();
    	}
}

public void readStartDateFile() throws ClassNotFoundException 
{
	 System.out.println ("Inside readEnDateFromFile");
	 try
	 {
		 ObjectInputStream objectIn2 = null;
		 boolean test2 = true;
		
		 objectIn2 = new ObjectInputStream(new BufferedInputStream(new FileInputStream("data/data/com.micro.mobisecurity/MicroEndDate")));
		
		 System.out.println ("Before while");
		 while (test2)
		 {
			 System.out.println ("Inside while");
			 endDay = (GregorianCalendar) objectIn2.readObject();
			 System.out.println ("within while loop of end date file");
			 System.out.println (endDay);
			 System.out.println ("After reading end date from file");
			 test2=false;
		 }

		 objectIn2.close();

		 int year = endDay.get(Calendar.YEAR);
		 int month = endDay.get(Calendar.MONTH)+1;
		 int day = endDay.get(Calendar.DAY_OF_MONTH);
		 System.out.println ("************** *********************************");  
		 System.out.println (year+":"+month+":"+day);

	 }
	 catch (IOException ioe)
	 {
		 ioe.printStackTrace();
	 }
} 
synchronized public void dataSendTimeInterval()
{
	 intCount++;
	try
	{
		 if(intCount%3==0)
		 {
			 System.out.println("**************************  hitted");
			 ReadScoutRecFile();
			 System.out.println("after hit url  ");
			 System.out.println("Data send process ----> " +intCount);
			 
			 intCount=0;
			 System.out.println("--count "+ intCount);
			System.gc();
			finish();
			System.exit(0);
		 }
	 }
	 catch(Exception ext)
	 {
		 System.out.println("File Error--"+ext);
	 }
	 finally
	 {
		 System.gc();
		 
  	}
}
}
