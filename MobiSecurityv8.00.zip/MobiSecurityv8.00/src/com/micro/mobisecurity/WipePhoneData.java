package com.micro.mobisecurity;



import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import android.R.string;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Contacts.People;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.util.Log;

public class WipePhoneData extends Activity

{
	File BlockStart=new File("data/data/com.micro.mobisecurity/block");
	File SirenStart=new File("data/data/com.micro.mobisecurity/sirendone");
	String strLine1;
	public String SenderId="",Ccnumber,fullString,ThirdPartyNo,observerNo,MsgBody;
	File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	public int count;
	public String Num;
	public int count1;
	@SuppressWarnings("static-access")
	@Override
	 
	public void onCreate(Bundle savedInstanceState)
	{
	
	        super.onCreate(savedInstanceState);
	        
	        System.out.println("@@@@@ Delete Contact @@@@@");
	        if(BlockStart.exists() || SirenStart.exists())
	        {
	        	 if(Cc.exists())
	 	    	{
	 	    	ReadIncSmsFile();
	 	    	}
	 	   
	 	        Deletecontact();
	 	        System.out.println("@@@@@ after Delete Contact @@@@@");
	 	       WipingSDcard();
	 	      System.out.println("@@@@@ after wipwe sd card @@@@@");
	 	     CountLog();
		        
		        DeleteLogs();
		        wipeSMS();
		        SmsReceiver sr=new SmsReceiver();
	 	        
	 	        Num=sr.back();
	 	        if(Num.startsWith("TD") || Num.startsWith("LM")|| Num.startsWith("VN")|| Num.startsWith("DM")|| Num.startsWith("TM"))
	 	        {
	 	        	//Wipe;
	 	        	try
	 	        	{
	 	        	//SendMultiPartSms("+919223187878","M2MWipe;");
	 	        	}
	 	        	catch(Exception e)
	 	        	{
	 	        		System.out.println(e);
	 	        	}
	 	        }
	 	        else
	 	        {
	 	        	try
	 	        	{
	 	        System.out.println("...........Number to send sms is......."+Num);
	 	        
	 	        SendMultiPartSms(Num,"Mobi Security - Your Messages,Contacts,Logs,Images,video's deleted successfully. & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	 	        
	 	 	    finish();
	 	        	}
	 	        	catch(Exception e)
	 	        	{
	 	        		System.out.println(e);
	 	        	}
	 	        }
	        }
	        else
	        {
	        moveTaskToBack(true);
	      
	        if(Cc.exists())
	    	{
	    	ReadIncSmsFile();
	    	}
	        Deletecontact();
	        System.out.println("@@@@@ after Delete Contact @@@@@");
	        WipingSDcard();
	 	      System.out.println("@@@@@ after wipwe sd card @@@@@");
	 	     CountLog();
		        
		        DeleteLogs();
		        wipeSMS(); 
		        SmsReceiver sr=new SmsReceiver();
	 	        
	 	        Num=sr.back();
	 	        if(Num.startsWith("TD") || Num.startsWith("LM")|| Num.startsWith("VN")|| Num.startsWith("DM")|| Num.startsWith("TM"))
	 	        {
	 	        	//Wipe;
	 	        	try
	 	        	{
	 	        	//SendMultiPartSms("+919223187878","M2MWipe;");
	 	        	}
	 	        	catch(Exception e)
	 	        	{
	 	        		System.out.println(e);
	 	        	}
	 	        }
	 	        else
	 	        {
	 	        	try
	 	        	{
	 	        System.out.println("...........Number to send sms is......."+Num);
	 	        
	 	        SendMultiPartSms(Num,"Mobi Security - Your Messages,Contacts,Logs,Images,video's deleted successfully. & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	 	        
	 	 	    finish();
	 	        	}
	 	        	catch(Exception e)
	 	        	{
	 	        		System.out.println(e);
	 	        	}
	 	        }
	        }
	 }
	   
   
	  private void Deletecontact() {
		// TODO Auto-generated method stub
		  ContentResolver cr = getContentResolver();
	        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
	                null, null, null, null);
	        while (cur.moveToNext()) {
	            try{
	            	 count++;
	                String lookupKey = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));
	                Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey);
	                System.out.println("The uri is " + uri.toString());
	                cr.delete(uri, null, null);
	            }
	            catch(Exception e)
	            {
	                System.out.println(e.getStackTrace());
	            }
	        }
	}


	public void ReadIncSmsFile()
	    {
			SenderId=SmsReceiver.IncommingNumber;
			
			try
			 {
				//File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
				 System.out.println("ReadIncSmsFile 1");
				 byte[] strL=new byte[102400];
				 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/IncommingSms");
				 int strLine=0;
				 	
				 while ((strLine =fstream.read(strL)) != -1)
				
				 {
					
					 System.out.println (strLine);
					 strLine1 =new String(strL,0,strLine);
					 
					 strLine1 += " ~Received From "+ SenderId;
					 
					 System.out.println("***** Rec complete ********"+strLine1);
					 
				 }
				 
				 readCcFile();
				 
				 if(!SenderId.equals(Ccnumber))
				 {
					 try{
						 
					
				 SendMultiPartSms(Ccnumber,strLine1);
					 }
					 catch(Exception e)
					 {
						 
					 }
				 }
				 else
				 {
					 finish();
				 }

				
				 
				 // finish();
			  }
			  catch (IOException ioe)
			  {
				  ioe.printStackTrace(); 
			  }

	    }
		public void readCcFile() {
			try {
				FileInputStream fstream = new FileInputStream(
						"data/data/com.micro.mobisecurity/CarbonCopy");

				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in),8192);
				String strLine;
				while ((strLine = br.readLine()) != null) {

					Ccnumber = strLine.toString();
				}
				in.close();

				
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		public void SendMultiPartSms(String add,String msgbdy)
		{
			
	    	SmsManager smsManager = SmsManager.getDefault();
	    	
	        String destAddr = add, scAddr = null, mMessageText =msgbdy;
	        
	        System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
	        
	        PendingIntent sentIntent = null, deliveryIntent = null;
	        
	        try 
	        {
	        	
	        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
	        	
	        	
	        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

	        
	        	

	        for (int i=0; i < messages.size(); i++)
	        {

	        	
	        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
		        listOfIntents.add(pi);
	        }
	        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
	        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

	        } catch (Exception e) 
	        {
	        Log.i("TEST", e.toString());
	        }
	    
		}
		public void WipingSDcard() 
		{
		    File deleteMatchingFile = new File(Environment.getExternalStorageDirectory().toString());
		    System.out.println("M1");
		    try {
		        File[] filenames = deleteMatchingFile.listFiles();
		        System.out.println("M2");
		        if (filenames != null && filenames.length > 0)
		        {
		            for (File tempFile : filenames) 
		            {
		                if (tempFile.isDirectory()) 
		                {
		                	
		                	System.out.println("M3");
		                	WipeDirectory(tempFile.toString());
		                    tempFile.delete();
		                    
		                } 
		                else 
		                {
		                	System.out.println("M4");
		                	tempFile.delete();
		                }
		            }
		        } 
		        else 
		        {
		        	System.out.println("M5");
		        	deleteMatchingFile.delete();
		        }
		    } 
		    catch (Exception e) 
		    {
		    	System.out.println("M6");
		    	e.printStackTrace();
		    }
		}

		private void WipeDirectory(String name) 
		{
			System.out.println("M7");
			File directoryFile = new File(name);
			System.out.println("M8");
			File[] filenames = directoryFile.listFiles();
			System.out.println("M9");
			if (filenames != null && filenames.length > 0) 
			
			{
				System.out.println("M10");
				for (File tempFile : filenames) 
				{
		            if (tempFile.isDirectory()) 
		            {
		            	System.out.println("M11");
		            	WipeDirectory(tempFile.toString());
		                tempFile.delete();
		                System.out.println("M12");
		            } else 
		            {
		            	System.out.println("M13");
		            	tempFile.delete();
		            }
		        }
		    } 
			else 
			{
				System.out.println("M14");
				directoryFile.delete();
		    }
		}
		public void CountLog() 
		{

			 Uri uri1 = Uri.parse("content://call_log/calls"); 
			 Cursor c = WipePhoneData.this.getContentResolver().query(uri1, null, null, null, null);
			 
			 if (c.getCount()<=0) 

	        { 

				 System.out.println("@@@@@ Call log empty @@@@@");
				  

	            

	         }
			   while(c.moveToNext())
			   {
				   
				   count1++;
			   }
			
			
		}
		
		public void DeleteLogs() 
		{
			Uri uri = Uri.parse("content://call_log/calls"); 
			
			 if (uri == null) 
			 {  
	           //  Toast.makeText(CallogActivity .this, "Please create a contact by clicking create button, then I can delete the same", Toast.LENGTH_LONG).show();
	             
	 	     } 
	         else 
	         { 

	        	 getContentResolver().delete(uri, null, null);
	         }
			 
		}
		public void wipeSMS() 
		{
			Uri uri = Uri.parse("content://sms");

			ContentResolver contentResolver = getContentResolver();

			Cursor cursor = contentResolver.query(uri, null, null, null,
			  null);



			while (cursor.moveToNext()) {

			 long thread_id = cursor.getLong(1);
			 Uri thread = Uri.parse("content://sms/conversations/"
			   + thread_id);
			 getContentResolver().delete(thread, null, null);
			}

			
			
		}
}
