package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SirenBlock1 extends Activity implements OnClickListener{

    @SuppressWarnings("unused")
	private boolean mHomeDown;
    @SuppressWarnings("unused")
	private boolean mBackDown;
    @SuppressWarnings("unused")
	private boolean mEndCallDown;
    @SuppressWarnings("unused")
	private boolean mCallDown;
    @SuppressWarnings("unused")
	private boolean mVolumeDown;
    @SuppressWarnings("unused")
	private boolean mCameraDown;
    @SuppressWarnings("unused")
	private boolean mVolumeUP;
    @SuppressWarnings("unused")
	private boolean mPowerButton;
    //mPowerButton
	File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
    
	String Lockmsg;
	public MediaPlayer mp=null;
	    
	Bundle savedInstanceState;
    private static final String TAG = "SavedInstace";
    //File UnblockFile=new File("data/data/com.micro.android.phoneblock/UNBLOCK");
    File SirenStart=new File("data/data/com.micro.mobisecurity/sirendone");
    TextView CustomMessageByUser;
	String ReadLockMsgFrmFile,newlckmsg;
	
    Button Ok;
    Button ForgotPIN;
	EditText enterPIN;
    KeyEvent event;
    public String fullString;
    public String ep;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //moveTaskToBack(true);
        System.out.println("@@@@@@@@@@ MDsuccess1");
        
        //To Create Full Screen Activity
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        System.out.println("@@@@@@@@@@ MDsuccess2");
        
  setContentView(R.layout.enterunblockpass);
        
        Ok = (Button)this.findViewById(R.id.unblockButton);
        Ok.setOnClickListener(this);
       // ForgotPIN = (Button)this.findViewById(R.id.cancel);

        enterPIN = (EditText)this.findViewById(R.id.EditPinKey);
        
        
       // CustomMessageByUser=(TextView)findViewById(R.id.CustomMessage);
       // CustomMessageByUser.setText("Phone is Locked");
 CustomMessageByUser=(TextView)findViewById(R.id.CustomMessage); 
        
        
    	try
		 {
    		Lockmsg=PreferenceExample.sharedPrefs.getString("Name", "NULL");
    		//Lockmsg=PreferenceExample.sDefaultTipPercent;
   
		 }
    	catch (Exception ioe)
		  {
			  ioe.printStackTrace(); 
		  }
        
       if (Lockmsg == null)
       {
    	   System.out.println("!!!!!!!!!!!!!!!! Lockmsg == null");
    	   CustomMessageByUser.setText("Message to be displayed on the locked screen");
       }
       else
       {
    	   
    	   CustomMessageByUser.setText(Lockmsg);
       }
        System.out.println("inside oncreate onlyBlock");
        
    
        
        System.out.println("value of newlckmsg is "+Lockmsg);
           
        System.out.println("........Keyguard is enbled");
        System.out.println(".........phone is locked");
       KeyguardManager mgr = (KeyguardManager)getSystemService(Activity.KEYGUARD_SERVICE); 
        KeyguardLock lock = mgr.newKeyguardLock(KEYGUARD_SERVICE); 
        lock.disableKeyguard();
      
     
    }
    @Override
    public void onBackPressed() {
       return;
    }
    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);           
    }
   
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_SEARCH) {
            return true;
        }
        else if (keyCode == KeyEvent.KEYCODE_POWER) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) 
    {
	 
    	System.out.println("............In dispatch keyevent");
        if (event.getAction() == KeyEvent.ACTION_DOWN) 
        {
            switch (event.getKeyCode()) 
            {
                case KeyEvent.KEYCODE_BACK:
                    mBackDown = true;
                    return true;
                case KeyEvent.KEYCODE_HOME:
                    mHomeDown = true;
                    return true;
                case KeyEvent.KEYCODE_CALL:
                	mCallDown= true;
                	return true;
                case KeyEvent.KEYCODE_ENDCALL:
                	mEndCallDown= true;
                	return true;
                case KeyEvent.KEYCODE_VOLUME_DOWN: 
                	mVolumeDown= true;
                	return true;
                case KeyEvent.KEYCODE_VOLUME_UP: 
                	mVolumeUP= true;
                	return true;
                case KeyEvent.KEYCODE_POWER:
                	mPowerButton=true; 	
                	return true;
                case KeyEvent.KEYCODE_CAMERA:
                	mCameraDown=true;
                	return true;
            }
        }
        
        return super.dispatchKeyEvent(event);
    }
    
   @Override
	public void onClick(View v) {
		
		System.out.println("........Inside onclick unblock");
		// TODO Auto-generated method stub
	
		if(v==Ok)
		{
			
			   
			readPINFile();
			
			 ep = enterPIN.getText().toString();
			 
			 
			 System.out.println("........"+fullString);
			 System.out.println("........"+ep);
			 
			 
			 if(ep.equals(fullString))
			 {
			
				 System.out.println(".....STRING COMPARED.......");
			
				 
				 SirenStart.delete();
	        
	        if (mp!=null)
	        { 
	        	System.out.println(".....mp!=null 1");
	        	mp.stop();
	 		System.out.println(".....mp!=null 2");
	 		mp.release();
	 		System.out.println(".....mp!=null 3");
	        mp = null;
	        System.out.println(".....mp!=null 4");
			moveTaskToBack(true);
			System.out.println(".....mp!=null 5");
			//onDestroy();
	        }
	        
	        System.out.println(".............User click on ok");
            moveTaskToBack(true);
   			//finish();
   			this.finish();
   			
   			System.exit(0);
   			Intent startMain = new Intent(Intent.ACTION_MAIN);
		     startMain.addCategory(Intent.CATEGORY_HOME);
		     startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		     startActivity(startMain);
		     this.finish();
			
		   }
			else
			{
			   alertbox("Mobi Security","Invalid password");
			}
		}
		
		}
   

  
    
	
	

	
	 public void readPINFile()
	 {
		 try
		 {
			 System.out.println ("INSIDE THE READRECFILE");
			 FileInputStream fstream = new FileInputStream("data/data/com.Multipartsms.com/PIN");
			 System.out.println ("INSIDE THE READRECFILE2");	
			 DataInputStream in = new DataInputStream(fstream);
			 System.out.println ("INSIDE THE READRECFILE3");	
			 BufferedReader br = new BufferedReader(new InputStreamReader(in));
			 String strLine;
			 System.out.println ("INSIDE THE READRECFILE4");	
			 while ((strLine = br.readLine()) != null)
			 {
				 System.out.println (strLine);
				 fullString = strLine.toString();
			 }
		     in.close();
		     System.out.println ("Full String is:- " +fullString);
		    
		     
		  }
		  catch (IOException ioe)
		  {
			  ioe.printStackTrace(); 
		  }
	 }
	 protected void alertbox(String title, String mymessage)     
	 {
		 new AlertDialog.Builder(this)   
		.setMessage(mymessage)   
		//.setTitle(title)   
		.setCancelable(true)   
		.setNeutralButton(android.R.string.ok,   
		new DialogInterface.OnClickListener() {   
		public void onClick(DialogInterface dialog, int whichButton)
		{
			 Intent act1=new Intent(SirenBlock1.this,MDsuccess.class);
             startActivity(act1);
		}   
		})   
		.show();   
	}
	 
	 
	 public void playsound()
		{
			
			try
			{
				System.out.println("play song");
			
				AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
				audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
				    audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
				    AudioManager.FLAG_SHOW_UI);

	            mp = MediaPlayer.create(getBaseContext(),
	                    R.raw.war);
	            mp.start();

	        
	        mp.setOnCompletionListener(new OnCompletionListener() 
	        {
	        
	         
	        	  
	              public void onCompletion(MediaPlayer arg0) 
	              {
	        
	                  System.out.println("song complete");  
	                  arg0.release();
	            	  nextSong();
	        
	                                        
	              }
	              
	               
	              
	         }
	        );
		 }
			 catch (Exception ioe)
			 {
		  	 ioe.printStackTrace();
			 } 
	        
		}
		
		public void nextSong()
		{
	        System.out.println("next song"); 
	        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
	        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
	            audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
	            AudioManager.FLAG_SHOW_UI);

			MediaPlayer mp = MediaPlayer.create(getBaseContext(),
	                R.raw.war);
	        mp.start();
	        
	        playsound();
	        
			
		}
		
	/*	public void onDestroy()
		{
		        System.out.println("@@@@@@@ ondestroy 1");
		        super.onDestroy();
		        System.out.println("@@@@@@@ ondestroy 2");
		        finish();
		        System.out.println("@@@@@@@ ondestroy 3");
		        System.exit(0);
		        System.out.println("after exit");
		        
		        
		        
		        
		
		 }*/


}
