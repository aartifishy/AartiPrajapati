package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashSet;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Contacts.People; 
import android.text.format.DateUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ReadCalender extends Activity 
{
	String inputLine,str,wholeCalendar;
	//StringBuffer wholeSMS;
	String strLine,calendarStr;
	String sb ;
	String[] arr;
	String[]arr1;
	String from;
	String msg;
	String str1,str2,str3;
	
	Handler mHandler = new Handler();
	private int count=0;
	private static final int NOTIFY_ME_ID=1337;
	PrintWriter out1,out2;
	
	Button calendarbackup,calendarrestore;
	 Context c;
	 int size, calendarChunks,read12,calendarFileSize;
	 File calendarFile = new File("data/data/com.micro.mobisecurity/calendar.txt");
	 
	 File encodedcalendarFile = new File("data/data/com.micro.mobisecurity/encodedcalendar.txt");
	 
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
    	 System.out.println ("Inside onCreate ");
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.backuporrestoresms);
        System.out.println ("Inside onCreate of savedInstanceState");  
        //setContentView(R.layout.backuporrestorecalendar);
        System.out.println ("after calenderbackup layout");  
        //selectButton();
        System.out.println ("after selectbutton");  
        CalenDer();
    }
    
    public void selectButton()
    {
    	 System.out.println ("inside selectButton");
    	//calendarbackup = (Button)findViewById(R.id.backupcalendar_button);
    	System.out.println ("inside selectButton");
    	//calendarrestore = (Button)findViewById(R.id.restorecalendar_button); 
    	
         
    	//calendarbackup.setOnClickListener(this);
    	System.out.println ("after calenderbackup Button");
    	//calendarrestore.setOnClickListener(this);
    	System.out.println ("after calenderbackup Button"); 
         
    }
    
    public void CalenDer()
    {
    	System.out.println ("inside calenDer");
    	setContentView(R.layout.calendartoserver);
    	  System.out.println ("after calendartoserver layout");  
    	readCalender(c);
    	System.out.println ("after readCalendar");  
    	encodeCalender();
    	System.out.println ("after encodeCalendar");  
	   	calendarFileSize = (int)encodedcalendarFile.length();
	   	System.out.println ("calendarFileSize::"+calendarFileSize);  
	   	calendarChunks = (calendarFileSize/102400);
		System.out.println ("calenderChunks::"+calendarChunks);  
	   	calendarChunks = calendarChunks+1;	 
		System.out.println ("calendarChunks1::"+calendarChunks);	
	   	 Thread t = new Thread(){
	   		   public void run()
	   		   {	   			  				  
	   	 				sendData("157_C~calendar.txt~START~"+calendarChunks);
	   	 				System.out.println ("157_C~calender.txt~START~"+calendarChunks);
	   	  				System.out.println ("157_C~calender.txt~START~"+calendarChunks);
		  				
		  				
		  				sendcalenderFileToServer();
   			  			sendData("157_C~calendar.txt~END~"+calendarChunks);
   			  			System.out.println ("157_C~calendar.txt~END~"+calendarChunks);
   			  			
   			  			mHandler.post(new Runnable()
	   			  		{
	   			  		       public void run()
	   			  		       {
	   			  			            	setContentView(R.layout.calendarstoreonserver);
	   			  			            	notifyMe();
	   			  		         }
	   			  		  });
	   			  				 				   
	   			  	}
	   		};
	
	   		t.start(); 
   }
    
  
    
    
    private void notifyMe()
	{
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your Calendar are stored succesfully.", i);
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}
  
    public  void readCalender(Context context)
    {
		try
		{
			System.out.println("33333333333333333333333333");
			calendarFile.createNewFile();
			System.out.println("33333333333333333333333333");
			out1 = new PrintWriter(calendarFile);
			System.out.println("33333333333333333333333333");
    	String strUri="content://com.android.calendar/calendars";
    	//String strUri="content://calendar/calendars";
    	System.out.println("33333333333333333333333333");
        Uri uricalender=Uri.parse(strUri);
        System.out.println("33333333333333333333333333");
        Cursor c=this.getContentResolver().query(uricalender, null, null, null,null);
     // For a full list of available columns see http://tinyurl.com/yfbg76w
        System.out.println("33333333333333333333333333");
		//System.out.println ("*************"+c.getCount());
		HashSet<String> calendarIds = new HashSet<String>();
		System.out.println("33333333333333333333333333");
	    System.out.println ("Inside readacalendar() method");
		while(c.moveToNext()) 
        {System.out.println("33333333333333333333333333");
			final String _id = c.getString(0);
			System.out.println("33333333333333333333333333");
			final String displayName = c.getString(1);
			System.out.println("33333333333333333333333333");
			//final Boolean selected = !c.getString(2).equals("0");
			System.out.println("33333333333333333333333333");
			//System.out.println("Id: " + _id + " Display Name: " + displayName + " Selected: " + selected);
			System.out.println("33333333333333333333333333");
			calendarIds.add(_id);
			System.out.println("33333333333333333333333333");
              	       	        	        	
        }
		// For each calendar, display all the events from the previous week to the end of next week.		
		for (String id : calendarIds) {
			System.out.println("33333333333333333333333333");
			Uri.Builder builder = Uri.parse("content://com.android.calendar/instances/when").buildUpon();
			//Uri.Builder builder = Uri.parse("content://calendar/instances/when").buildUpon();
			System.out.println("33333333333333333333333333");
			long now = new Date().getTime();
			System.out.println("33333333333333333333333333");
			ContentUris.appendId(builder, now - DateUtils.WEEK_IN_MILLIS);
			System.out.println("33333333333333333333333333");
			ContentUris.appendId(builder, now + DateUtils.WEEK_IN_MILLIS);
			System.out.println("33333333333333333333333333");
			Cursor eventCursor = this.getContentResolver().query(builder.build(),
					new String[] { "title", "begin", "end", "allDay"}, "Calendars._id=" + id,
					null, "startDay ASC, startMinute ASC"); 
			System.out.println("33333333333333333333333333");
			// For a full list of available columns see http://tinyurl.com/yfbg76w

			while (eventCursor.moveToNext()) {
				System.out.println("33333333333333333333333333");
				final String title = eventCursor.getString(0);
				System.out.println("33333333333333333333333333");
				final Date begin = new Date(eventCursor.getLong(1));
				System.out.println("33333333333333333333333333");
				final Date end = new Date(eventCursor.getLong(2));
				System.out.println("33333333333333333333333333");
				final Boolean allDay = !eventCursor.getString(3).equals("0");
				System.out.println("33333333333333333333333333");
				//final String location = eventCursor.getString(4);
				System.out.println("33333333333333333333333333");
				//out1.println("BEGIN:VCALENDAR"); 
				//out1.println("VERSION:1.0"); 
				//out1.println("BEGIN:VEVENT"); 
				//out1.println("X-OBJECTTYPE:APPOINTMENT"); 
				//out1.println("TITLE:"+title); 
				out1.println("BEGIN:VCALENDAR\r\nVERSION:1.0\r\nBEGIN:VEVENT\r\nX-OBJECTTYPE:APPOINTMENT\r\nTITLE:"+title+"\r\nDTEND:"+end+"\r\nDTSTART:"+begin+"\r\nALL DAY:"+allDay+"\r\nEND:VEVENT\r\nEND:VCALENDAR"); 
				//out1.println("Begin:"+ begin); 
				//out1.println("CHARSET=UTF-8:"); 
				//out1.println("ENCODING=QUOTED-PRINTABLE:Meeting"); 
				//out1.println("DTEND:"+ end);
				//out1.println("DTSTART:"+ begin);
				//out1.println("ALL DAY:"+allDay);
				//out1.println("LOCATION:Mumbai"); 
				//out1.println("SUMMERY:Sangram Pawar"); 
				 
				
				//out1.println("END:VEVENT");
				//out1.println("END:VCALENDAR");
						//" VERSION:1.0"+title.trim()+"�"+begin+"�"+end+"�"+allDay+"~~");END:VEVENT
				System.out.println("Title: " + title + " Begin: " + begin + " End: " + end + 	" All Day: " + allDay);
			}
		}
		out1.flush();
		out1.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	     
    }
    
 
    
    
    public void encodeCalender()
 	{
    	
 		try
		{
 			encodedcalendarFile.createNewFile();
 			PrintWriter out12 = new PrintWriter(encodedcalendarFile);
 			
			InputStream inputStream =  new FileInputStream (calendarFile);
					
			byte[] b = new byte[1023];
			while((read12 = inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out12.print(encoded);			
				out12.flush();	
				System.out.println ("After flushing");
							
			}
			out12.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
 	}
    
   
    
    public void sendcalenderFileToServer()
    {
    	System.out.println ("Inside sendSMSFileToServer()");
    	try
    	{
    		
   		 	System.out.println ("Required chunks are"+calendarChunks);
    		byte[] byteArray = new byte[102400];
    		 FileInputStream fstream = new FileInputStream(encodedcalendarFile);
    		 int bytesRead = 0;
     		 while((bytesRead = fstream.read(byteArray)) != -1)
     		 {  
     			 calendarStr = new String(byteArray,0,bytesRead);  
     			 sendData("157_C~calendar.txt~"+calendarChunks+"~"+calendarStr);
     			 System.out.println ("#######################################");
     			 System.out.println (calendarStr);
     		 }
    	 }
        catch (IOException ioe)
        {
       	 ioe.printStackTrace(); 
        }
    		
    }
    
  
           
    public void sendData(String line)
    {
    	try
    	{
    		
    		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/DumpData.aspx");
    		
    		
    		// connectURL is a URL object
    		System.out.println ("After heating url");
    		
    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
    		// allow inputs 
    		conn.setDoInput(true); 
    		
    		// allow outputs 
    		conn.setDoOutput(true); 
    		
    		// don't use a cached copy 
    		conn.setUseCaches(false); 
    		
    		// use a post method 
    		conn.setRequestMethod("POST"); 
    		
    		// set post headers 
    		conn.setRequestProperty("Connection","Keep-Alive"); 
    		   		
    		// open data output stream 
    		OutputStream dos ; 
    		
    		dos=conn.getOutputStream();
    		
    		System.out.println ("Before if statement");
    		
    			byte[] arr = line.getBytes();
    		
    			System.out.println ("arr auccesfully created"+arr.length);
    	      	    
    			dos.write(arr);
    	    
    			System.out.println ("write to the page");
    		    	   	   		
    		System.out.println ("After if statement");
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 	    		
	    		b.append( (char)ch);
	    		   
	    	} 
	    	String s=b.toString(); 
	    	System.out.println (s);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
	    	
    	} 
    	catch (MalformedURLException ex)
    	{ 
    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	}

    }
         
    
   /* public void onClick(View v)
    {
    	
    	
    	if (v==calendarbackup)
    	{
    		CalenDer();
  		    		
    	}
    	else if (v==calendarrestore)
    	{
    		Intent contactIntent = new Intent(this,ReadCalender.class);
			startActivity(contactIntent);
  		    		
    	}
    		
    }*/

}