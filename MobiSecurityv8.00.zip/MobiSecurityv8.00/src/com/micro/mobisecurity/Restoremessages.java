package com.micro.mobisecurity;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class Restoremessages extends Activity implements OnClickListener
{
	String inputLine,str,wholeSMS;
	//StringBuffer wholeSMS;
	String strLine;
	String sb ;
	String[] arr;
	String[]arr1;
	String from;
	String msg,imei;
	String str1,str2,str3;
	File smsFile = new File("data/data/com.micro.mobisecurity/smsFile.txt");
	Handler mHandler = new Handler();
	private int count=0;
	private static final int NOTIFY_ME_ID=1337;
	
	ImageButton inboxRestore,sentboxRestore;
	 Context c;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // Request the progress bar to be shown in the title
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setProgress(10000); // Turn it off for now
        setContentView(R.layout.inboxorsentbackupsms);
        System.out.println ("Inside onCreate of ReadSMS");  
        calCulateIMEI();
       /* selectButton();
        System.out.println ("after select button");  */
        inboxRestore = (ImageButton)findViewById(R.id.inboxbackupsms_button);
        System.out.println ("Inside onCreate of ReadSMS 1");  
   	 sentboxRestore =  (ImageButton)findViewById(R.id.outboxbackupsms_button);
     System.out.println ("Inside onCreate of ReadSMS 2");   
   	 inboxRestore.setOnClickListener(this);
     System.out.println ("Inside onCreate of ReadSMS 3");  
     sentboxRestore.setOnClickListener(this);
     System.out.println ("Inside onCreate of ReadSMS 4"); 
    }
    
    private void calCulateIMEI() {
		// TODO Auto-generated method stub
    	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	}
    public void onClick(View v)
    {
    	
    	
    	if (v==inboxRestore)
    	{
    		//setContentView(R.layout.smstoserver);
    		//setContentView(R.layout.inboxorsentbackupsms);
    		//selectInboxOrSentboxRestore();
    		System.out.println ("User click on intboxRestore button");
				setContentView(R.layout.smsfromserver);
				Thread t = new Thread(){
			   public void run()
			   {
				   	readWebPage();
	        	System.out.println ("After restore sms"); 
	        	//System.out.println ("????????????????"+inputLine.length());
	        	writeSMSToFile();
	        	readSMSFromFile();
	        	mHandler.post(new Runnable() {
			            public void run()
			            {
			            	setContentView(R.layout.smsrestorestoreonphone);
			            	smsFile.delete();
			           	    notifyMe();
			            }
			    	});
				 				   
			   }
			};

			t.start(); 
    		
    			 
    		
    		
    	}
    	else if (v==sentboxRestore)
    	{
    		//setContentView(R.layout.smsfromserver);
    		//setContentView(R.layout.inboxorsentrestoresms);
    		//selectInboxOrSentboxRestore();
    		System.out.println ("User click on intboxRestore button");
				setContentView(R.layout.smsfromserver);
				Thread t = new Thread(){
			   public void run()
			   {
				   	readWebPage1();
	        	System.out.println ("After restore sms"); 
	        	//System.out.println ("????????????????"+inputLine.length());
	        	writeSMSToFile();
	        	readSMSFromFile();
	        	mHandler.post(new Runnable() {
			            public void run()
			            {
			            	setContentView(R.layout.smsoutboxrestorestoreonphone);
			            	smsFile.delete();
			             	notifyMe();
			            }
			    	});
				 				   
			   }
			};

			t.start(); 
    	}
    		
    }
 
    
    
    private void notifyMe()
	{
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your SMS are restored succesfully", i);
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}
    
    
 
    
    
      
    
    
    public void restoreSMS(String from, String message)
    {
    	ContentValues values = new ContentValues();
    	values.put("address", from);
    	values.put("body", message);
    	getContentResolver().insert(Uri.parse("content://sms/inbox"), values);
    	System.out.println ("Inside restoreSMS method");

    }
    
    public void readWebPage()
    {
    	System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%Inside readWebPage method");
    	   try { 
    		   //http://www.microlifeline.net/new/users/ Licencekey/masterlist.txt
               //URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/Backup_1%5Caddressbook.txt");
    		   URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/Backup_1%5Cinbox.txt");
               BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream())); 
               DataInputStream dis=new DataInputStream(yahoo.openStream());
               System.out.println("Data Input Stream Data--"+dis.readLine());
               System.out.println ("Before while");
               while ((inputLine = in.readLine()) != null) 
               
               { 
            	   
            	   System.out.println ("Inside while");
            	   System.out.println(inputLine); 
            	   wholeSMS=wholeSMS+inputLine;
            	   
               } 
             
               System.out.println ("####################"+wholeSMS.length());
               System.out.println ("####################"+wholeSMS);
               in.close(); 
           } catch (MalformedURLException me) { 
               System.out.println(me); 
       
           } catch (IOException ioe) {  
               System.out.println(ioe); 
           }  

    }
    public void readWebPage1()
    {
    	System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%Inside readWebPage method");
    	   try { 
    		   //http://www.microlifeline.net/new/users/ Licencekey/masterlist.txt
               //URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/Backup_1%5Caddressbook.txt");
    		   URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/Backup_1%5Csent.txt");
               BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream())); 
               
               System.out.println ("Before while");
               while ((inputLine = in.readLine()) != null) 
               
               { 
            	   System.out.println ("Inside while");
            	   System.out.println(inputLine); 
            	   wholeSMS=wholeSMS+inputLine;
            	   
               } 
             
               System.out.println ("####################"+wholeSMS.length());
               System.out.println ("####################"+wholeSMS);
               in.close(); 
           } catch (MalformedURLException me) { 
               System.out.println(me); 
       
           } catch (IOException ioe) {  
               System.out.println(ioe); 
           }  

    }
    public void writeSMSToFile() 
    {
    	try
    	{
    		smsFile.createNewFile();
    		System.out.println ("Inside writeSMSToFile");
    		PrintWriter out = new PrintWriter(smsFile);
    		System.out.println ("After crating PrintWriter object");
    		System.out.println ("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"+wholeSMS);
    		out.write(wholeSMS);
    		out.flush();
    		out.close();
    	}
    	catch (IOException ioe)
    	{
    		ioe.printStackTrace();
    	}
    	 
    	
    }
    
    public void readSMSFromFile()
    {
    
    	
    	try
		{
    			System.out.println ("Inside try block of readSMSFromFile method");
				FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/smsFile.txt");
		
    			DataInputStream in = new DataInputStream(fstream);
        		BufferedReader br = new BufferedReader(new InputStreamReader(in));
        		System.out.println ("Before while");
        		while ((strLine = br.readLine()) != null)
    			{
        			System.out.println ("***************************************");
    				System.out.println (strLine);
    				str = strLine.toString(); 
    				    				    				
    			}
        	      		
        		System.out.println ("outside of while");
        		System.out.println (str);
        		arr = str.split("~~");  
        		System.out.println (arr[0]);
        		for (int i =0;i<arr.length-1;i++)
        		{
        			System.out.println ("......................1");
        			str1 = arr[i];
        			//restoreSMS(str1.substring(0,str1.indexOf("�")),str1.substring(str1.indexOf("�")+1,str1.length()));
        			System.out.println ("......................2"+str1);
        			arr1 = str1.split("�");
        			System.out.println ("......................2"+arr1);
        			str2 = arr1[0];
        			System.out.println ("......................2"+str2);
        			str3 = arr1[1];
        			System.out.println ("......................2"+str3);
        			System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!");
        			System.out.println (str2);		
        			System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!");
        			System.out.println (str3); 
        			restoreSMS(str2,str3);
        		}
        		/*arr = str.split(")))");  
        		System.out.println ("After split with ### now size of arr is"+arr.length);
        		System.out.println (str); 
       			 			
       			for (int i=0;i<arr.length-1;i++)
       			{
       				System.out.println ("Inside for loop of split");
       				str1= arr[i];
       				String[] arr2 = str1.split("(((");
       				from = arr2[0];
       				System.out.println ("$$$$$$$$$$"+from);
       				msg = arr2[1];
       				System.out.println ("$$$$$$$$$$"+msg);
       				resroreSMS(from,msg);
       			}*/
       			in.close();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
    }
    
 
    
 

}