package com.micro.mobisecurity;
/* <!-- 
* Copyright (C) 2009 AlmondMendoza
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
-->
*/

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class Main extends Activity { 
        private TextView contentTxt;
        
        private BroadcastReceiver mBatInfoReceiver = new BroadcastReceiver(){
                @Override
                public void onReceive(Context context, Intent intent) {
                        // TODO Auto-generated method stub
                        int level = intent.getIntExtra("level", 0);
            int scale = intent.getIntExtra("scale", 100);
                        contentTxt.setText(String.valueOf(level * 100 / scale) + "%");
                        boolean isPresent = intent.getBooleanExtra("present", false);
                        String technology = intent.getStringExtra("technology");
                        int plugged = intent.getIntExtra("plugged", -1);
                       // int scale = intent.getIntExtra("scale", -1);
                        int health = intent.getIntExtra("health", 0);
                        int status = intent.getIntExtra("status", 0);
                        int rawlevel = intent.getIntExtra("level", -1);
            //int level = 0;
           
            Bundle bundle = intent.getExtras();
           
            Log.i("BatteryLevel", bundle.toString());
           
            if(isPresent)
            {
                    if (rawlevel >= 0 && scale > 0) {
                        level = (rawlevel * 100) / scale;
                    }
                   
                    String info = "\n\n\nBattery Level: " + level + "%\n";
                   
                    info += ("Technology: " + technology + "\n");
                    info += ("Plugged: " + getPlugTypeString(plugged) + "\n");
                    info += ("Health: " + getHealthString(health) + "\n");
                    info += ("Status: " + getStatusString(status) + "\n");
                   
                    setBatteryLevelText(info);
            }
            else
            {
                setBatteryLevelText("Battery not present!!!");
            }
                }
                private String getPlugTypeString(int plugged){
                    String plugType = "Unknown";
                   
                    switch(plugged)
                    {
                            case BatteryManager.BATTERY_PLUGGED_AC: plugType = "AC";        break;
                            case BatteryManager.BATTERY_PLUGGED_USB: plugType = "USB";      break;
                    }
                   
                    return plugType;
            }
           
            private String getHealthString(int health)
            {
                    String healthString = "Unknown";
                   
                    switch(health)
                    {
                            case BatteryManager.BATTERY_HEALTH_DEAD: healthString = "Dead"; break;
                            case BatteryManager.BATTERY_HEALTH_GOOD: healthString = "Good"; break;
                            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: healthString = "Over Voltage"; break;
                            case BatteryManager.BATTERY_HEALTH_OVERHEAT: healthString = "Over Heat"; break;
                            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: healthString = "Failure"; break;
                    }
                   
                    return healthString;
            }
           
            private String getStatusString(int status)
            {
                    String statusString = "Unknown";
                   
                    switch(status)
                    {
                            case BatteryManager.BATTERY_STATUS_CHARGING: statusString = "Charging"; break;
                            case BatteryManager.BATTERY_STATUS_DISCHARGING: statusString = "Discharging"; break;
                            case BatteryManager.BATTERY_STATUS_FULL: statusString = "Full"; break;
                            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: statusString = "Not Charging"; break;
                    }
                   
                    return statusString;
            }
           
            private void setBatteryLevelText(String text){
            	contentTxt.setText(text);
            }
           
            private void registerBatteryLevelReceiver(){
                    IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                   
            registerReceiver(mBatInfoReceiver, filter);
            }
        };
        
        
        @Override 
        public void onCreate(Bundle icicle) { 
            super.onCreate(icicle); 
            setContentView(R.layout.batthighinfo);
            contentTxt = (TextView) this.findViewById(R.id.batterylevel_text);
            this.registerReceiver(this.mBatInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            //IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            //registerReceiver(mBatInfoReceiver, filter);
           // registerBatteryLevelReceiver();
           /* setContentView(R.layout.batthighinfo);
            
            textBatteryLevel = (TextView)findViewById(R.id.batterylevel_text);
           
            registerBatteryLevelReceiver();
            
            
            PrefsActivity.connectToBatteryService(getBaseContext());
            PrefsActivity.setAppLanguage(getBaseContext());
        }
        
      /*  @Override
        public boolean onPrepareOptionsMenu(Menu menu) {
                menu.clear();
                menu.add(0,R.string.preferences,0,R.string.preferences).setIcon(R.drawable.mobisecurityicon);
                menu.add(1,R.string.buy_battery,1,R.string.buy_battery).setIcon(R.drawable.mobisecurityicon);
                menu.add(1,R.string.about_app,1,R.string.about_app).setIcon(R.drawable.mobisecurityicon);
                return super.onPrepareOptionsMenu(menu);
        }*/


       /* @Override
        public boolean onOptionsItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                        case R.string.preferences:
                                startActivity(new Intent(this,PrefsActivity.class));
                                return (true);
                case R.string.buy_battery: 
                        String url = "http://www.amazon.com/gp/search?ie=UTF8&keywords=android%20"+Build.DEVICE+"%20battery&tag=monmonja05-20&index=blended&linkCode=ur2&camp=1789&creative=9325";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
                case R.string.about_app: 
                        String urlAbout = "http://almondmendoza.com/android-applications/";
                Intent aboutIntent = new Intent(Intent.ACTION_VIEW);
                aboutIntent.setData(Uri.parse(urlAbout));
                startActivity(aboutIntent);
                break;
                
                }
                // TODO Auto-generated method stub
                return super.onOptionsItemSelected(item);
        }*/
        }
}
