package com.micro.mobisecurity;


import java.io.File;

import android.content.Context; 
import android.content.Intent; 
import android.content.BroadcastReceiver; 

public class MyStartupIntentReceiver1 extends BroadcastReceiver
{ 
String pinString;
File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
     @Override 
     public void onReceive(Context context, Intent intent)
     { 

			if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL))
	        {
				if(PinFile.exists())
				{
				MDsuccess ms =new MDsuccess();
				ms.readPINFile();
				pinString=ms.fullString;
				System.out.println("pinString::"+pinString);
				 /*String number = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
				 if (number.equals("000"))*/
				if (intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER).equals(pinString))
	     	   	 {
					setResultData(null);
		            abortBroadcast();
	
          /* Create intent which will finally start the Main-Activity. */ 
          Intent myStarterIntent = new Intent(context,Firstpage.class); 
          /* Set the Launch-Flag to the Intent. */ 
          //myStarterIntent.setLaunchFlags(Intent.NEW_TASK_LAUNCH);
          myStarterIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 

          /* Send the Intent to the OS. */ 
          context.startActivity(myStarterIntent); 
          //context.startService(myStarterIntent);
	     	   	 }
	        }
				
	        }
     }  
} 
