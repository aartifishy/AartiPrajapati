package com.micro.mobisecurity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MyStartupIntentReceiver extends BroadcastReceiver
{ 

     @Override 
     public void onReceive(Context context, Intent intent)
     { 
    	/* Intent i = new Intent(Intent.ACTION_MAIN);
    	 i.addCategory(Intent.CATEGORY_MAIN);*/

          //Intent myStarterIntent = new Intent(context,MicroScout.class); 
    	 Intent myStarterIntent = new Intent(context,LMTScheckSIM.class);
    	 
          myStarterIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 


          context.startActivity(myStarterIntent); 
   
     }  
} 