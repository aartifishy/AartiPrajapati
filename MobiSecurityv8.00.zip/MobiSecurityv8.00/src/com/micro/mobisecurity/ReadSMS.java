package com.micro.mobisecurity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class ReadSMS extends Activity implements OnClickListener
{
	String inputLine,str,wholeSMS;
	//StringBuffer wholeSMS;
	String strLine,inboxStr,sentboxStr;
	String sb ;
	String[] arr;
	String[]arr1;
	String from;
	String msg,imei;
	String str1,str2,str3;
	
	Handler mHandler = new Handler();
	private int count=0;
	private static final int NOTIFY_ME_ID=1337;
	PrintWriter out1,out2;
	
	ImageButton inboxbackup,sentboxbackup,restore,inboxBackup,sentboxBackup,inboxRestore,sentboxRestore;
	 Context c;
	 char delimiter='�';
	 int size, inboxChunks,read12,sentboxChunks,read21,inboxFileSize,sentFileSize;
	 File inboxFile = new File("data/data/com.micro.mobisecurity/inbox.txt");
	 File sentboxFile = new File("data/data/com.micro.mobisecurity/sentbox.txt");
	 File encodedinboxFile = new File("data/data/com.micro.mobisecurity/encodedinbox");
	 File encodedsentboxFile = new File("data/data/com.micro.mobisecurity/encodedsentbox");
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.backuporrestoresms);
        // Request the progress bar to be shown in the title
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setProgress(10000); // Turn it off for now
        setContentView(R.layout.inboxorsentbackupsms);
        System.out.println ("Inside onCreate of ReadSMS");  
        calCulateIMEI();
        selectButton();
       
    }
    
    public void selectButton()
    {
    	 inboxbackup = (ImageButton)findViewById(R.id.inboxbackupsms_button);
    	 sentboxbackup = (ImageButton)findViewById(R.id.outboxbackupsms_button);
    	
         
         inboxbackup.setOnClickListener(this);
         sentboxbackup.setOnClickListener(this);
         
    }
    private void calCulateIMEI() {
		// TODO Auto-generated method stub
    	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	}
    public void inBox()
    {
    	setContentView(R.layout.smstoserver); 
    	readInboxSMS(c);
    	encodeInbox();
	   	inboxFileSize = (int)encodedinboxFile.length();
	   	inboxChunks = (inboxFileSize/102400);
	   	inboxChunks = inboxChunks+1;	 
			
	   	 Thread t = new Thread(){
	   		   public void run()
	   		   {	   			  				  
	   	 			 	sendData(imei+"_I~inbox.txt~START~"+inboxChunks);
	   	 				System.out.println (imei+"_I~inbox.txt~START~"+inboxChunks);
	   	  				System.out.println (imei+"_I~inbox.txt~START~"+inboxChunks);
		  				
		  				
		  				sendinboxFileToServer();
   			  			sendData(imei+"_I~inbox.txt~END~"+inboxChunks);
   			  			System.out.println (imei+"_I~inbox.txt~END~"+inboxChunks);
   			  			
   			  			mHandler.post(new Runnable()
	   			  		{
	   			  		       public void run()
	   			  		       {
	   			  			            	setContentView(R.layout.smsstoreonserver);
	   			  			           inboxFile.delete();
	 	   			  			      sentboxFile.delete();
	 	   			  			 encodedinboxFile.delete();
	 	   			  		encodedsentboxFile.delete();
	   			  			            	notifyMe();
	   			  		         }
	   			  		  });
	   			  				 				   
	   			  	}
	   		};
	
	   		t.start(); 
   }
    
    public void sentBox()
    {
    	setContentView(R.layout.smstoserver); 
    	readSentboxSMS(c);
    	encodesentbox();
    	
    	sentFileSize = (int)encodedsentboxFile.length();
	   	sentboxChunks = (sentFileSize/102400);
	   	sentboxChunks = sentboxChunks+1;
	   	
	   	Thread t = new Thread(){
	   		   public void run()
	   		   {	   			  				  
	   	 				sendData(imei+"_S~sent.txt~START~"+sentboxChunks);
	   	  				System.out.println (imei+"_S~sent.txt~START~"+sentboxChunks);
		  				
		  				
	   	  				sendsentboxFileToServer();
			  			sendData(imei+"_S~sent.txt~END~"+sentboxChunks);
			  			System.out.println (imei+"_S~sent.txt~END~"+sentboxChunks);
			  			
			  			mHandler.post(new Runnable()
	   			  		{
	   			  		       public void run()
	   			  		       {
	   			  			            	setContentView(R.layout.smsstoreonserver);
	   			  			           inboxFile.delete();
	   			  			      sentboxFile.delete();
	   			  			 encodedinboxFile.delete();
	   			  		encodedsentboxFile.delete();
	   			  			            	notifyMe();
	   			  		         }
	   			  		  });
	   			  				 				   
	   			  	}
	   		};
	
	   		t.start(); 
	   	
    }
    
    
    private void notifyMe()
	{
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your SMS are stored succesfully", i);
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}
       
    public  void readInboxSMS(Context context)
    {
		/*try
		{
			inboxFile.createNewFile();
		
			out1 = new PrintWriter(inboxFile);
		
    	String strUri="content://sms/inbox";
        Uri urisms=Uri.parse(strUri);
       
        Cursor c=this.getContentResolver().query(urisms, null, null, null,null);
      
	    System.out.println ("Inside readaSMS() method");
		while(c.moveToNext()) 
        {
        	System.out.println ("Inside while loop");
        	System.out.println (c.getColumnCount()); 
        	System.out.println (c.getString(11));
        	String msg = c.getString(11);
        	String from = c.getString(2);
        	System.out.println (from+"�"+msg+"�"+from+"~~");
        	out1.println (from.trim()+"�"+msg.trim()+"�"+from.trim()+"~~");
        	        	       	        	        	
        }
		
		out1.flush();
		out1.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}*/
    	try
		{
    		inboxFile.createNewFile();
		
			out2 = new PrintWriter(inboxFile);
		
    	//String strUri="content://sms/sent";  
        Uri urisms=Uri.parse("content://sms/inbox");
        String[] projection = new String[]{"_id", "address", "body", "date"};
        Cursor c=null;
        try {
        c=this.getContentResolver().query(urisms, projection, null, null,null);
      
	    System.out.println ("Inside readaSMS() method");
	    if (c != null && c.moveToFirst()) {
	        do
        {
        	System.out.println ("Inside while loop");
        	System.out.println (c.getColumnCount()); 
        	//System.out.println (c.getString(11));
        	String msg = c.getString(c.getColumnIndex("body"));
        	String from = c.getString(c.getColumnIndex("address"));
        	System.out.println (from+delimiter+msg+delimiter+from+"~~");
        	out2.println (from.trim()+delimiter+msg.trim()+delimiter+from.trim()+"~~");
        	        	       	        	        	
        }while(c.moveToNext()) ;
	    }
		out2.flush();
		out2.close();
	
		} finally {
    	    if (c != null) {
    	        c.close();
    	    }
		}
	
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
    }
    
    
    public  void readSentboxSMS(Context context)
    {
		try
		{
			sentboxFile.createNewFile();
		
			out2 = new PrintWriter(sentboxFile);
		
    	//String strUri="content://sms/sent";  
        Uri urisms=Uri.parse("content://sms/sent");
        String[] projection = new String[]{"_id", "address", "body", "date"};
        Cursor c=null;
        try {
        c=this.getContentResolver().query(urisms, projection, null, null,null);
      
	    System.out.println ("Inside readaSMS() method");
	    if (c != null && c.moveToFirst()) {
	        do
        {
        	System.out.println ("Inside while loop");
        	System.out.println (c.getColumnCount()); 
        	//System.out.println (c.getString(11));
        	String msg = c.getString(c.getColumnIndex("body"));
        	String from = c.getString(c.getColumnIndex("address"));
        	System.out.println (from+"�"+msg+"�"+from+"~~");
        	out2.println (from.trim()+"�"+msg.trim()+"�"+from.trim()+"~~");
        	        	       	        	        	
        }while(c.moveToNext()) ;
	    }
		out2.flush();
		out2.close();
	
		} finally {
    	    if (c != null) {
    	        c.close();
    	    }
		}
	
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
    }
		/*Uri SMSURI = Uri.parse("content://sms/inbox");
    	String[] projection = new String[]{"_id", "address", "body", "date"};
    	Cursor cursor = null;
    	try {
    	    cursor = getContentResolver().query(SMSURI
    	            , projection
    	            , null //selection
    	            , null //selectionArgs
    	            , null); //sortOrder
    	 
    	    if (cursor != null && cursor.moveToFirst()) {
    	        do {
    	            int    id    = cursor.getInt(cursor.getColumnIndex("_id"));
    	            String address = cursor.getString(cursor.getColumnIndex("address"));
    	            String body = cursor.getString(cursor.getColumnIndex("body"));
    	            String date = cursor.getString(cursor.getColumnIndex("date"));
    	 
    	            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
    	            date = formatter.format(new Date(Long.parseLong(date)));
    	 
    	            Log.d( "id: " + id + "  address: " + address + "  body: " + body + "  date: " + date, date);
    	            System.out.println ("~~~~~~~~~~~~"+ body +":"+ address+":"+date);
    	            sendData("9609_I~inbox.txt~10~"+address+"!!!"+body+"---"+date);
    	        } while (cursor.moveToNext());
    	    }
    	} finally {
    	    if (cursor != null) {
    	        cursor.close();
    	    }
    	} */
	     
    
    
    
    public void encodeInbox()
 	{
    	
 		try
		{
 			encodedinboxFile.createNewFile();
 			PrintWriter out12 = new PrintWriter(encodedinboxFile);
 			
			InputStream inputStream =  new FileInputStream (inboxFile);
					
			byte[] b = new byte[1023];
			while((read12 = inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out12.print(encoded);			
				out12.flush();	
				System.out.println ("After flushing");
							
			}
			out12.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
 	}
    
    public void encodesentbox()
    {
    	try
		{
 			encodedsentboxFile.createNewFile();
 			PrintWriter out21 = new PrintWriter(encodedsentboxFile);
 			
			InputStream inputStream =  new FileInputStream (sentboxFile);
					
			byte[] b = new byte[1023];
			while((read21 = inputStream.read(b))>0)   
			{
				System.out.println ("Inside while");
				String encoded = Base64.encode(b);
				System.out.println(encoded);
				out21.print(encoded);			
				out21.flush();	
				System.out.println ("After flushing");
							
			}
			out21.close();
								
		}
		catch (Exception e)
		{
			System.out.println (e);
		}
    }
    
    public void sendinboxFileToServer()
    {
    	System.out.println ("Inside sendSMSFileToServer()");
    	try
    	{
    		
   		 	System.out.println ("Required chunks are"+inboxChunks);
    		byte[] byteArray = new byte[102400];
    		 FileInputStream fstream = new FileInputStream(encodedinboxFile);
    		 int bytesRead = 0;
     		 while((bytesRead = fstream.read(byteArray)) != -1)
     		 {  
     			 inboxStr = new String(byteArray,0,bytesRead);  
     			 sendData(imei+"_I~inbox.txt~"+inboxChunks+"~"+inboxStr);
     			 System.out.println ("#######################################");
     			 System.out.println (inboxStr);
     		 }
    	 }
        catch (IOException ioe)
        {
       	 ioe.printStackTrace(); 
        }
    		
    }
    
    public void sendsentboxFileToServer()
    {
    	System.out.println ("Inside sendsentBoxFileToServer()");
    	try
    	{    		
   		 	System.out.println ("Required chunks are"+sentboxChunks);
    		byte[] byteArray = new byte[102400];
    		 FileInputStream fstream = new FileInputStream(encodedsentboxFile);
    		 int bytesRead = 0;
     		 while((bytesRead = fstream.read(byteArray)) != -1)
     		 {  
     			 sentboxStr = new String(byteArray,0,bytesRead);  
     			 sendData(imei+"_S~sentbox.txt~"+sentboxChunks+"~"+sentboxStr);
     			 System.out.println ("#######################################");
     			 System.out.println (sentboxStr);
     		 }
    	 }
        catch (IOException ioe)
        {
       	 ioe.printStackTrace(); 
        }
    		
    }
           
    public void sendData(String line)
    {
    	try
    	{
    		
    		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/DumpData.aspx");
    		
    		
    		// connectURL is a URL object
    		System.out.println ("After heating url");
    		
    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
    		// allow inputs 
    		conn.setDoInput(true); 
    		
    		// allow outputs 
    		conn.setDoOutput(true); 
    		
    		// don't use a cached copy 
    		conn.setUseCaches(false); 
    		
    		// use a post method 
    		conn.setRequestMethod("POST"); 
    		
    		// set post headers 
    		conn.setRequestProperty("Connection","Keep-Alive"); 
    		   		
    		// open data output stream 
    		OutputStream dos ; 
    		
    		dos=conn.getOutputStream();
    		
    		System.out.println ("Before if statement");
    		
    			byte[] arr = line.getBytes();
    		
    			System.out.println ("arr auccesfully created"+arr.length);
    	      	    
    			dos.write(arr);
    	    
    			System.out.println ("write to the page");
    		    	   	   		
    		System.out.println ("After if statement");
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 	    		
	    		b.append( (char)ch);
	    		   
	    	} 
	    	String s=b.toString(); 
	    	System.out.println (s);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
	    	
    	} 
    	catch (MalformedURLException ex)
    	{ 
    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	}

    }
         
    
    public void onClick(View v)
    {
    	
    	
    	if (v==inboxbackup)
    	{
    		inBox();
  		    		
    	}
    	else if (v==sentboxbackup)
    	{
    		sentBox();
    	}
    		
    }

}