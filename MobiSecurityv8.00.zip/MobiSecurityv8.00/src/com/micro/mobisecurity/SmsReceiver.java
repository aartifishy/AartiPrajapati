package com.micro.mobisecurity;



import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class SmsReceiver extends BroadcastReceiver

{
	File startDateFile = new File("data/data/com.micro.mobisecurity/MicroStartDate");
	File endDateFile = new File("data/data/com.micro.mobisecurity/MicroEndDate");
	File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
	File InSms=new File("data/data/com.micro.mobisecurity/IncommingSms");
	File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	String body="",IncommingSmsBody="",IncommingMultiSmsBody="",Newrec="",ObsNo="";
	File scoutRecFile=new File("data/data/com.micro.mobisecurity/ScoutRecFile");
	File stdAppExpiredFile = new File(
	"data/data/com.micro.mobisecurity/StandardAppExpired");
	public static String  IncommingNumber="";
	public String Bstring,pinString;
	public  String R1,R2,R3,R4,R5,R6,R7,R8,R9,R10;
	public static final Uri uriSms = Uri.parse("content://sms");
	 public String BuddyString;
	    public String RecipientNumber,RecipientName,onlynumber,splitnumber;
	    String arr1[];
	    String arr2[]=new String[10];
	    GregorianCalendar endDay,now,startDay;
	    SmsMessage sms;
	@Override
	public void onReceive(Context context, Intent intent) 
   {
		
		
		System.out.println("********* SMS Aaya *********");
		
		Bundle bundle  = intent.getExtras();
		SmsMessage[] messages = null;
		String body="";

		Object[] pdus = (Object[]) bundle.get("pdus");
		messages = new SmsMessage[pdus.length];
		
		
		//Read Observer Number
		/*AfterSms iAfterRecSms=new AfterSms();
        iAfterRecSms.ReadScoutRecFile();
        ObsNo=iAfterRecSms.observerNo;*/
        
        
        
		
		
		for (int i = 0; i < pdus.length; i++)
		{
		     messages[i] =SmsMessage.createFromPdu((byte[]) pdus[i]);
		}

	      sms = messages[0];
		
		body = sms.getDisplayMessageBody();
		
		IncommingSmsBody = body;  //SMS Body
		System.out.println("message body::"+IncommingSmsBody);
		IncommingNumber = sms.getOriginatingAddress(); //Sender Number
		
		//InboxMessageDelete();
		//mobnumber=number.substring(number.indexOf("+"),number.indexOf("+")+2);
		System.out.println("###### sender ######"+ IncommingNumber);
		onlynumber=IncommingNumber.substring(3,IncommingNumber.length());
		System.out.println("###### Mobile Number ######"+ onlynumber);
		//splitnumber=IncommingNumber;
		//System.out.println("###### Split Number ######"+ splitnumber);
		MDsuccess ms =new MDsuccess();
		ms.readPINFile();
		pinString=ms.fullString;
		System.out.println("pinString::"+pinString);
		/*try{
			
			
			System.out.println("m2m deactivateeeeeeeeeeeee");
			Intent startActivity = new Intent();
	      	     startActivity.setClass(context, AfterSms.class);
	      	     startActivity.setAction(AfterSms.class.getName());
	      	     startActivity.setFlags(
	      	     Intent.FLAG_ACTIVITY_NEW_TASK
	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	      	     context.startActivity(startActivity);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}*/
		
		if(appactFile.exists())
		{
			System.out.println("m2m deactivateeeeeeeeeeeee");
			Intent startActivity = new Intent();
	      	     startActivity.setClass(context, AfterDeactSMS.class);
	      	     startActivity.setAction(AfterDeactSMS.class.getName());
	      	     startActivity.setFlags(
	      	     Intent.FLAG_ACTIVITY_NEW_TASK
	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	      	     context.startActivity(startActivity);
			
		}
		else if(startDateFile.exists() || endDateFile.exists())
		{
			
		try
		{
			readStartDateFile();
			readEndDateFile();
		}
		catch (ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		 now = new GregorianCalendar();  
		 if (endDay.after(now)) 
		 {
			 System.out.println ("First condition is true");
			 if ((now.after(startDay)))
			 {
				 try 
					{
						System.out.println("********* Inside TRY *********");  
						
									System.out.println("********* if SMS length is 1 *********");
									
									System.out.println(IncommingSmsBody);
									System.out.println(pinString);
									System.out.println("Getlog"  +pinString);
										try
								     	{
								     	     System.out.println ("**** File Writing ****");	 
								     	     InSms.createNewFile();
								     	     PrintWriter out1 = new PrintWriter(InSms);
								     	     out1.write(IncommingSmsBody);  
								     	     out1.flush();
								     	     out1.close();
								     	 }
								     	 catch (IOException ioe)
								     	 {
									    	 ioe.printStackTrace();
								     	 } 
											
												
										
										 if(IncommingSmsBody.equalsIgnoreCase("Help" +pinString) )
											{
											 abortBroadcast();
											 Intent startActivityCall = new Intent();
												System.out.println("after intent");
								  	      	     startActivityCall.setClass(context, HelpCommand.class);
								  	      	 System.out.println("after set class");
								  	      	     startActivityCall.setAction(HelpCommand.class.getName());
								  	      	 System.out.println("after set acttion");
								  	      	     startActivityCall.setFlags(
								  	      	     Intent.FLAG_ACTIVITY_NEW_TASK
								  	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								  	      	 System.out.println("after set new task");
								  	      	     context.startActivity(startActivityCall);
								  	      	 System.out.println("after set start activity");
								  	      	
												
											}
											
										 else if(IncommingSmsBody.equalsIgnoreCase("Callme" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
											 abortBroadcast();
												Intent startActivityCall = new Intent();
												System.out.println("after intent");
								  	      	     startActivityCall.setClass(context, Callme.class);
								  	      	 System.out.println("after set class");
								  	      	     startActivityCall.setAction(Callme.class.getName());
								  	      	 System.out.println("after set acttion");
								  	      	     startActivityCall.setFlags(
								  	      	     Intent.FLAG_ACTIVITY_NEW_TASK
								  	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								  	      	 System.out.println("after set new task");
								  	      	     context.startActivity(startActivityCall);
								  	      	 System.out.println("after set start activity");
								  	      	
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Getlog" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
												System.out.println("@@@@@@ GetLog Command @@@@@@@@");
												abortBroadcast();
												
												
												System.out.println();
									
												Intent startActivity = new Intent();
								  	      	     startActivity.setClass(context, Getlog.class);
								  	      	     startActivity.setAction(Getlog.class.getName());
								  	      	 

								  	      	     startActivity.setFlags(
								  	      	     Intent.FLAG_ACTIVITY_NEW_TASK
								  	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								  	      	     context.startActivity(startActivity);
								  	      	
											}
											
											else if(IncommingSmsBody.equalsIgnoreCase("Block" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
												abortBroadcast();
												 /*if(Cc.exists())
													{
													 System.out.println("m2m deactivateeeeeeeeeeeee");
														Intent startActivity1 = new Intent();
												      	     startActivity1.setClass(context, AfterSms.class);
												      	     startActivity1.setAction(AfterSms.class.getName());
												      	     startActivity1.setFlags(
												      	     Intent.FLAG_ACTIVITY_NEW_TASK
												      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
												      	     context.startActivity(startActivity1);
													}*/
												System.out.println("@@@@@@ Block Command @@@@@@@@");
												//deleteMessage(context,messages);
												//DeleteSMSFromInbox1(context, messages);
												System.out.println();
										 
										
												Intent startActivity = new Intent();
									      	     startActivity.setClass(context, BlockOnly.class);
									      	     startActivity.setAction(BlockOnly.class.getName());
									      	     startActivity.setFlags(
									      	     Intent.FLAG_ACTIVITY_NEW_TASK| Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
									      	     context.startActivity(startActivity);
									      	  
										
												
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Siren" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
												abortBroadcast();
												System.out.println("@@@@@@ Siren Command @@@@@@@@");
												/*if(Cc.exists())
												{
												 System.out.println("m2m deactivateeeeeeeeeeeee");
													Intent startActivity1 = new Intent();
											      	     startActivity1.setClass(context, AfterSms.class);
											      	     startActivity1.setAction(AfterSms.class.getName());
											      	     startActivity1.setFlags(
											      	     Intent.FLAG_ACTIVITY_NEW_TASK
											      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
											      	     context.startActivity(startActivity1);
												}*/
												
											//deleteMessage(context,messages);
												//DeleteSMSFromInbox1(context, messages);
										
												Intent startActivity = new Intent();
									      	     startActivity.setClass(context, SirenBlock.class);
									      	     startActivity.setAction(SirenBlock.class.getName());
									      	     startActivity.setFlags(
									      	     Intent.FLAG_ACTIVITY_NEW_TASK
									      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
									      	     context.startActivity(startActivity);
									      	   
									      	
												
											//}
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Deact") ) 
											{
												System.out.println("@@@@@@ Siren Command @@@@@@@@");
												
												abortBroadcast();
												//if((IncommingNumber.equals("+918080705667")) || (IncommingNumber.equals("+917709640709")) )
												{
												//DeleteSMSFromInbox1(context, messages);
												//deleteMessage(context,messages);
												Intent startActivity = new Intent();
									      	     startActivity.setClass(context, Deactivateapp.class);
									      	     startActivity.setAction(Deactivateapp.class.getName());
									      	     startActivity.setFlags(
									      	     Intent.FLAG_ACTIVITY_NEW_TASK
									      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
									      	     context.startActivity(startActivity);
												}
									      	
												
											//}
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Wipe" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
												System.out.println("@@@@@@ Wipe Command @@@@@@@@");
												abortBroadcast();
												
												AlldeleteMessage(context, messages);
													
												   Intent startActivity1 = new Intent();
									       	          startActivity1.setClass(context, WipePhoneData.class);
									       	          startActivity1.setAction(WipePhoneData.class.getName());
									       	          startActivity1.setFlags(
									       	          Intent.FLAG_ACTIVITY_NEW_TASK
									       	          | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
									       	          context.startActivity(startActivity1);
									       	          
									       	    
									         	   
									         	  
									          	     
									          	  
									          	  
									         	   
										 
											}
											
											else if(IncommingSmsBody.equalsIgnoreCase("Find" +pinString) )//&& (IncommingNumber.equals(ObsNo)))
											{
												System.out.println("@@@@@@ Find Command @@@@@@@@");
												
												abortBroadcast();
												//DeleteSMSFromInbox1(context, messages);
												//deleteMessage(context,messages);
												System.out.println(".......Incoming number......"+IncommingNumber);
												System.out.println(".......Recipient number....."+Bstring);
												
												
										
										 
											 
											 System.out.println("******** Number is buddy number ***********");
											 
											 
												
												Intent startActivity = new Intent();
								  	      	     startActivity.setClass(context, Find.class);
								  	      	     startActivity.setAction(Find.class.getName());
								  	      	     startActivity.setFlags(
								  	      	     Intent.FLAG_ACTIVITY_NEW_TASK
								  	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								  	      	     context.startActivity(startActivity);
								  	      	
											
											
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Ccstop" +pinString) )
											{
												abortBroadcast();
												System.out.println("Cc stop");
												Cc.delete();
											}
											else if(IncommingSmsBody.equalsIgnoreCase("Cc" +pinString) )
											{
												abortBroadcast();
												System.out.println("@@@@@@ Carbon Copy Activated @@@@@@@@");
												//deleteMessage(context,messages);
												//DeleteSMSFromInbox1(context, messages);
												 try
											     	{
											     	     System.out.println ("****Cc File Writing ****");	 
											     	     Cc.createNewFile();
											     	     PrintWriter out1 = new PrintWriter(Cc);
											     	     out1.write(IncommingNumber);  
											     	     out1.flush();
											     	     out1.close();
											     	 }
											     	 catch (IOException ioe)
											     	 {
												    	 ioe.printStackTrace();
											     	 } 
																		
											     	if(Cc.exists())
													{
													 System.out.println("m2m deactivateeeeeeeeeeeee");
														Intent startActivity1 = new Intent();
												      	     startActivity1.setClass(context, AfterSms.class);
												      	     startActivity1.setAction(AfterSms.class.getName());
												      	     startActivity1.setFlags(
												      	     Intent.FLAG_ACTIVITY_NEW_TASK
												      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
												      	     context.startActivity(startActivity1);
													}
									      	     
									      	
												
											//}
											}
											else
											{
												 if(Cc.exists())
													{
													 System.out.println("m2m deactivateeeeeeeeeeeee");
														Intent startActivity = new Intent();
												      	     startActivity.setClass(context, AfterSms.class);
												      	     startActivity.setAction(AfterSms.class.getName());
												      	     startActivity.setFlags(
												      	     Intent.FLAG_ACTIVITY_NEW_TASK
												      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
												      	     context.startActivity(startActivity);
													}
											}
											
					
							
					   
						  
					    
					} 
					catch (Exception e) 
					{
			             System.out.println("........................."+e);
					}
			 }
			else
			{
				System.out.println ("Sim has not changed, But date is changed therefore application is expired");
				try {
					stdAppExpiredFile.createNewFile();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
				Intent startActivity = new Intent();
	      	     startActivity.setClass(context, PeriodExpired.class);
	      	     startActivity.setAction(PeriodExpired.class.getName());
	      	     startActivity.setFlags(
	      	     Intent.FLAG_ACTIVITY_NEW_TASK
	      	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	      	     context.startActivity(startActivity);
				//sendSMS(rec1,"Sim has not changed, But date is changed therefore application is expired");
				//sendSMS(rec2,"Sim has not changed, But date is changed therefore application is expired");
				//sendSMS("7709640709","Sim has not changed, But date is changed therefore application is expired");
			}
		}
		else
		{
			System.out.println ("Sim has not changed but application is expired");
			//sendSMS(rec1,"Sim has not changed but application is expired");
			//sendSMS(rec2,"Sim has not changed but application is expired");
			//sendSMS("7709640709","Sim has not changed but application is expired");
			try {
				stdAppExpiredFile.createNewFile();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
			Intent startActivity = new Intent();
     	     startActivity.setClass(context, PeriodExpired.class);
     	     startActivity.setAction(PeriodExpired.class.getName());
     	     startActivity.setFlags(
     	     Intent.FLAG_ACTIVITY_NEW_TASK
     	     | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
     	     context.startActivity(startActivity);
		}
		
		}
		

   }
	
	
	


	public void readEndDateFile() throws ClassNotFoundException 
	{
		 try
		 {
			 ObjectInputStream objectIn1 = null;
			 boolean test = true;															
				
			 objectIn1 = new ObjectInputStream(new BufferedInputStream(new FileInputStream("data/data/com.micro.mobisecurity/MicroStartDate")));
			
			 while (test)  
			 {
				 startDay = (GregorianCalendar) objectIn1.readObject();
				 System.out.println ("within while loop of start date file");
				 System.out.println (startDay);
				 System.out.println ("After reading start date from file");
				 test=false;
			 }

			 objectIn1.close();

			 int year = startDay.get(Calendar.YEAR);
			 int month = startDay.get(Calendar.MONTH)+1;
			 int day = startDay.get(Calendar.DAY_OF_MONTH);

			 System.out.println ("***********************************************");
			 System.out.println (year+":"+month+":"+day);
				
			}
			catch (IOException ioe)
	    	{
	    		ioe.printStackTrace();
	    	}
	}
	
	public void readStartDateFile() throws ClassNotFoundException 
	{
		 System.out.println ("Inside readEnDateFromFile");
		 try
		 {
			 ObjectInputStream objectIn2 = null;
			 boolean test2 = true;
			
			 objectIn2 = new ObjectInputStream(new BufferedInputStream(new FileInputStream("data/data/com.micro.mobisecurity/MicroEndDate")));
			
			 System.out.println ("Before while");
			 while (test2)
			 {
				 System.out.println ("Inside while");
				 endDay = (GregorianCalendar) objectIn2.readObject();
				 System.out.println ("within while loop of end date file");
				 System.out.println (endDay);
				 System.out.println ("After reading end date from file");
				 test2=false;
			 }

			 objectIn2.close();

			 int year = endDay.get(Calendar.YEAR);
			 int month = endDay.get(Calendar.MONTH)+1;
			 int day = endDay.get(Calendar.DAY_OF_MONTH);
			 System.out.println ("************** *********************************");  
			 System.out.println (year+":"+month+":"+day);

		 }
		 catch (IOException ioe)
		 {
			 ioe.printStackTrace();
		 }
	}
	
	private int AlldeleteMessage(Context context, SmsMessage[] messages) {
		
		 Uri deleteUri = Uri.parse("content://sms");
		    int count = 0;
		    Cursor c = context.getContentResolver().query(deleteUri, null, null,
		            null, null);
		while (c.moveToNext()) {
		        try {
		            // Delete the SMS
		            String pid = c.getString(0); // Get id;
		            String uri = "content://sms/" + pid;
		            count = context.getContentResolver().delete(Uri.parse(uri),
		                    null, null);
		        } catch (Exception e) {
		        }
				//return count;
		}
		return count;
		    }
		  
	public String back()
	{
		System.out.println("..............."+IncommingNumber);
		return IncommingNumber;
	}
	


}
