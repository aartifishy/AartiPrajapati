package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ParseException;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class AddBuddyClick extends ListActivity 
{
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	String[]arr1;
	public static String PREFS = "MyPrefs";
	public static int firsttimerecselect=0;
	public volatile static int cnt;
	String recno,FullString,mobnumber,uname,recfullString,recname;
	static final int DIALOG_Rec = 1;
	private Dialog editorDialog = null;
	//AddBuddiesPinRegTime ad=new AddBuddiesPinRegTime();
	 File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
	public static String serverRec="";
	String[] title ;
	String[] detail ;
	Integer[] imgid ;
	public static SharedPreferences mPref;
   
    File BuddyListFile=new File("data/data/com.micro.mobisecurity/buddylist");
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		mPref = getSharedPreferences(PREFS, 0);
		if(BuddyFile.exists())
		{
			title = new String[] {
				"Mobi Security Buddy List","Manual Add Buddy", "Automatic Add Buddy"};
			 detail = new String[] {
				"You added buddy list","Manually add buddy ","Handset contact through add buddy"};
			imgid =new Integer[]{R.drawable.userlist,R.drawable.manualaddbuddy,R.drawable.addbuddyviaphone};
		}
		else
		{
			title = new String[] {
					"Manual Add Buddy", "Automatic Add Buddy"};
				 detail = new String[] {
					"Manually add buddy ","Handset contact through add buddy"};
				imgid =new Integer[]{R.drawable.manualaddbuddy,R.drawable.addbuddyviaphone};
		}
		setContentView(R.layout.main1);
		
		mInflater = (LayoutInflater) getSystemService(
		Activity.LAYOUT_INFLATER_SERVICE);
		
		data = new Vector<RowData>();
		
		for(int i=0;i<title.length;i++)
		{
			try {
			 	rd = new RowData(i,title[i],detail[i]);
			    } 
			catch (ParseException e) 
			{
			    	e.printStackTrace();
			}
		   data.add(rd);
		}
		   CustomAdapter adapter = new CustomAdapter(this, R.layout.firstlist,R.id.title, data);
		   setListAdapter(adapter);
		   getListView().setTextFilterEnabled(true);
	}
	   public void onListItemClick(ListView parent, View v, int position,long id) 
	   { 
		   if(BuddyFile.exists())
		   {
		  if (position == 0 )
		   {
			   //Toast.makeText(getApplicationContext(), "You have selected "
	                   // +"General Setting.",  Toast.LENGTH_SHORT).show();
			   
			   Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this,ShowBuddyList.class.getName());
	   			startActivity(intent);
	   			//showDialog(DIALOG_Rec);
		   }
		   if (position ==1)
		   {
			   /*Toast.makeText(getApplicationContext(), "You have selected "
	                    +"General Setting.",  Toast.LENGTH_SHORT).show();*/
			   
			   /*Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this,AddBuddyManual.class.getName());
	   			startActivity(intent);*/
	   			showDialog(DIALOG_Rec);
		   }
		   else if (position == 2)
		   {
			 /*  Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Lock Setting.",  Toast.LENGTH_SHORT).show();*/
			   
			   /*Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, LockSetting.class.getName());
	   			startActivity(intent);*/
			  Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, ContactListDemo.class.getName());
	   			startActivity(intent);
			   
		   }
		   }
		   else
		   {
			   if (position ==0)
			   {
				   /*Toast.makeText(getApplicationContext(), "You have selected "
		                    +"General Setting.",  Toast.LENGTH_SHORT).show();*/
				   
				   /*Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this,AddBuddyManual.class.getName());
		   			startActivity(intent);*/
		   			showDialog(DIALOG_Rec);
			   }
			   else if (position ==1)
			   {
				 /*  Toast.makeText(getApplicationContext(), "You have selected "
		                    +"Lock Setting.",  Toast.LENGTH_SHORT).show();*/
				   
				   /*Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, LockSetting.class.getName());
		   			startActivity(intent);*/
				    Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, ContactListDemo.class.getName());
		   			startActivity(intent);
				   
			   }
		   }
		 
	   }
	       private class RowData 
	       {
	       protected int mId;
	       protected String mTitle;
	       protected String mDetail;
	       RowData(int id,String title,String detail)
	       	   {
		       mId=id;
		       mTitle = title;
		       mDetail=detail;
		       }
	       
		       @Override
		       public String toString() 
		       {
		               return mId+" "+mTitle+" "+mDetail;
		       }
	       }
	       
	  private class CustomAdapter extends ArrayAdapter<RowData> 
	  {
		  public CustomAdapter(Context context, int resource,int textViewResourceId, List<RowData> objects) 
		  {               
			  super(context, resource, textViewResourceId, objects);
		  }
	       @Override
	       public View getView(int position, View convertView, ViewGroup parent) 
	       {   
	       ViewHolder holder = null;
	       TextView title = null;
	       TextView detail = null;
	       ImageView i11=null;
	       RowData rowData= getItem(position);
	       if(null == convertView)
	       {
	            convertView = mInflater.inflate(R.layout.firstlist, null);
	            holder = new ViewHolder(convertView);
	            convertView.setTag(holder);
	       }
	             holder = (ViewHolder) convertView.getTag();
	             title = holder.gettitle();
	             title.setText(rowData.mTitle);
	             detail = holder.getdetail();
	             detail.setText(rowData.mDetail);                                                     
	             i11=holder.getImage();
	             i11.setImageResource(imgid[rowData.mId]);
	             return convertView;
	       }
	            private class ViewHolder 
	            {
	            private View mRow;
	            private TextView title = null;
	            private TextView detail = null;
	            private ImageView i11=null; 
	            public ViewHolder(View row) 
	            {
	            mRow = row;
	            }
	         public TextView gettitle() 
	         {
	             if(null == title)
	             {
	                 title = (TextView) mRow.findViewById(R.id.title);
	             }
	            return title;
	         }     
	         public TextView getdetail() 
	         {
	             if(null == detail)
	             {
	                  detail = (TextView) mRow.findViewById(R.id.detail);
	             }
	           return detail;
	         }
	        public ImageView getImage() 
	        {
	             if(null == i11)
	             {
	                  i11 = (ImageView) mRow.findViewById(R.id.img);
	             }
	                return i11;
	        }
	     }
	   } 
	  @Override
	    protected Dialog onCreateDialog(int id)
	    {
	        Dialog editor = editorDialog;
	        
	       
	        
	        if (editorDialog == null)
	        {
	        	 switch(id)
	        	 {
	        	 
	        	 case DIALOG_Rec:
	        	 editor = createEditorDialogForRec();
	        	 //ChangeEmail();
	             break;

	        	

	        	 }
	            
	        }
	        return editor;
	    }
	  

	  private Dialog createEditorDialogForRec()
	    {
	        AlertDialog.Builder builder = new AlertDialog.Builder(this);
	        builder.setTitle(R.string.addDialogTitleRec);

	        View content = getLayoutInflater().inflate(R.layout.addrec,
	            (ViewGroup) findViewById(R.id.editrecLayout));
	        builder.setView(content);
	        
	        
	        builder.setPositiveButton(R.string.AddButton,
	            new DialogInterface.OnClickListener()
	            {
	        		
	                public void onClick(DialogInterface dialog, int which)
	                {
	                    
	                	Dialog source = (Dialog) dialog;
	                    EditText noField = (EditText) source
	                        .findViewById(R.id.editTextrec);
	                    EditText nameField = (EditText) source
                      .findViewById(R.id.editTextrecnm); 
	                    recno = noField.getText().toString();
	              	    recname=nameField.getText().toString();
	                    if (  cnt<5) 
	                    {
	                                //FullString += recno;
	                            //FullString += "  ";
	                            //FullString += recno;
	                            //System.out.println(FullString);
	                            //recno=customnoDialog_EditText.getText().toString();
	                           System.out.println("recno::"+recno);
	                            	if( recno!=null)
	              					{
	                                    //dataAdapter.add(FullString);
	                            		if(recno.startsWith("+"))
	                                    	
	                                    {
	                                    	//mobnumber=number.substring(number.indexOf("+"),number.indexOf("+")+2);
	                                    	//mobnumber=recno.substring(3,recno.length());
	                                    	//System.out.println("with out+91::"+mobnumber);
	                                    	//recno="";
	                                        //recno=mobnumber;
	                                        System.out.println("convert in number"+recno);
	                                        //FileWrite("","");
	                                        //ad.RegisterButton.setEnabled(true);
	                                        System.out.println("after register true::"+recno);
	                                        firsttimerecselect++;
	                                        writebuddies();
	                                        alertboxAfterBuddyAdd("Inform Buddies?","Send an SMS to your (new) buddies? This is to tell them that they will be notified if an unkown SIM is inserted in your device.");
	                                    }
	                            		else
	                            		{
	                            			alertbox("Mobi Security","Oops!This contact doesn't contain Country Code please add");
	                            		}
	                                   
	              					}else
	              					{
	              						alertbox("Mobi Security","Oops!This contact doesn't contain Name or Contact number");
	              					}
	                                    
	                                    //FullString="";
	                          
	                           
	              			
	              			
	                          
	                            /*txtContacts.setText(name);
	                            numbers_contacts.setText(number);*/
	                            
	                    }else
	                	{
	                		alertbox("Mobi Security","Oops!Maximum limit to add buddies is reached");
	                	}
	                    
	                    //removeDialog(DIALOG_1);
	                }
	            });

	        builder.setNegativeButton(R.string.CancelButton,
	            new DialogInterface.OnClickListener()
	            {

	                public void onClick(DialogInterface dialog, int which)
	                {
	                    dialog.dismiss();
	                   callBuddylist();
	                	
	                }

					
	            });

	        return builder.create();
	    }
	  @Override
		protected void onPrepareDialog(int id, Dialog dialog)
		{
			switch (id)
			{
				case DIALOG_Rec:
				{
					//dialog.setTitle("Custom dialog 1");
		
					EditText noField = (EditText)dialog.findViewById(R.id.editTextrec);
					EditText nameField = (EditText)dialog.findViewById(R.id.editTextrecnm);
		
					// Set the default values for Field 1 and 2
					nameField.setText("");
					noField .setText("");
					
				}
				break;
			}
		}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	    					Create Dialog For Change Name
	    					Create Dialog For Change Name
	    					Create Dialog For Change Name
	    					
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	    


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	  private void callBuddylist() {
			// TODO Auto-generated method stub
		  Intent intent = new Intent(Intent.ACTION_VIEW);
 			intent.setClassName(this, AddBuddyClick.class.getName());
 			startActivity(intent);
		}
	  public void writebuddies()
	    {
		  
	    	try
	    	{
	    		System.out.println("inside write buddies");
	    		/*SharedPreferences preferences = getPreference(MODE_PRIVATE);
	    		SharedPreferences.Editor editor = preferences.edit();
	    		editor.putInt("storedInt", storedPreference); // value to store
	    		editor.commit();*/
	    		//mPref = getPreferences();
	    		//Editor e = mPref.edit();
	    		System.out.println("before get cnt"+cnt);
	    		cnt = mPref.getInt("numRun",0);
	    		System.out.println("after get cnt"+cnt);
	    		  cnt++;
	    		  System.out.println("after get cnt increment"+cnt);
	    		  mPref.edit().putInt("numRun",cnt).commit();

	    		//cnt++;
	    		//ad.RegisterButton.setEnabled(true);
	    		BuddyFile.createNewFile();
	    	
			  FileWriter out1 = new FileWriter(BuddyFile,true);
			  serverRec+=recno+";";
			  System.out.println("Server Recipients::"+serverRec);
			 out1.write(";"+recno);  
			 System.out.println (";"+recno.trim());
			 out1.flush();
			 out1.close();
			 //System.out.println ("Name is?"+name);
			 System.out.println ("Number is?"+recno);
	    	}
	    	 catch (IOException ioe)
	    	 {
	    		 ioe.printStackTrace();
	    	 } 
	    	 try
		    	{
		    		//cnt++;
		    		//ad.RegisterButton.setEnabled(true);
		    		BuddyListFile.createNewFile();
		    	
				  FileWriter out1 = new FileWriter(BuddyListFile,true);
				  
				 out1.write("?"+recname+" "+recno);  
				 System.out.println ("?"+recno.trim()+" "+recname);
				 out1.flush();
				 out1.close();
				 //System.out.println ("Name is?"+name);
				 System.out.println ("Number is?"+recno);
		    	}
		    	 catch (IOException ioe)
		    	 {
		    		 ioe.printStackTrace();
		    	 } 
	    }
public  void FileWrite(File aPath,String aBody)
{
	try 
	{
		 System.out.println("@@@@ Inside Try FileWrite @@@@");
		 
		 aPath.createNewFile();
		 PrintWriter out1 = new PrintWriter(aPath);
		 out1.write(aBody);  
		 System.out.println (aBody.trim());
		 out1.flush();
		 out1.close();
	}
	catch (IOException ioe)
	 {
		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
		ioe.printStackTrace();
	 }
	
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++








protected void alertbox(String title, String mymessage)     
{
	new AlertDialog.Builder(this)   
	.setMessage(mymessage)   
	//.setTitle(title)   
	.setCancelable(true)   
	.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
	
	{   
	public void onClick(DialogInterface dialog, int whichButton)
		{
    	
		}   
	}
	)   
	.show();   
}
protected void alertboxAfterBuddyAdd(String title, String mymessage)     
{
// Code here to display alert box
   	// Create the alert box
          AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
          //alertbox.setTitle(mymessage);
          // Set the message to display
          alertbox.setMessage(mymessage);

          // Add a neutral button to the alert box and assign a click listener
          alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
          {

              // Click listener on the neutral button of alert box
              public void onClick(DialogInterface arg0, int arg1) 
              {
            	// The neutral button was clicked
                  //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
            	 // Lock();
            	  //moveTaskToBack(true);
            	  try
            	  {
            		 // alertboxAfterBuddyAdd("Inform Buddies?","Send an SMS to your (new) buddies? This is to tell them that they will be notified if an unkown SIM is inserted in your device");
            		  readNameFile();
            		  SendMultiPartSms(recno,uname+ " has added you as recipient on Mobi Security. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.mobisecurity.net" );
            		  alertboxAfterBuddyAddSucc("Mobi Security","Buddy added successfully!Do you want to another buddy?");
            	  //ReadScoutRecFile();
            	  }
            	  catch(Exception e)
            	  {
            		  System.out.println("send sms "+e);
            	  }
              }
          }
          
          
          
          );
          
          // Set a negative/no button and create a listener

          alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

              // Click listener

              public void onClick(DialogInterface arg0, int arg1) 
              {

                 // Toast.makeText(getApplicationContext(), "You Press No button.", Toast.LENGTH_SHORT).show();
                  alertboxAfterBuddyAddSucc("Mobi Security","Buddy added successfully!Do you want to another buddy?");
              }

          }
          
          );
           // show the alert box
          alertbox.show();  
}	
protected void alertboxAfterBuddyAddSucc(String title, String mymessage)     
{
// Code here to display alert box
   	// Create the alert box
          AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
          //alertbox.setTitle(mymessage);
          // Set the message to display
          alertbox.setMessage(mymessage);

          // Add a neutral button to the alert box and assign a click listener
          alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
          {

              // Click listener on the neutral button of alert box
              public void onClick(DialogInterface arg0, int arg1) 
              {
            	// The neutral button was clicked
                  //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
            	 // Lock();
            	  //moveTaskToBack(true);
            	  showDialog(DIALOG_Rec);
              }
          }
          
          
          
          );
          
          // Set a negative/no button and create a listener

          alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

              // Click listener

              public void onClick(DialogInterface arg0, int arg1) 
              {

                //  Toast.makeText(getApplicationContext(), "You Press No button.", Toast.LENGTH_SHORT).show();
                        finish();
              }

          }
          
          );
           // show the alert box
          alertbox.show();  
}	
/*public void ReadScoutRecFile()
{
	
	try
	 {
		    
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecure/arpfile");
		 DataInputStream in = new DataInputStream(fstream);
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println ("@@@@ while STRLINE is "+strLine);
			 recfullString = strLine.toString();
		 }
	     in.close();
	     
	     arr1 = recfullString.split("\\?");
	       			
	     for (int i=0;i<arr1.length;i++)
	     {	
	    	 
	    	 SendMultiPartSms(arr1[i],uname+ " has added you as recipient on Mobi Security. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.micromcs.net" );
	    	 //SendMultiPartSms(arr[i],uname+ " has added you as recipient on Micro Secure. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.microsecure.net" );
				
	     }
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}*/
public void readNameFile()
{

	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/NameField");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 uname = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +uname);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
public void SendMultiPartSms(String add,String msgbdy)
{
	
	SmsManager smsManager = SmsManager.getDefault();
	
 String destAddr = add, scAddr = null, mMessageText =msgbdy;
 
 System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
 
 PendingIntent sentIntent = null, deliveryIntent = null;
 
 try 
 {
 	
 	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
 	
 	
 	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
 	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

 
 	

 for (int i=0; i < messages.size(); i++)
 {

 	
 	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
        listOfIntents.add(pi);
 }
 System.out.println ("******** inside TRY FOR SendMultiPartSms10");
 smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

 } catch (Exception e) 
 {
 Log.i("TEST", e.toString());
 }

}	
}