package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.CellLocation;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.TextView;

public class Find extends Activity {
	
	public String RECP1,RECP2;
	public String name1,name2;
	public String Num,strProvider="";
	public String SenderId="",Ccnumber,ThirdPartyNo,observerNo,MsgBody;
	LocationManager locationManager;
	String location_context;
	StringBuilder sb;
	String serviceProvider,sp;
	Location location; 
	int cellID,lac,c=0,intCount=0; 
	String var;
	Criteria criteria=null;
	private static boolean locUpdateStatus=false;
	DateFormat dateFormat;   
	long ms;
	Date date;
	String myDate;
	int day,month,year,hours,minutes,seconds, Areacode,Countrycode,mcc;
	TextView recipientMobNo1,recipientMobNo2;
	String strLine,str;
	String fullString,rec1,rec2,timsi,uname,name;
	double lat,lng,speed;
	String lat1,lng1,cellID1;
    String Gpslocation;
    GsmCellLocation location1; 
    String provider;
    TelephonyManager mTelephonyMgr;
	public static String FindMyNumber="";
	String strLine1;
	String[]arr;
	String[]arr1;
	File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
	File BlockStart=new File("data/data/com.micro.mobisecurity/block");
	File SirenStart=new File("data/data/com.micro.mobisecurity/sirendone");
	File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	public void onCreate(Bundle savedInstanceState) 
	{
        super.onCreate(savedInstanceState);
        if(BlockStart.exists() || SirenStart.exists())
        {
        	location_context = Context.LOCATION_SERVICE;
    		System.out.println("location context"+location_context);
    	    locationManager = (LocationManager)getSystemService(location_context);
    	    mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
    	    location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
    	    System.out.println("location Manager"+locationManager);
    	    calculations();
            CalculateLatandLang();
            //location();
            if(Cc.exists())
    		{
            	ReadIncSmsFile();
    		}
            //finish();
            //System.exit(0);
        }
        else
        {
        moveTaskToBack(true);
        location_context = Context.LOCATION_SERVICE;
		System.out.println("location context"+location_context);
	    locationManager = (LocationManager)getSystemService(location_context);
	    mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
	    location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
	    System.out.println("location Manager"+locationManager);
	    calculations();
        CalculateLatandLang();
        //location();
        if(Cc.exists())
		{
        	ReadIncSmsFile();
		}
        //finish();
        //System.exit(0);
        }  
	}
	private void calculations() {
		// TODO Auto-generated method stub
		 sp = mTelephonyMgr.getSimOperatorName();
		 serviceProvider = removeSpace(sp);
		 serviceProvider.replace("%20"," ");
		 System.out.println ("*************************"+serviceProvider);
		 
		cellID = location1.getCid();
		 cellID1 = Integer.toString(cellID);
		 System.out.println ("*************cellID"+ cellID1);

		lac=location1.getLac();
		 //System.out.println ("*************areacode"+ areacode);
		 String networkOperator = mTelephonyMgr.getNetworkOperator();
		   mcc = Integer.parseInt(networkOperator.substring(0, 3));
	        int mnc = Integer.parseInt(networkOperator.substring(3));
		//date.toString("yyyy-MM-dd HH:MM:SS");
	}
synchronized  public void   CalculateLatandLang()
	
    {          
		try
		{
			System.out.println("************Inside CalculatelatLong*****************");
			locUpdateStatus=false;
			System.out.println("************Inside CalculatelatLong***22222222**************");
			System.gc();
		
	   	 	//Setting Criteria
	   	 	criteria = new Criteria();
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setAccuracy(Criteria.ACCURACY_FINE);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setAltitudeRequired(false);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setBearingRequired(false);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
	   	 	criteria.setCostAllowed(true);
	   	 System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	criteria.setPowerRequirement(Criteria.POWER_LOW);
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	strProvider = locationManager.getBestProvider(criteria, true);
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	//mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	
		 	System.out.println("************Inside CalculatelatLong********100000000000*********");
		 	try
			{
			 		System.out.println("***GPS Provider IS NOT NULL********** ");
			 		listenLocation locationListener=new listenLocation();
					locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,15000, 10, locationListener);
					System.out.println("*******Location Listner thread Is started*****");
			}
			catch (Exception e) 
			{
				TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
		  		//lat=0.0;
		        //  lng=0.0;
		                 
		  		//---obtain the CellID and LAC of the device---
		  	        CellLocation.requestLocationUpdate();        
		  	        cellID = location1.getCid();
		  	         lac = location1.getLac();

		  	       
		  	        
		  	        try {
		  	            if (!displayMap(cellID, lac))
		  	            {
		  	                lat=0.0;
		  	                lng=0.0;
		  	            }
		  	                
		  	        } catch (Exception e1) {                    
		  	            e1.printStackTrace();
		  	        } 
					dataSendTimeInterval();
			  	
			}	
			
			System.out.println("gps provider is ---"+locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
			
			Timer timer=new Timer();
			TimerTask task=new TimerTask() {
				
				@Override
				public void run() 
				{
					System.out.println("locUpdateStatus--"+locUpdateStatus);
					if(locUpdateStatus==false)
					{
						System.out.println("inside imer locupdate status");
					System.out.println("Inside While....Thread sleep for-"+c+"-times");
					TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
			  		//lat=0.0;
			        //  lng=0.0;
			                 
			  		//---obtain the CellID and LAC of the device---
			  	        CellLocation.requestLocationUpdate();        
			  	        cellID = location1.getCid();
			  	         lac = location1.getLac();

			  	       
			  	        
			  	        try {
			  	            if (!displayMap(cellID, lac))
			  	            {
			  	                lat=0.0;
			  	                lng=0.0;
			  	            }
			  	                
			  	        } catch (Exception e) {                    
			  	            e.printStackTrace();
			  	        } 
						dataSendTimeInterval();
				  	}
					else
					{
						dataSendTimeInterval();
					}
					c++;
				}
			};
			timer.schedule(task, 0, 15000);
		
		}
		catch(Exception e)
		{
			
		System.out.println("error 4-->"+e);
	
		}
		
		
     } 
private void updateWithNewLocation( Location location)
{
	  this.location=location;
	  System.out.println("--------------updateWithNewLocation-------------------");
	  if (location != null) 
	  {
		  lat = location.getLatitude();
		  //strLat1 = Double.toString(dblLat);
		  lng = location.getLongitude();
		  //strLng1 = Double.toString(dblLng);
		  this.location=location;
		  
		  //dblLat = location.getLatitude();
		  //strLat1 = Double.toString(dblLat);
	   	  //dblLng = location.getLongitude();
	      //strLng1 = Double.toString(dblLng);
	 	  //dblSpeed=location.getSpeed();
	 	  //strSpeed1 = Double.toString(dblSpeed);
		  //dblSpeed=location.getSpeed();
		  //strSpeed1 = Double.toString(dblSpeed);
		  locUpdateStatus=true;
		  System.out.println("**************************  2");
		  dataSendTimeInterval();
	    	
		 
	  }
		
	  else 
		  
	  {
		  System.out.println("inside lat lng got it zero");
		  TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
	  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
	  		//lat=0.0;
	        //  lng=0.0;
	                 
	  		//---obtain the CellID and LAC of the device---
	  	        CellLocation.requestLocationUpdate();        
	  	        cellID = location1.getCid();
	  	         lac = location1.getLac();

	  	       
	  	        
	  	        try {
	  	            if (!displayMap(cellID, lac))
	  	            {
	  	                lat=0.0;
	  	                lng=0.0;
	  	            }
	  	                
	  	        } catch (Exception e) {                    
	  	            e.printStackTrace();
	  	        } 
			dataSendTimeInterval();
	  		 //sb.append("No Location");
	}
			
}
private void ProviderDisable(String provider)
{
	  try
	  {
		  System.out.println("provider disable falseeeeeeeeeeeeeee");
		  locUpdateStatus=false;
		  TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
	  		location1 = (GsmCellLocation) mTelephonyMgr.getCellLocation();
	  		//lat=0.0;
	        //  lng=0.0;
	                 
	  		//---obtain the CellID and LAC of the device---
	  	        CellLocation.requestLocationUpdate();        
	  	        cellID = location1.getCid();
	  	         lac = location1.getLac();

	  	       
	  	        
	  	        try {
	  	            if (!displayMap(cellID, lac))
	  	            {
	  	                lat=0.0;
	  	                lng=0.0;
	  	            }
	  	                
	  	        } catch (Exception e) {                    
	  	            e.printStackTrace();
	  	        } 
		  	dataSendTimeInterval();
		  	//Thread.sleep(8000);
		  	// CalculateLatandLang();
	  }
	  catch(Exception e)
	  {
		  System.out.println("provider disable ERROR--"+e);
		  CalculateLatandLang();
	  }
}

class listenLocation implements LocationListener
{
	@Override
	public void onLocationChanged(Location location)
	{
		
		updateWithNewLocation(location);
				
	}
	@Override
	public void onProviderDisabled(String provider)
	{		
		ProviderDisable(provider);
		/* bring up the GPS settings */
		/*Intent intent = new Intent(
				android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(intent);*/
	
	}
	@Override
	public void onProviderEnabled(String provider) {
		System.out.println("*************Provider Enable***********");
		locUpdateStatus=true;
	//	CalculateLatandLang();
		
	}
	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		locUpdateStatus=true;
		System.out.println("on provider Changed--**provider--"+provider);
		System.out.println("on provider Changed--**status--"+status);
		System.out.println("on provider Changed--**Bundle Extras--"+extras.describeContents());
		//CalculateLatandLang();
		
	}
}
	
	 private boolean displayMap(int cellID, int lac) throws Exception 
	    {
	        String urlString = "http://www.google.com/glm/mmap";            
	    
	        //---open a connection to Google Maps API---
	        URL url = new URL(urlString); 
	        URLConnection conn = url.openConnection();
	        HttpURLConnection httpConn = (HttpURLConnection) conn;        
	        httpConn.setRequestMethod("POST");
	        httpConn.setDoOutput(true); 
	        httpConn.setDoInput(true);
	        httpConn.connect(); 
	        
	        //---write some custom data to Google Maps API---
	        OutputStream outputStream = httpConn.getOutputStream();
	        WriteData(outputStream, cellID, lac);       
	        
	        //---get the response---
	        InputStream inputStream = httpConn.getInputStream();  
	        DataInputStream dataInputStream = new DataInputStream(inputStream);
	        
	        //---interpret the response obtained---
	        dataInputStream.readShort();
	        dataInputStream.readByte();
	        int code = dataInputStream.readInt();
	        if (code == 0) {
	            lat = (double) dataInputStream.readInt() / 1000000D;
	            System.out.println("cell id base latitude::"+lat);
	            lng = (double) dataInputStream.readInt() / 1000000D;
	            System.out.println("cell id base longitude::"+lng);
	            dataInputStream.readInt();
	            dataInputStream.readInt();
	            dataInputStream.readUTF();
	            
	            //---display Google Maps---
	            //String uriString = "geo:" + lat
	             //   + "," + lng;
	            //System.out.println("Gps location::"+uriString);
	            //Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
	                //Uri.parse(uriString));
	            //startActivity(intent);
	            return true;
	        }
	        else
	        {        	
	        	return false;
	        }
	    }  

	    private void WriteData(OutputStream out, int cellID, int lac) 
	    throws IOException
	    {    	
	        DataOutputStream dataOutputStream = new DataOutputStream(out);
	        dataOutputStream.writeShort(21);
	        dataOutputStream.writeLong(0);
	        dataOutputStream.writeUTF("en");
	        dataOutputStream.writeUTF("Android");
	        dataOutputStream.writeUTF("1.0");
	        dataOutputStream.writeUTF("Web");
	        dataOutputStream.writeByte(27);
	        dataOutputStream.writeInt(0);
	        dataOutputStream.writeInt(0);
	        dataOutputStream.writeInt(3);
	        dataOutputStream.writeUTF("");

	        dataOutputStream.writeInt(cellID);  
	        dataOutputStream.writeInt(lac);     

	        dataOutputStream.writeInt(0);
	        dataOutputStream.writeInt(0);
	        dataOutputStream.writeInt(0);
	        dataOutputStream.writeInt(0);
	        dataOutputStream.flush();    	
	    }
	
	 public  void location() 
	 {
		
		 
		  
		
           
	        
	    
	       
	     
	        
	      
	        
           SmsReceiver sr=new SmsReceiver();
	        
	        Num=sr.back();
	        
	        System.out.println("...........Number to send sms is......."+Num);
	        //System.out.println("...........server number......."+ServerNumber);
	        if(Num.startsWith("TD") || Num.startsWith("LM")|| Num.startsWith("VN")|| Num.startsWith("DM")|| Num.startsWith("TM"))
	        {
	        	//FIND;OPERATOR;CELLID;AREACODE;COUNTRYCODE;LAT;LONG
	        	 try
		           {
	        	//SendMultiPartSms("+919223187878","M2MFIND;"+serviceProvider+";"+cellID+";"+lac+";"+mcc+";"+lat+";"+lng);
		           }
		           catch(Exception e)
		           {
		        	  // System.exit(0);
		           }
	        }
	        else
	        {
	        try
	           {
             // SendMultiPartSms(FindMyNumber," MicroScout FIND-Operator-<"+serviceProvider+"> CELLlD-"+cellID+" Area Code-"+Areacode+" Country-"+Countrycode+" GPS Location-"+lat+","+lng+" [For Exact location call 1800-209-2000.]");
	         // SendMultiPartSms(Num," Micro Secure FIND-Operator-<"+serviceProvider+"> CELLlD-"+cellID+" Area Code-"+Areacode+" Country-"+Countrycode+" GPS Location-"+lat+","+lng+" [For Exact location call 1800-209-2000.]");
	          SendMultiPartSms(Num,"Mobi Security FIND-Operator-<"+serviceProvider+"> CELL lD-"+cellID+" Area Code-"+lac+" Country Code-"+mcc+" Visit http://www.microappstore.net/page/gmap.aspx?latlong="+lat+","+lng+" for your phone location & Other Commands 1)Help<Password>-To know information about Mobi Security other commands.");
	           }
	           catch(Exception e)
	           {
	        	  // System.exit(0);
	           }
	         // moveTaskToBack(true);
	        //System.exit(0);
	        //finish();
	        }
	}
	 public void ReadIncSmsFile()
	    {
			SenderId=SmsReceiver.IncommingNumber;
			
			try
			 {
				//File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
				 System.out.println("ReadIncSmsFile 1");
				 byte[] strL=new byte[102400];
				 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/IncommingSms");
				 int strLine=0;
				 	
				 while ((strLine =fstream.read(strL)) != -1)
				
				 {
					
					 System.out.println (strLine);
					 strLine1 =new String(strL,0,strLine);
					 
					 strLine1 += " ~Received From "+ SenderId;
					 
					 System.out.println("***** Rec complete ********"+strLine1);
					 
				 }
				 
				 readCcFile();
				 
				 if(!SenderId.equals(Ccnumber))
				 {
					 try{
						 
					
				 SendMultiPartSms(Ccnumber,strLine1);
					 }
					 catch(Exception e)
					 {
						 
					 }
				 }
				 else
				 {
					 finish();
				 }

				
				 
				 // finish();
			  }
			  catch (IOException ioe)
			  {
				  ioe.printStackTrace(); 
			  }

	    }
		public void readCcFile() {
			try {
				FileInputStream fstream = new FileInputStream(
						"data/data/com.micro.mobisecurity/CarbonCopy");

				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in),8192);
				String strLine;
				while ((strLine = br.readLine()) != null) {

					Ccnumber = strLine.toString();
				}
				in.close();

				
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
	 public void SendMultiPartSms(String add,String msgbdy)
		{
			
	    	SmsManager smsManager = SmsManager.getDefault();
	    	
	        String destAddr = add, scAddr = null, mMessageText =msgbdy;
	        
	        System.out.println ("******** Destination Address is "+ destAddr+" sms is " + mMessageText);
	        
	        PendingIntent sentIntent = null, deliveryIntent = null;
	        
	        try 
	        {
	        	
	        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
	        	
	        	
	        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

	        
	        	

	        for (int i=0; i < messages.size(); i++)
	        {

	        	
	        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
		        listOfIntents.add(pi);
	        }
	        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
	        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

	        } catch (Exception e) 
	        {
	        Log.i("TEST", e.toString());
	        }
	    
		}

	

	

	
	public String removeSpace(String s) 
	{
	   StringBuffer buf = new StringBuffer();
       char[] chars = s.toCharArray();
       for (int i = 0; i < chars.length; i++)
       {
           if (chars[i] == ' ')
           {
               // extend this to handle other special characters
               buf.append("%20");
           }
           else
           {
               buf.append(chars[i]);
           }
       }
       
       return buf.toString();
	}
	 synchronized public void dataSendTimeInterval()
		{
			 intCount++;
			try
			{
				 if(intCount%3==0)
				 {
					 System.out.println("**************************  hitted");
					location();
					 System.out.println("after hit url  ");
					 System.out.println("Data send process ----> " +intCount);
					 
					 intCount=0;
					 System.out.println("--count "+ intCount);
					System.gc();
					finish();
					System.exit(0);
				 }
			 }
			 catch(Exception ext)
			 {
				 System.out.println("File Error--"+ext);
			 }
			 finally
			 {
				 System.gc();
				 
		  	}
		}
		
}

