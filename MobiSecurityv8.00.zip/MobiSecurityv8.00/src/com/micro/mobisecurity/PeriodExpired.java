package com.micro.mobisecurity;




import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.style.AlignmentSpan.Standard;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class PeriodExpired extends Activity implements OnClickListener
{
	 File ToggleBatteryOnOff=new File("data/data/com.micro.mobisecurity/BattInfo");
		File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
		File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
		File SettingFileNameField=new File("data/data/com.micro.mobisecurity/NameField");
		File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
		File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
		File BuddyListFile=new File("data/data/com.micro.mobisecurity/buddylist");
		 File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
		 File PhoneInfoFile=new File("data/data/com.micro.mobisecurity/PhoneInfoFile");
			File scoutRecFile=new File("data/data/com.micro.mobisecurity/ScoutRecFile");
			File Cc=new File("data/data/com.micro.mobisecurity/CarbonCopy");
	Button okButton,canButton;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.stdexp);
		
		okButton = (Button)this.findViewById(R.id.sd_OkButton);
        okButton.setOnClickListener(this);
        canButton = (Button)this.findViewById(R.id.sd_CancelButton);
        canButton.setOnClickListener(this);
	}
	
	public void onClick(View v)
	{
		if (v==okButton)
		{
			//setContentView(R.layout.standardform);
			 ToggleBatteryOnOff.delete();
			    BuddyFile.delete();
			    PinFile.delete();
			    SettingFileNameField.delete();
			    ToggleSirenOnSIMchng.delete();
			    ToggleAutoLockOnSIMchng.delete();
			    BuddyListFile.delete();
			    appactFile.delete();
			    PhoneInfoFile.delete();
			    Cc.delete();
			Intent stexttrialIntent = new Intent(this, MicroScout.class);
			startActivity(stexttrialIntent);
		}
		else if (v==canButton)
		{
			moveTaskToBack(true);
			finish();
		}
	}
}