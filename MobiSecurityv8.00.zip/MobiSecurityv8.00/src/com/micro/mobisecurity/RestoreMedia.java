package com.micro.mobisecurity;

import com.micro.mobisecurity.R;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class RestoreMedia extends ListActivity implements OnClickListener
{
	
	 ImageButton backup,image,audio,video;
	 
 
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
    	
    	System.out.println ("Inside onCreate method");
        super.onCreate(savedInstanceState);
     // Request the progress bar to be shown in the title
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setProgress(10000); // Turn it off for now
        try
        {
        	setContentView(R.layout.backuporrestoreimages);
        }
        catch (Exception ioe)
        {
        	ioe.printStackTrace();
        }
        //myPath = (TextView)findViewById(R.id.path);
        //getDir(root);
        
        selectButton();
       	
        
    }
    
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
    	super.onSaveInstanceState(savedInstanceState);
    }
    
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
    	  super.onRestoreInstanceState(savedInstanceState);
    }
    
    public void selectButton()
    {
    	 image = (ImageButton)findViewById(R.id.backupimage_button);
         audio = (ImageButton)findViewById(R.id.backupaudio_button);
         video = (ImageButton)findViewById(R.id.backupvideo_button);
         
         image.setOnClickListener(this);
         audio.setOnClickListener(this);
         video.setOnClickListener(this);
         
         
    }
    
    public void onClick(View v)
    {
    	if (v==image)
    	{
    		System.out.println ("User click on image ");
    		Intent restoreimageIntent = new Intent(this,ImageRestore.class);
			startActivity(restoreimageIntent);
    	}
    	
    	else if (v==audio)
    	{
    		System.out.println ("User click on audio");
    		Intent restoreaudioIntent = new Intent(this,MusicRestore.class);
			startActivity(restoreaudioIntent);
    		
    	}
    	
    	else if (v==video)
    	{
    		System.out.println ("User click on video");
    		Intent restorevideoIntent = new Intent(this,VideoRestore.class);
			startActivity(restorevideoIntent);
    		
    	}
    }
    
   
    
    protected void alertbox(String title, String mymessage)   
    {   
   	 new AlertDialog.Builder(this)   
       .setMessage(mymessage)   
       //.setTitle(title)   
       .setCancelable(true)   
       .setNeutralButton(android.R.string.ok,   
          new DialogInterface.OnClickListener() {   
          public void onClick(DialogInterface dialog, int whichButton){}   
          })   
       .show();   
    }
    
    
    	
	}
	    	 

