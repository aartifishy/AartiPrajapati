package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;

public class RestoreList extends ListActivity implements OnClickListener
{
	Button contacts,sms,media;
	String response,inputLine,str1,str2,str3,myRes,key,imei;
	int counter;
	String[] resArr,myBackup1;
	int i = 0;
	
	TextView selection;
	
	public void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.restoreimage);
		System.out.println ("Inside RestoreList class");
		noOfBackups();
		System.out.println ("After noOfBackup()");
		setListAdapter(new IconicAdapter(this));
		selection=(TextView)findViewById(R.id.selection);
		System.out.println ("At the end of onCreate()");
		
    }
	
	public void noOfBackups()
    {
    	try
    	{    	
    		checkIMSI();
    		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/masterlist.txt"); 
    		    		
    		BufferedReader in = new BufferedReader(new InputStreamReader(connectURL.openStream()));

            System.out.println ("Before while");
            
            while ((inputLine = in.readLine()) != null) 
            {    
            	System.out.println (inputLine);
            	myRes+=inputLine;
            
            }
            System.out.println ("MyRes="+myRes.substring(3));
            resArr = myRes.split("#");
            System.out.println ("*********************************************************");
        
        } 
    	
    	catch (UnknownHostException uhe)
    	{
    		alertbox("Information","Check your GPRS connection");
    	}
    	catch (MalformedURLException ex)
    	{ 
    		 //Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	} 
    }
	
	
	public void onListItemClick(ListView parent, View v,int position, long id)
	{
		System.out.println ("inside onListItemClick()");
		System.out.println ("****"+resArr[position]);
		Bundle bd = new Bundle();
		bd.putStringArray(key ,resArr);
		Intent restoreIntent = new Intent(this, Restore.class);
		//startActivity(restoreIntent);
		startActivityForResult(restoreIntent, 1);
		
	 	
	}

	class IconicAdapter extends ArrayAdapter {
		Activity context;
		
		IconicAdapter(Activity context) {
			super(context, R.layout.row, resArr);
			
			this.context=context;
		}
		
		public View getView(int position, View convertView,
												ViewGroup parent) {
			LayoutInflater inflater=context.getLayoutInflater();
			View row=inflater.inflate(R.layout.row, null);
			TextView label=(TextView)row.findViewById(R.id.rowtext);
			
			label.setText(resArr[position]);
			
		
			
			return(row);
		}
	}
	
	
	protected  void alertbox(String title, String mymessage)   
    {   
   	 new AlertDialog.Builder(this)   
       .setMessage(mymessage)   
       //.setTitle(title)   
       .setCancelable(true)   
       .setNeutralButton(android.R.string.ok,   
          new DialogInterface.OnClickListener() {   
          public void onClick(DialogInterface dialog, int whichButton){}   
          })   
       .show();   
    }
	public void checkIMSI()
	{
		
		try
		{
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
		
		}
		catch (Exception cnfe)
		{
			cnfe.printStackTrace();
		}   

	}
	
	public void onClick (View v)
	{
		if (v==contacts)
		{
			System.out.println ("User click on contacts");
		}
		
		else if (v==sms)
		{
			System.out.println ("User click on sms");
		}
		
		else if (v==media)
		{
			System.out.println ("User click on Media");
		}
	}
}
