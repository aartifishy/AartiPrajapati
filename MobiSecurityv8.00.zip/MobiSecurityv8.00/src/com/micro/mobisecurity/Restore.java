package com.micro.mobisecurity;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class Restore extends Activity implements OnClickListener
{
	ImageButton contacts,sms,media,calendar;
	
	public void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.backuplist);
		System.out.println ("At the end of onCreate() in Restore class");
		
		contacts= (ImageButton)this.findViewById(R.id.contacts_button);
		sms = (ImageButton)this.findViewById(R.id.sms_button);
		//calendar = (Button)this.findViewById(R.id.calendar_button);
		media = (ImageButton)this.findViewById(R.id.media_button);
		 	 	
		 contacts.setOnClickListener(this);
		 sms.setOnClickListener(this);
		 //calendar.setOnClickListener(this);
		 media.setOnClickListener(this);
    }
	
	public void onClick(View v)
	{
		if (v==contacts)
		{
			System.out.println ("contacts");
			Intent contactresIntent = new Intent(this,RestoreContact.class);
			startActivity(contactresIntent);
		}
		
		else if (v==sms)
		{
			System.out.println ("sms");
			Intent messageresIntent = new Intent(this,Restoremessages.class);
			startActivity(messageresIntent);
		}
		/*else if (v==calendar)
		{
			System.out.println ("sms");
			Intent calendarIntent = new Intent(this,RestoreCalendar.class);
			startActivity(calendarIntent);
		}*/
		else if (v==media)
		{
			System.out.println ("sms");
			Intent mediaIntent = new Intent(this,RestoreMedia.class);
			startActivity(mediaIntent);
		}
	}
}
