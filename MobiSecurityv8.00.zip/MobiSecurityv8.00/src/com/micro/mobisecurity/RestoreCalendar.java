package com.micro.mobisecurity;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Contacts.People; 
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class RestoreCalendar extends Activity 
{
	String inputLine,str,wholeCalendar;
	//StringBuffer wholeSMS;
	String strLine;
	String sb ;
	String[] arr;
	String[]arr1;
	String from;
	String msg,imei;
	String str1,str2,str3;
	File calendarFile = new File("data/data/com.micro.mobisecurity/calendarFile.txt");
	Handler mHandler = new Handler();
	private int count=0;
	private static final int NOTIFY_ME_ID=1337;
	
	Button calendarRestore;
	 Context c;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.calendarrestore);
        System.out.println ("Inside onCreate of ReadSMS");  
        calendarRestore();
        /* selectButton();
      
        System.out.println ("after select button");  */
        //calendarRestore = (Button)findViewById(R.id.calendarrestore_button);
        System.out.println ("Inside onCreate of ReadSMS 1");  
   	  
        //calendarRestore.setOnClickListener(this);
     System.out.println ("Inside onCreate of ReadSMS 3");  
     
    }
    
    
    public void calendarRestore()
    {
    	
    	
    	
    		//setContentView(R.layout.smstoserver);
    		//setContentView(R.layout.inboxorsentbackupsms);
    		//selectInboxOrSentboxRestore();
    		System.out.println ("User click on intboxRestore button");
				setContentView(R.layout.calendarfromserver);
				Thread t = new Thread(){
			   public void run()
			   {
				   	readWebPage();
	        	System.out.println ("After restore sms"); 
	        	//System.out.println ("????????????????"+inputLine.length());
	        	writeCalendarToFile();
	        	readCalendarFromFile();
	        	mHandler.post(new Runnable() {
			            public void run()
			            {
			            	setContentView(R.layout.calendarrestore);
			           	    notifyMe();
			            }
			    	});
				 				   
			   }
			};

			t.start(); 
    		
    			 
    		
    		
    	
    	
    		
    }
 
    
    
    private void notifyMe()
	{
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your Calendar are restored succesfully.", i);
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}
    
    
 
    
    
      
    
    
    public void restoreCalendar(String str22, String title)
    {
    	ContentValues values = new ContentValues();
    	values.put("calendar_id", str22);          
    	values.put("title", title);
    
		//values.put("dtstart", ""+calendarfrom.getTimeInMillis());
    	//values.put("dtend", ""+calendarto.getTimeInMillis());
    	values.put("hasAlarm", 0);

    	getContentResolver().insert(Uri.parse("content://com.android.calendar/events"), values);
    	System.out.println ("Inside restoreSMS method");

    }
    public void checkIMSI()
	{
		
		try
		{
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
		
		}
		catch (Exception cnfe)
		{
			cnfe.printStackTrace();
		}   

	}
    public void readWebPage()
    {
    	System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%Inside readWebPage method");
    	   try { 
    		   checkIMSI();
    		   //http://www.microlifeline.net/new/users/ Licencekey/masterlist.txt
               //URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/Backup_1%5Caddressbook.txt");
    	   URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/Backup_1%5Ccalendar.txt");
               BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream())); 
               DataInputStream dis=new DataInputStream(yahoo.openStream());
               System.out.println("Data Input Stream Data--"+dis.readLine());
               System.out.println ("Before while");
               while ((inputLine = in.readLine()) != null) 
               
               { 
            	   
            	   System.out.println ("Inside while");
            	   System.out.println(inputLine); 
            	   wholeCalendar=wholeCalendar+inputLine;
            	   
               } 
             
               System.out.println ("####################"+wholeCalendar.length());
               System.out.println ("####################"+wholeCalendar);
               in.close(); 
           } catch (MalformedURLException me) { 
               System.out.println(me); 
       
           } catch (IOException ioe) {  
               System.out.println(ioe); 
           }  

    }
   
    public void writeCalendarToFile() 
    {
    	try
    	{
    		calendarFile.createNewFile();
    		System.out.println ("Inside writeCalendarToFile");
    		PrintWriter out = new PrintWriter(calendarFile);
    		System.out.println ("After crating PrintWriter object");
    		System.out.println ("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR"+wholeCalendar);
    		out.write(wholeCalendar);
    		out.flush();
    		out.close();
    	}
    	catch (IOException ioe)
    	{
    		ioe.printStackTrace();
    	}
    	 
    	
    }
    
    public void readCalendarFromFile()
    {
    
    	
    	try
		{
    			System.out.println ("Inside try block of readSMSFromFile method");
				FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/calendarFile.txt");
		
    			DataInputStream in = new DataInputStream(fstream);
        		BufferedReader br = new BufferedReader(new InputStreamReader(in));
        		System.out.println ("Before while");
        		while ((strLine = br.readLine()) != null)
    			{
        			System.out.println ("***************************************");
    				System.out.println (strLine);
    				str = strLine.toString(); 
    				    				    				
    			}
        	      		
        		System.out.println ("outside of while");
        		System.out.println (str);
        		arr = str.split("~~");  
        		System.out.println (arr[0]);
        		for (int i =0;i<arr.length-1;i++)
        		{
        			System.out.println ("......................1");
        			str1 = arr[i];
        			//restoreSMS(str1.substring(0,str1.indexOf("µ")),str1.substring(str1.indexOf("µ")+1,str1.length()));
        			System.out.println ("......................2"+str1);
        			arr1 = str1.split("µ");
        			System.out.println ("......................2"+arr1);
        			str2 = arr1[0];
        			System.out.println ("......................2"+str2);
        			str3 = arr1[1];
        			System.out.println ("......................2"+str3);
        			System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!");
        			System.out.println (str2);		
        			System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!");
        			System.out.println (str3); 
        			restoreCalendar(str2,str3);
        		}
        		/*arr = str.split(")))");  
        		System.out.println ("After split with ### now size of arr is"+arr.length);
        		System.out.println (str); 
       			 			
       			for (int i=0;i<arr.length-1;i++)
       			{
       				System.out.println ("Inside for loop of split");
       				str1= arr[i];
       				String[] arr2 = str1.split("(((");
       				from = arr2[0];
       				System.out.println ("$$$$$$$$$$"+from);
       				msg = arr2[1];
       				System.out.println ("$$$$$$$$$$"+msg);
       				resroreSMS(from,msg);
       			}*/
       			in.close();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
    }
    
 
    
 

}