package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TextView;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
 
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
 
public class VideoRestore extends Activity  {
    /** Called when the activity is first created. */
 
    //initialize a button and a counter
    Button btn,firstBackup;
    String inputLine3,wholeVideo;
    String str1,str2,str3,imei;
    int counter = 0,p=0;  
    String[] strArr;
    static Vector vct2;
    String folderName,bkuFolder,type,fileName,newFileName;          
    String strLine,str;
	File video = new File("data/data/com.micro.mobisecurity/video.3gp");
    File videoFile = new File("data/data/com.micro.mobisecurity/videoFile.txt");
    int a,size,total;
    FileOutputStream out1;
    @SuppressWarnings({ "rawtypes", "unused" })
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
    	System.out.println ("Inside oncreate");
        super.onCreate(savedInstanceState);
     // Request the progress bar to be shown in the title
	       requestWindowFeature(Window.FEATURE_PROGRESS);
	       setProgress(10000); // Turn it off for now
        calCulateIMEI();
        // setup the layout
        setContentView(R.layout.restoreimage);
        System.out.println ("****Counter is "+counter);
        Vector test = countBackup();
      
        //new MyList(test);
        System.out.println ("after countBackup");
		Intent VideoListIntent = new Intent(this,VideoList.class);
		startActivity(VideoListIntent);
        // add a click-listener on the button
        //btn = (Button) findViewById(R.id.Button01);
        //btn.setOnClickListener(this);
     /*   for (int i=1;i<test;i++)
        {
        	System.out.println ("Inside for loop");
        	TableLayout table = (TableLayout) findViewById(R.id.TableLayout01);
        	 
            //create a new TableRow
            TableRow row = new TableRow(this);
     
            // count the counter up by one
           
     
            // create a new TextView
           // TextView t = new TextView(this);
            // set the text to "text xx"
            //t.setText("text " + counter);
     
            // create a CheckBox
            System.out.println ("Value of i is"+i);
          
            
            if (i==1)
            {            	
            	System.out.println ("99999999999999"+str1);
            	//b.setText("BackUp1");
            	Button b = new Button(this);
            	b.setOnClickListener(this);
            	b.setText(str1);
            	a=1;
            	row.addView(b);
            	b.setOnClickListener(new OnClickListener(){
            	
					@Override
					public void onClick(View v)
					{
						// TODO Auto-generated method stub
						System.out.println ("User Click on backup1 button");
						//UserID= "42";
						
						int deo = str1.indexOf('~')+1;
						int deo1 = str1.indexOf('\\');
						folderName =str1.substring(deo,deo1);
						String remainingString = str1.substring(deo1+1);
						
						System.out.println ("Folder name is "+folderName);
						System.out.println ("Remaining string is"+remainingString);
						int deo2 = remainingString.indexOf('\\');
						System.out.println (deo2);
						type = remainingString.substring(0,deo2);
						System.out.println (type);
						
					    fileName = remainingString.substring(deo2+1);
						System.out.println (fileName);
						byte[] fileArray = fileName.getBytes();
						newFileName = Base64.encode(fileArray);
						System.out.println ("$$$$$$$$$$$$$$$$$$"+newFileName);
						restoreImage();
					}
            	});
            }
            else if (i==3)
            {
            	System.out.println ("99999999999999"+str2);
            	//b.setText("BackUp2");
            	Button b = new Button(this);
            	b.setOnClickListener(this);
            	b.setText(str2);
            	row.addView(b);
            	a=2;
            	b.setOnClickListener(new OnClickListener(){
                	
					@Override
					public void onClick(View v)
					{
						// TODO Auto-generated method stub
						System.out.println ("User Click on backup2 button");
						
						//UserID= "42";
						
						int deo = str2.indexOf('~')+1;
						int deo1 = str2.indexOf('\\');
						folderName =str2.substring(deo,deo1);
						String remainingString = str2.substring(deo1+1);
						
						System.out.println ("Folder name is "+folderName);
						System.out.println ("Remaining string is"+remainingString);
						int deo2 = remainingString.indexOf('\\');
						System.out.println (deo2);
						type = remainingString.substring(0,deo2);
						System.out.println (type);
						
					    fileName = remainingString.substring(deo2+1);
						System.out.println (fileName);
						byte[] fileArray = fileName.getBytes();
						newFileName = Base64.encode(fileArray);
						System.out.println ("$$$$$$$$$$$$$$$$$$"+newFileName);
						restoreImage();
						
					}
            	});
            	
            }
            else if (i==5)
            {
            	System.out.println ("99999999999999"+str3);
            	//b.setText("BackUp3");
            	Button b = new Button(this);
            	b.setOnClickListener(this);
            	b.setText(str3);
            	row.addView(b);
            	a=3;
            	b.setOnClickListener(new OnClickListener(){
                	
					@Override
					public void onClick(View v)
					{
						// TODO Auto-generated method stub
						System.out.println ("User Click on backup3 button");
						
						//UserID= "42";
						
						int deo = str1.indexOf('~')+1;
						int deo1 = str1.indexOf('\\');
						folderName =str1.substring(deo,deo1);
						String remainingString = str1.substring(deo1+1);
						
						System.out.println ("Folder name is "+folderName);
						System.out.println ("Remaining string is"+remainingString);
						int deo2 = remainingString.indexOf('\\');
						System.out.println (deo2);
						type = remainingString.substring(0,deo2);
						System.out.println (type);
						
					    fileName = remainingString.substring(deo2+1);
						System.out.println (fileName);
						byte[] fileArray = fileName.getBytes();
						newFileName = Base64.encode(fileArray);
						System.out.println ("$$$$$$$$$$$$$$$$$$"+newFileName);
						restoreImage();
						
					}
            	});
            }
            
     
            // add the TextView and the CheckBox to the new TableRow
            //row.addView(t);
            
     
            // add the TableRow to the TableLayout
            table.addView(row,new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            i++;
        }*/
      
        /*System.out.println ("********************"+strArr.length);
        System.out.println (str1);
        System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println (str2);*/
 
    }
    
    private void calCulateIMEI() {
		// TODO Auto-generated method stub
   	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	} 

	public void onSaveInstanceState(Bundle savedInstanceState)
    {
    	super.onSaveInstanceState(savedInstanceState);
    }
    
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
    	  super.onRestoreInstanceState(savedInstanceState);
    }
    
   
    
 
  
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector countBackup()
    {
    	//int p = 0;
    	vct2=new Vector();
    	try
    	{
    	 	System.out.println ("Inside countBackup");
    		    	
    	  	URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/masterlist.txt");
    	   	//URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/masterlist.txt"); 
            BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream()));
            
            System.out.println ("Before while");
            
            while((inputLine3 = in.readLine()) != null) 
        
            {   
            	if(inputLine3.endsWith(".3gp")||inputLine3.endsWith(".avi")||inputLine3.endsWith(".wmv")||inputLine3.endsWith(".mp4")||inputLine3.endsWith(".mpg"))
            	{
            	str1=inputLine3.trim();
            	vct2.addElement(str1);
            	System.out.println("string array--->"+p+" is "+str1);
            	str1="";
            	p++;
            	}
            	/*System.out.println ("^^^^^^^^^^^^^^"+counter);
        			System.out.println (inputLine);
        			if (counter==0)
        			{
        				str1 = inputLine.trim();
        				System.out.println ("############# str1::"+str1);
        			}
        			else if (counter==2)
        			{
        				str2 = inputLine.trim();
        				System.out.println ("############# str2::"+str2);
        			}
        			else if (counter==4)
        			{
        				str3 = inputLine.trim();
        				System.out.println ("############# str3::"+str3);
        				//System.out.println ("#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$####");
        			}
        			System.out.println ("***");
        			         			
        			System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        			System.out.println (counter);
        			System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        			counter++;
        			p++;
        			//System.out.println ("$$$$$$$$$$$$$$$$$$$$"+p);
        			  // get a reference for the TableLayout
        	       */
            } 
           
            	//out.flush();
    			//out.close();
            System.out.println("vector size-->"+vct2.size());
            
           System.out.println ("At the end of try");
           
         
          
    	}
    	catch (Exception e)
    	{
    		e.printStackTrace();
    	}
    	  return vct2;
    }
    
    protected void alertbox(String title, String mymessage)   
    {   
   	 new AlertDialog.Builder(this)   
       .setMessage(mymessage)   
       //.setTitle(title)   
       .setCancelable(true)   
       .setNeutralButton(android.R.string.cancel,   
          new DialogInterface.OnClickListener() {   
          public void onClick(DialogInterface dialog, int whichButton){}   
          })   
       .show();   
    }
}