package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ParseException;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class GeneralSetting extends  ListActivity
{
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	private Dialog editorDialog = null;
	
	static final int DIALOG_Email = 0;
	static final int DIALOG_Name = 1;
	static final int DIALOG_ChangePIN = 2;
	Dialog source;
	EditText nameField;
    String name;
    SharedPreferences mPrefs;
    String PREFS = "MyPrefs";
    SharedPreferences app_preferences;
    public static final String PREFS_NAME = "MyPrefsFile";
    private static final String PREF_USERNAME = "username";
  
    private static final String PREF_STATUS = "status";

    public static SharedPreferences sharedPrefs ;
    File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
    
	//File SettingFileNameField=new File("data/data/com.micro.mobisecurity/NameField");
	File SettingFileNameField=new File("data/data/com.micro.mobisecurity/NameField");
	File SettingFileEmailField=new File("data/data/com.micro.mobisecurity/EmailField");
	File unPinFile=new File("data/data/com.micro.android.unlock/PIN");
	File sdpinFile=new File("/sdcard/PIN");
	String prefName, ReadFilePin;
	RowData rd;
	String user,fullString,NameString,pinString;
	String[]arr;
	EditText userId;
	boolean cnt; 
	static final String[] title = new String[] {
	   "Change Name", "Change Buddy","Change Password"};
	static final String[] detail = new String[] {
		"Change Your Name","Security Alert Will Be Sent To Your Buddies Via SMS. ","Change Your Current Password"};
	private Integer[] imgid = {R.drawable.change_name,R.drawable.change_buddy,R.drawable.changepin};
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main1);
		
		mInflater = (LayoutInflater) getSystemService(
		Activity.LAYOUT_INFLATER_SERVICE);
		
		data = new Vector<RowData>();
		
		mPrefs = getSharedPreferences(PREFS, 0);
		
		for(int i=0;i<title.length;i++)
		{
			try {
			 	rd = new RowData(i,title[i],detail[i]);
			    } 
			catch (ParseException e) 
			{
			    	e.printStackTrace();
			}
		   data.add(rd);
		}
		System.out.println("cnt value::"+cnt);
		if(cnt==true)
	    {
	    	System.out.println("inside cnt trueeeeeeeeee");
	    	prefName=mPrefs.getString("name", null);
	    	if(prefName!=null)
	    	{
	    		
	    		System.out.println("######### prefName!=null "+prefName);
	    		nameField = (EditText) this
	    	    .findViewById(R.id.NameText);
	    		
	    		
	    		System.out.println("######### prefName!=null@@@@@@@ "+prefName);
	        //prefName=mPrefs.getString("name", null);
	        //String name = nameField.getText().toString();
	        nameField.setText(prefName);
	    	System.out.println("######### prefName!=null");
	    	}
	    	else
	    	{
	    		
	    		System.out.println("######### else prefNam");
	    	}
	    }
		   CustomAdapter adapter = new CustomAdapter(this, R.layout.firstlist,R.id.title, data);
		   setListAdapter(adapter);
		   getListView().setTextFilterEnabled(true);
	}
	   public void onListItemClick(ListView parent, View v, int position,long id) 
	   {  
		   if (position == 0)
		   {
			 //open DialogBox for Name
			  /* Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, ChangeUserName.class.getName());
	   			startActivity(intent);*/
			  showDialog(DIALOG_Name);
		   }
		   else if (position == 1 )
		   {
			    //Start activity for Add Buddy
			    Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, AddBuddyClick.class.getName());
	   			startActivity(intent);
		   }
		  /* else if (position == 1)
		   {
			   //open DialogBox for Change Email
			Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, ChangeEmailId.class.getName());
	   			startActivity(intent);
			  showDialog(DIALOG_Email);
		   }*/
		   
		   else if (position == 2)
		   {
			 //open DialogBox for Change PIN
			   showDialog(DIALOG_ChangePIN);
		   }
		 
	   }
	       private class RowData 
	       {
	       protected int mId;
	       protected String mTitle;
	       protected String mDetail;
	       RowData(int id,String title,String detail)
	       	   {
		       mId=id;
		       mTitle = title;
		       mDetail=detail;
		       }
	       
		       @Override
		       public String toString() 
		       {
		               return mId+" "+mTitle+" "+mDetail;
		       }
	       }
	       
	  private class CustomAdapter extends ArrayAdapter<RowData> 
	  {
		  public CustomAdapter(Context context, int resource,int textViewResourceId, List<RowData> objects) 
		  {               
			  super(context, resource, textViewResourceId, objects);
		  }
	       @Override
	       public View getView(int position, View convertView, ViewGroup parent) 
	       {   
	       ViewHolder holder = null;
	       TextView title = null;
	       TextView detail = null;
	       ImageView i11=null;
	       RowData rowData= getItem(position);
	       if(null == convertView)
	       {
	            convertView = mInflater.inflate(R.layout.firstlist, null);
	            holder = new ViewHolder(convertView);
	            convertView.setTag(holder);
	       }
	             holder = (ViewHolder) convertView.getTag();
	             title = holder.gettitle();
	             title.setText(rowData.mTitle);
	             detail = holder.getdetail();
	             detail.setText(rowData.mDetail);                                                     
	             i11=holder.getImage();
	             i11.setImageResource(imgid[rowData.mId]);
	             return convertView;
	       }
	            private class ViewHolder 
	            {
	            private View mRow;
	            private TextView title = null;
	            private TextView detail = null;
	            private ImageView i11=null; 
	            public ViewHolder(View row) 
	            {
	            mRow = row;
	            }
	         public TextView gettitle() 
	         {
	             if(null == title)
	             {
	                 title = (TextView) mRow.findViewById(R.id.title);
	             }
	            return title;
	         }     
	         public TextView getdetail() 
	         {
	             if(null == detail)
	             {
	                  detail = (TextView) mRow.findViewById(R.id.detail);
	             }
	           return detail;
	         }
	        public ImageView getImage() 
	        {
	             if(null == i11)
	             {
	                  i11 = (ImageView) mRow.findViewById(R.id.img);
	             }
	                return i11;
	        }
	     }
	   } 
	  
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	     
					Create Dialog For Change Email
					Create Dialog For Change Email
					Create Dialog For Change Email
					

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	*/				
	  
	  
	  

	  @Override
	    protected Dialog onCreateDialog(int id)
	    {
	        Dialog editor = editorDialog;
	        
	       
	        
	        if (editorDialog == null)
	        {
	        	 switch(id)
	        	 {
	        	 
	        	 

	        	 case DIALOG_Name:
	        	 editor = createEditorDialogForName();
		         
	        
	        		// ChangeName();
	        		 break;
		         
	        	 case DIALOG_ChangePIN:
		        editor = createEditorDialogForPinChange();
	        	 //ChangePIN();	 
			     break;

	        	 }
	            
	        }
	        return editor;
	    }
	  

	 
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	    					Create Dialog For Change Name
	    					Create Dialog For Change Name
	    					Create Dialog For Change Name
	    					
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	    
private Dialog createEditorDialogForName()
{

    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle(R.string.addDialogTitleName);

    View content = getLayoutInflater().inflate(R.layout.changename,
    (ViewGroup) findViewById(R.id.editLayout));
    builder.setView(content);
    //app_preferences=  PreferenceManager.getDefaultSharedPreferences(this);
    
    
    

    
    
    builder.setPositiveButton(R.string.OkButton,
        new DialogInterface.OnClickListener()
        {
    		
            public void onClick(DialogInterface dialog, int which)
            {
               
            	mPrefs=getSharedPreferences(PREFS, 0);
                 source = (Dialog) dialog;
                 nameField = (EditText) source
                    .findViewById(R.id.NameText);
                //prefName=mPrefs.getString("name", null);
                //String name = nameField.getText().toString();
               // nameField.setText(name);
                prefName=nameField.getText().toString();
                if(prefName.equals(""))
                {
              	  alertbox("Mobi Security","Please enter your name.");
                }
                else if(prefName.length()<4 || prefName.length()>16)
                {
              	  alertbox("Mobi Security","Please enter valid name.");
                }
                else
                {
                //nameField.setText(prefName);
                System.out.println("@@@@@@@@@@ "+prefName);
                FileWrite(SettingFileNameField,prefName);
                //SharedPreferences.Editor editor = app_preferences.edit();
                //editor.putString("counter", name);
                //editor.commit();
                
                //nameField.setText(name);
                
               saveName();
  
               cnt=true;

               alertbox("Mobi Security","Successfully updated your name.");
      
                }
        

                
                dialog.dismiss();
            }
        });

    builder.setNegativeButton(R.string.CancelButton,
        new DialogInterface.OnClickListener()
        {

            public void onClick(DialogInterface dialog, int which)
            {
            	//removeName();
            	cnt=false;
                dialog.dismiss();
            	
            	
            }
        });

    return builder.create();
}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
 						
 						Create Dialog For Change PIN
 						Create Dialog For Change PIN
 						Create Dialog For Change PIN
 						
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

private Dialog createEditorDialogForPinChange()
{
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle(R.string.addDialogTitlePIN);

    View content = getLayoutInflater().inflate(R.layout.changepin,
    (ViewGroup) findViewById(R.id.editLayout));
    builder.setView(content);
    
    
    builder.setPositiveButton(R.string.OkButton,
        new DialogInterface.OnClickListener()
        {
    		
            public void onClick(DialogInterface dialog, int which)
            {
                
            	
            	Dialog source = (Dialog) dialog;
            	
                EditText CurrentPIN = (EditText) source
                    .findViewById(R.id.CurrentPINText);
               
                readPinFile();
                String CurrentPINText = CurrentPIN.getText().toString();
                
                EditText NewPIN = (EditText) source
                .findViewById(R.id.NewPINText);
            
                String NewPINText = NewPIN.getText().toString();
                
                EditText ConfrmNewPIN = (EditText) source
                .findViewById(R.id.RetypeNewPINText);
            
                String ConfrmNewPINText = ConfrmNewPIN.getText().toString();
          if(CurrentPINText.equals("") || NewPINText.equals("") || ConfrmNewPINText.equals(""))
             {
        	  alertboxAfterPinInfoWrong("Mobi Security","Please enter all details.");
             }
          else if(CurrentPINText.equals(""))
          {
        	  alertboxAfterPinInfoWrong("Mobi Security","Please enter current password.");
          }
          else if(NewPINText.equals(""))
          {
        	  alertboxAfterPinInfoWrong("Mobi Security","Please enter new password.");
          }
          else if(ConfrmNewPINText.equals(""))
          {
        	  alertboxAfterPinInfoWrong("Mobi Security","Please enter confirm new password.");
          }
          else if(!CurrentPINText.equals(ReadFilePin))
                {
        	  alertboxAfterPinInfoWrong("Mobi Security","Please enter correct old password.");
                }
                else if(!NewPINText.equals(ConfrmNewPINText))
                {
                	alertboxAfterPinInfoWrong("Mobi Security","Please enter same new password & confirm password.");
                }
                else
                {
                	//FileWrite(sdFile,ConfrmNewPINText);
                	 // FileWrite(PinFile,ConfrmNewPINText);
                	  try
                    	{
                    	  FileWrite(PinFile,ConfrmNewPINText);
                    	}
                    	catch(Exception e)
                    	{
                    		System.out.println("file writing probvlem"+e);
                    	}
                	  try
                  	{
                  	  FileWrite(unPinFile,ConfrmNewPINText);
                  	}
                  	catch(Exception e)
                  	{
                  		System.out.println("file writing probvlem"+e);
                  	}
                  	try
                  	{
                  	  FileWrite(sdpinFile,ConfrmNewPINText);
                  	}
                  	catch(Exception e)
                  	{
                  		System.out.println("file writing probvlem"+e);
                  	}
                	  try
      	        	{
      	        	//SendMultiPartSms("+919223187878","M2MPin;"+ConfrmNewPINText);
      	        	}
      	        	catch(Exception e)
      	        	{
      	        		System.out.println(e);
      	        	}
                	  alertbox("Mobi Security","Successfully updated password.");
                }
              
                dialog.dismiss();
            }

			
        });

    builder.setNegativeButton(R.string.CancelButton,
        new DialogInterface.OnClickListener()
        {

            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            	
            	
            }
        });

    return builder.create();
}
public void readPinFile()
{
 
	try
	 {
		 System.out.println ("INSIDE THE READRECFILE");
		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/PIN");
		 System.out.println ("INSIDE THE READRECFILE2");	
		 DataInputStream in = new DataInputStream(fstream);
		 System.out.println ("INSIDE THE READRECFILE3");	
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 System.out.println ("INSIDE THE READRECFILE4");	
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println (strLine);
			 ReadFilePin = strLine.toString();
		 }
	     in.close();
	     System.out.println ("Full String is:- " +ReadFilePin);
	    
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
@Override
protected void onPrepareDialog(int id, Dialog dialog)
{
	switch (id)
	{
		case DIALOG_ChangePIN:
		{
			readPinFile();
			//dialog.setTitle("Custom dialog 1");
			EditText CurrentPIN = (EditText)dialog
            .findViewById(R.id.CurrentPINText);
			/*EditText cdField1Edit = (EditText)dialog.findViewById(R.id.cdField1Edit);
			EditText cdField2Edit = (EditText)dialog.findViewById(R.id.cdField2Edit);*/

			// Set the default values for Field 1 and 2
			//cdField1Edit.setText("");
			CurrentPIN.setText(ReadFilePin != null ? ReadFilePin : "");
		}
		break;
		case DIALOG_Name:
		{
			ReadNameFieldFile();
			//dialog.setTitle("Custom dialog 1");
			
			EditText nameField = (EditText) dialog
            .findViewById(R.id.NameText);
			/*EditText cdField1Edit = (EditText)dialog.findViewById(R.id.cdField1Edit);
			EditText cdField2Edit = (EditText)dialog.findViewById(R.id.cdField2Edit);*/

			// Set the default values for Field 1 and 2
			//cdField1Edit.setText("");
			nameField.setText(fullString != null ? fullString : "");
		}
		break;
	}
}
public void ReadNameFieldFile()
{
	
	try
	 {
		    
		 //FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/SettingFileNameField");
		FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/NameField");
		 DataInputStream in = new DataInputStream(fstream);
		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
		 String strLine;
		 while ((strLine = br.readLine()) != null)
		 {
			 System.out.println ("@@@@ while STRLINE is "+strLine);
			 fullString = strLine.toString();
		 }
	     in.close();
	     
	     arr = fullString.split("\\?");
	       			
	     for (int i=0;i<arr.length;i++)
	     	
	     NameString=arr[0];	 
	     
	     System.out.println ("#####observer is "+NameString);
	    
	     
	  }
	  catch (IOException ioe)
	  {
		  ioe.printStackTrace(); 
	  }
}

public  void FileWrite(File aPath,String aBody)
{
	try 
	{
		 System.out.println("@@@@ Inside Try FileWrite @@@@");
		 
		 aPath.createNewFile();
		 PrintWriter out1 = new PrintWriter(aPath);
		 out1.write(aBody);  
		 System.out.println (aBody.trim());
		 out1.flush();
		 out1.close();
	}
	catch (IOException ioe)
	 {
		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
		ioe.printStackTrace();
	 }
	
}
private void saveName()
{
	  cnt=true;
	 nameField = (EditText) source
     .findViewById(R.id.NameText);
	 prefName=nameField .getText().toString();
	 
	 System.out.println("!!!!!!!saveName "+prefName);
	 
	 Editor e=mPrefs.edit();
	 e.putString("name", prefName );
	 e.commit();
}
private void removeName()
{
	
	 nameField = (EditText) source
     .findViewById(R.id.NameText);
	 prefName=nameField .getText().toString();
	 
	 Editor e=mPrefs.edit();
	 e.remove("name" );
	 e.commit();
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
private Dialog createEditorDialogForName1()
{
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle(R.string.addDialogTitleName);

    View content = getLayoutInflater().inflate(R.layout.changename,
    (ViewGroup) findViewById(R.id.editLayout));
    builder.setView(content);
    
    if (SettingFileNameField.exists())
    {
    	ReadNameFieldFile();
        
    	System.out.println("file exist n body is "+NameString);
    	
    	nameField = (EditText)this.findViewById(R.id.NameText);
    	System.out.println("file exist 1"+nameField);
    	NameString=nameField .getText().toString();
    	//name=NameString;
    	System.out.println("file exist 2");
    	FileWrite(SettingFileNameField,NameString);
    	System.out.println("@@@@@@@@@@@@@@@ name "+name);
    	System.out.println("@@@@@@@@@@@@@@@ NameString "+NameString);
    	
    	//nameField.setText("Micro");
    	
    	//nameField.setText(NameString);
    	
    	
    	
    }
    else
    {
    	System.out.println("file not exist");
    	
    }
    
    
    builder.setPositiveButton(R.string.OkButton,
        new DialogInterface.OnClickListener()
        {
    		
            public void onClick(DialogInterface dialog, int which)
            {
                /**/
            	
            	//con();
            	
            	Dialog source = (Dialog) dialog;
                EditText nameField = (EditText) source
                    .findViewById(R.id.NameText);
                
                String name = nameField.getText().toString();
              
                FileWrite(SettingFileNameField,name);
                
                
        

                
                dialog.dismiss();
            }
        });

    builder.setNegativeButton(R.string.CancelButton,
        new DialogInterface.OnClickListener()
        {

            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            	
            	
            }
        });

    return builder.create();
}



private void openAboutDialog()
{
	/*AlertDialog.Builder dialog = new AlertDialog.Builder( this );
	dialog.setView( getLayoutInflater().inflate( R.layout.changename, null ) );
	nameField = (EditText)this.findViewById(R.id.NameText);
	nameField.setText("manmay");
	//dialog.setTitle( getString( R.string.about_jumpy_title ) );
	dialog.setPositiveButton( getString( R.string.OkButton ), null );
	dialog.show();*/
	
	setContentView(R.layout.changename);
	nameField = (EditText)this.findViewById(R.id.NameText);
	//nameField.setText("manmay");
	
	
}


protected void alertboxAfterPinInfoWrong(String title, String mymessage)     
{
// Code here to display alert box
   	// Create the alert box
          AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

          // Set the message to display
          alertbox.setMessage(mymessage);
          //alertbox.setTitle(title);
          // Add a neutral button to the alert box and assign a click listener
          alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() 
          {

              // Click listener on the neutral button of alert box
              public void onClick(DialogInterface arg0, int arg1) 
              {
            	  System.out.println("inside change password alert");
            	  showDialog(DIALOG_ChangePIN);
              }
          }
          
          
          
          );
          
         
           // show the alert box
          alertbox.show();  
}	 

//editor = createEditorDialogForPinChange();

protected void alertbox(String title, String mymessage)     
{
	new AlertDialog.Builder(this)   
	.setMessage(mymessage)   
	//.setTitle(title)   
	.setCancelable(true)   
	.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
	
	{   
	public void onClick(DialogInterface dialog, int whichButton)
		{
    	
		}   
	}
	)   
	.show();   
}
public void SendMultiPartSms(String add,String msgbdy)
{
	
	SmsManager smsManager = SmsManager.getDefault();
	
 String destAddr = add, scAddr = null, mMessageText =msgbdy;
 
 System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
 
 PendingIntent sentIntent = null, deliveryIntent = null;
 
 try 
 {
 	
 	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
 	
 	
 	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
 	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

 
 	

 for (int i=0; i < messages.size(); i++)
 {

 	
 	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
        listOfIntents.add(pi);
 }
 System.out.println ("******** inside TRY FOR SendMultiPartSms10");
 smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

 } catch (Exception e) 
 {
 Log.i("TEST", e.toString());
 }

}	

}