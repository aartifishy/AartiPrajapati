package com.micro.mobisecurity;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;


public class BackupList extends Activity implements OnClickListener
{
	ImageButton contacts,sms,calendar,media;
	public void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		System.out.println ("Inside onCreate of BackupList");
		setContentView(R.layout.backuplist);
		
		contacts= (ImageButton)this.findViewById(R.id.contacts_button);
		sms = (ImageButton)this.findViewById(R.id.sms_button);
		//calendar = (ImageButton)this.findViewById(R.id.calendar_button);
		media = (ImageButton)this.findViewById(R.id.media_button);
		 	 	
		 contacts.setOnClickListener(this);
		 sms.setOnClickListener(this);
		 //calendar.setOnClickListener(this);
		 media.setOnClickListener(this);
    }
	
	public void onClick(View v)
    {
		if (v==contacts)
		{
			System.out.println ("User click on Contacts button");
			Intent contactIntent = new Intent(this,ContactBackup.class);
			startActivity(contactIntent);
		}
		
		else if (v==sms)
		{
			System.out.println ("User click on sms button");
			Intent smsIntent = new Intent(this,ReadSMS.class);
			startActivity(smsIntent);
		}
		/*else if (v==calendar)
		{
			System.out.println ("User click on sms button");
			Intent smsIntent = new Intent(this,ReadCalender.class);
			startActivity(smsIntent);
		}*/
		else if (v==media)
		{
			System.out.println ("User click on Media button");
			Intent mediaIntent = new Intent(this,BackupMedia.class);
			startActivity(mediaIntent);
		}
    }
}

