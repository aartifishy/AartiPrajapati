package com.micro.mobisecurity;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.TextView;

public class ShowSettingsActivity extends Activity {
	
	public static  String editpref="";

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.show_settings_layout);

		SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

		StringBuilder builder = new StringBuilder();
		
		builder.append("\n" + sharedPrefs.getBoolean("EnablePreferences", false));
		builder.append("\n" + sharedPrefs.getBoolean("EnablePreferences1", false));
		
		builder.append("\n" + sharedPrefs.getString("Name", "NULL"));
		
		editpref=sharedPrefs.getString("Name", "NULL");

		TextView settingsTextView = (TextView) findViewById(R.id.settings_text_view);
		settingsTextView.setText(builder.toString());

	}

}
