package com.micro.mobisecurity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Vector;

import com.micro.mobisecurity.R;



import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ParseException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class LockSetting extends ListActivity 
{
	//File ToggleSirenOnSIMchng=new File("data/data/com.Multipartsms.com/SirenToggle");
	//File ToggleAutoLockOnSIMchng=new File("data/data/com.Multipartsms.com/LockToggle");
	
	File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
	File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
	
	
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	
	static final int DIALOG_ChangeLockMessage = 0;
	private Dialog editorDialog = null;
	File secureLockMesgChangeFile=new File("data/data/com.micro.mobisecurity/SecureLockMsgFile");
	
	
	static final String[] title = new String[] {
		"Change Lock Message"};
	static final String[] detail = new String[] {
		"Chage Your Lock Message."};
	private Integer[] imgid = {R.drawable.setmessagelockscreen};
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locksetting);
		
		ToggleButton toggleForAutolock = (ToggleButton) findViewById(R.id.toggleForAutolock);
		ToggleButton toggleForSiren = (ToggleButton) findViewById(R.id.toggleForSiren);
		
		mInflater = (LayoutInflater) getSystemService(
		Activity.LAYOUT_INFLATER_SERVICE);
		
		data = new Vector<RowData>();
		
		for(int i=0;i<title.length;i++)
		{
			try {
			 	rd = new RowData(i,title[i],detail[i]);
			    } 
			catch (ParseException e) 
			{
			    	e.printStackTrace();
			}
		   data.add(rd);
		}
		   CustomAdapter adapter = new CustomAdapter(this, R.layout.firstlist,R.id.title, data);
		   setListAdapter(adapter);
		   getListView().setTextFilterEnabled(true);
	
		   toggleForAutolock.setOnClickListener(new View.OnClickListener() 
	        {
	            public void onClick(View v) 
	            {
	                if(((ToggleButton) v).isChecked())
	                {
	                    Toast.makeText(getBaseContext(), "Lock  On", Toast.LENGTH_SHORT).show();
	                   // FileWrite(ToggleAutoLockOnSIMchng,"LockOn");
	                 writeToggleAutoLockOnSIMchngFile();
	                }
	                else
	                {
	                    Toast.makeText(getBaseContext(), "Lock Off", Toast.LENGTH_SHORT).show();
	                   // FileWrite(ToggleAutoLockOnSIMchng,"LockOff");
	                  writeToggleAutoLockOffSIMchngFile();
	                }
	            }
	        });
		   
		   toggleForSiren.setOnClickListener(new View.OnClickListener() 
	        {
	            public void onClick(View v) 
	            {
	                if(((ToggleButton) v).isChecked())
	                {
	                    Toast.makeText(getBaseContext(), "Siren On", Toast.LENGTH_SHORT).show();
	                   // FileWrite(ToggleSirenOnSIMchng,"SirenOn");
	                writeToggleSirenOnSIMchngFile();
	                }else
	                {
	                    Toast.makeText(getBaseContext(), "Siren Off", Toast.LENGTH_SHORT).show();
	                  //  FileWrite(ToggleSirenOnSIMchng,"SirenOff");
	                    writeToggleSirenOffSIMchngFile();
	                }
	            }
	        });
	}
	
	
	   public void onListItemClick(ListView parent, View v, int position,long id) 
	   {  
		   
		   if (position == 0 )
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Auto Lock.",  Toast.LENGTH_SHORT).show();
			   
			   //AutoLock();
			   showDialog(DIALOG_ChangeLockMessage);
		   }
		   /*else if (position == 1)
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Enable Alarm.",  Toast.LENGTH_SHORT).show();
			   
			   EnableAlarm();
		   }
		   else if (position == 2)
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Change Lock Message.",  Toast.LENGTH_SHORT).show();
			   
			   showDialog(DIALOG_ChangeLockMessage);
		   }*/
		 
	   }
	       private class RowData 
	       {
	       protected int mId;
	       protected String mTitle;
	       protected String mDetail;
	       RowData(int id,String title,String detail)
	       	   {
		       mId=id;
		       mTitle = title;
		       mDetail=detail;
		       }
	       
		       @Override
		       public String toString() 
		       {
		               return mId+" "+mTitle+" "+mDetail;
		       }
	       }
	       
	  private class CustomAdapter extends ArrayAdapter<RowData> 
	  {
		  public CustomAdapter(Context context, int resource,int textViewResourceId, List<RowData> objects) 
		  {               
			  super(context, resource, textViewResourceId, objects);
		  }
	       @Override
	       public View getView(int position, View convertView, ViewGroup parent) 
	       {   
	       ViewHolder holder = null;
	       TextView title = null;
	       TextView detail = null;
	       ImageView i11=null;
	       RowData rowData= getItem(position);
	       if(null == convertView)
	       {
	            convertView = mInflater.inflate(R.layout.firstlist, null);
	            holder = new ViewHolder(convertView);
	            convertView.setTag(holder);
	       }
	             holder = (ViewHolder) convertView.getTag();
	             title = holder.gettitle();
	             title.setText(rowData.mTitle);
	             detail = holder.getdetail();
	             detail.setText(rowData.mDetail);                                                     
	             i11=holder.getImage();
	             i11.setImageResource(imgid[rowData.mId]);
	             return convertView;
	       }
	            private class ViewHolder 
	            {
	            private View mRow;
	            private TextView title = null;
	            private TextView detail = null;
	            private ImageView i11=null; 
	            public ViewHolder(View row) 
	            {
	            mRow = row;
	            }
	         public TextView gettitle() 
	         {
	             if(null == title)
	             {
	                 title = (TextView) mRow.findViewById(R.id.title);
	             }
	            return title;
	         }     
	         public TextView getdetail() 
	         {
	             if(null == detail)
	             {
	                  detail = (TextView) mRow.findViewById(R.id.detail);
	             }
	           return detail;
	         }
	        public ImageView getImage() 
	        {
	             if(null == i11)
	             {
	                  i11 = (ImageView) mRow.findViewById(R.id.img);
	             }
	                return i11;
	        }
	     }
	   } 
	  

public void AutoLock()
{


    //Code here to display the dialog box with checkbox
	   
	 //List items

       final CharSequence[] items = {"Yes", "No"};

       //Prepare the list dialog box

       AlertDialog.Builder builder = new AlertDialog.Builder(this);

       //Set its title

       builder.setTitle("Please Select..");

       //Set the list items along with checkbox and assign with the click listener

       builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {

       // Click listener

       public void onClick(DialogInterface dialog, int item) 
       {

              Toast.makeText(getApplicationContext(), items[item], Toast.LENGTH_SHORT).show();

              //If the Cheese item is chosen close the dialog box

              //if(items[item]=="Cheese")
              
          

               dialog.dismiss();

          }

       });

       AlertDialog alert = builder.create();

       //display dialog box

       alert.show();

   	
}

public void EnableAlarm()
{


    //Code here to display the dialog box with checkbox
	   
	 //List items

       final CharSequence[] items = {"Yes", "No"};

       //Prepare the list dialog box

       AlertDialog.Builder builder = new AlertDialog.Builder(this);

       //Set its title

       builder.setTitle("Please Select..");

       //Set the list items along with checkbox and assign with the click listener

       builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {

       // Click listener

       public void onClick(DialogInterface dialog, int item) 
       {

              Toast.makeText(getApplicationContext(), items[item], Toast.LENGTH_SHORT).show();

              //If the Cheese item is chosen close the dialog box

              //if(items[item]=="Cheese")
              
          

               dialog.dismiss();

          }

       });

       AlertDialog alert = builder.create();

       //display dialog box

       alert.show();

   
}


    protected Dialog onCreateDialog(int id)
    {
        Dialog editor = editorDialog;
        
       
        
        if (editorDialog == null)
        {
        	 switch(id)
        	 {
        	 
        	 case DIALOG_ChangeLockMessage:
        	 editor = createEditorDialogForEmail();
             break;

        	 

        	 }
            
        }
        return editor;
    }
  

    private Dialog createEditorDialogForEmail()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.addDialogTitleLock);

        View content = getLayoutInflater().inflate(R.layout.changelockmessage,
            (ViewGroup) findViewById(R.id.editLayout));
        builder.setView(content);
        
        
        builder.setPositiveButton(R.string.OkButton,
            new DialogInterface.OnClickListener()
            {
        		
                public void onClick(DialogInterface dialog, int which)
                {
                    /**/
                	
                	//con();
                	
                	Dialog source = (Dialog) dialog;
                    EditText nameField = (EditText) source
                        .findViewById(R.id.editText1);
                    
                    String name = nameField.getText().toString();
                    

                    System.out.println("@@@@@@@@@@@@@@@@@ "+ name); 
            

                    if ((name.length() > 0) )
                    {
                    	
                    	try 
				    	{
                    		 secureLockMesgChangeFile.createNewFile();
							 PrintWriter out1 = new PrintWriter(secureLockMesgChangeFile);
							 out1.write(name);  
							 System.out.println (name.trim());
							 out1.flush();
							 out1.close();
							 System.out.println ("Lock Mesg Is "+name);
				    	}
				    	catch (IOException ioe)
						 {
							 ioe.printStackTrace();
						 }
                    	
                    }
                    dialog.dismiss();
                }
            });

        builder.setNegativeButton(R.string.CancelButton,
            new DialogInterface.OnClickListener()
            {

                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                	
                	
                }
            });

        return builder.create();
    }
    
   /* public void FileWrite(File aPath,String aBody)
	{
		try 
    	{
			 System.out.println("@@@@ Inside Try FileWrite @@@@");
			 
			 aPath.createNewFile();
			 PrintWriter out1 = new PrintWriter(aPath);
			 out1.write(aBody);  
			 System.out.println (aBody.trim());
			 out1.flush();
			 out1.close();
    	}
    	catch (IOException ioe)
		 {
    		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
    		ioe.printStackTrace();
		 }
		
	}*/
    
	public void writeToggleSirenOnSIMchngFile()
	 {
	
		 try {
			 ToggleSirenOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleSirenOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("SirenOn");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
			
	 }

	public void writeToggleSirenOffSIMchngFile()
	 {
	
		 try {
			 ToggleSirenOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleSirenOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("SirenOff");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
	 }
	public void writeToggleAutoLockOnSIMchngFile()
	 {
	
		try {
			ToggleAutoLockOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleAutoLockOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("LockOn");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 3");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 3");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 3");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 3");
	 }
	public void writeToggleAutoLockOffSIMchngFile()
	 {
	
		try {
			ToggleAutoLockOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleAutoLockOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("LockOff");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
	 }
}