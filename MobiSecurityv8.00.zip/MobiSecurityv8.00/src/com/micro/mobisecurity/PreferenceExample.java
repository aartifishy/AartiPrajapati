package com.micro.mobisecurity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import com.micro.mobisecurity.R;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;

public class PreferenceExample extends PreferenceActivity 
{
	
	public static final String nwd = "nwd";
	//public static  String mmm="";
	public  String mmm;
    private CheckBoxPreference nwd_pref;
    private SharedPreferences mPreferences;
    public static final String MESSAGE_KEY = "message";
    private EditTextPreference mTextAfter;
    public String updatedString;
    public static SharedPreferences sharedPrefs ;

    //+++++++++++++++++++++++++++++++++++++++
    
    public static final String KEY_EditTextPreference = "Edit_preference";
    private EditTextPreference mEditTextPreference;
   

    //+++++++++++++++++++++++++++++++++++++++
    /*EditTextPreference editmanu;boolean b=true;*/
    
    public static final String GAME_PREFERENCES = "Name";
    File ToggleBatteryOnOff=new File("data/data/com.micro.mobisecurity/BattInfo");
    File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
	File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");

    
    
	@Override
    public void onCreate(Bundle savedInstanceState) 
	
	{
        super.onCreate(savedInstanceState);
        //addPreferencesFromResource(R.xml.preference);
       addPreferencesFromResource(R.xml.lock_setting_pref);
       
       mEditTextPreference = (EditTextPreference)getPreferenceScreen().findPreference(KEY_EditTextPreference);
       final StringBuilder builder = new StringBuilder();
       sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this); 
       
       System.out.println("@@@@@@@@ onlyblock called ");
	   

	   
	   System.out.println("value of mmm is "+mmm);
	   System.out.println("value of mmm is "+updatedString);
	   
	   final CheckBoxPreference buyPref = (CheckBoxPreference) findPreference("EnablePreferences");
       buyPref.setOnPreferenceClickListener(new OnPreferenceClickListener() 
       {
       public boolean onPreferenceClick(Preference preference) 
       {   
          if (buyPref.isChecked()) 
          {
            // checkbox is checked, do something
        	  System.out.println("@@@@@@@@@@@@@ isChecked");
        	  writeToggleAutoLockOnSIMchngFile();
          } else 
          {
            // checkbox not checked, do something else
        	  System.out.println("@@@@@@@@@@@@@ NOTChecked");
        	  writeToggleAutoLockOffSIMchngFile();
          }
          return true; 
       }

	});
       
       final CheckBoxPreference buyPref1 = (CheckBoxPreference) findPreference("EnablePreferences1");
       buyPref1.setOnPreferenceClickListener(new OnPreferenceClickListener() 
       {
       public boolean onPreferenceClick(Preference preference) 
       {   
          if (buyPref1.isChecked()) 
          {
            // checkbox is checked, do something
        	  System.out.println("@@@@@@@@@@@@@ ManuisChecked");
        	  writeToggleSirenOnSIMchngFile();
          } else 
          {
            // checkbox not checked, do something else
        	  System.out.println("@@@@@@@@@@@@@ ManuNOTChecked");
        	  writeToggleSirenOffSIMchngFile();
          }
          return true; 
       }

	});
       
       
       final CheckBoxPreference buyPref2 = (CheckBoxPreference) findPreference("EnablePreferences2");
       buyPref2.setOnPreferenceClickListener(new OnPreferenceClickListener() 
       {
       public boolean onPreferenceClick(Preference preference) 
       {   
          if (buyPref.isChecked()) 
          {
            // checkbox is checked, do something
        	  System.out.println("@@@@@@@@@@@@@ isChecked");
        	  writeBatteryAlertOnFile();
          } else 
          {
            // checkbox not checked, do something else
        	  System.out.println("@@@@@@@@@@@@@ NOTChecked");
        	  writeBatteryAlertOffFile();
          }
          return true; 
       }

	});
       final EditTextPreference buyPref1a = (EditTextPreference) findPreference("Name");
       buyPref1a.setOnPreferenceClickListener(new OnPreferenceClickListener() 
       {
       public boolean onPreferenceClick(Preference preference) 
       {   
    	   System.out.println("@@@@@@@@@@@@@ Edit Text Is Clicked");
    	   System.out.println("@@@@@@@@@@@@@ "+buyPref1a.getText());
    	   
          return true; 
       }

	});
	
	}
	
	

	public void onDialogClosed (boolean positiveResult)
    
    {
    	System.out.println("@@@@@@@@@@@ dialog closed");
    	
    	SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

		StringBuilder builder = new StringBuilder();
		
		builder.append("\n" + sharedPrefs.getBoolean("EnablePreferences", false));
		builder.append("\n" + sharedPrefs.getBoolean("EnablePreferences1", false));
		
		builder.append("\n" + sharedPrefs.getString("Name", "NULL"));
		
		mmm=sharedPrefs.getString("Name", "NULL");
    }
	
	
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) 
    {
    	menu.add(Menu.NONE, 0, 0, "Show current settings");
    	return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
    {
    	switch (item.getItemId()) 
    	{
    		case 0:
    			startActivity(new Intent(this, ShowSettingsActivity.class));
    			return true;
    	}
    	return false;
    }
    public void writeBatteryAlertOnFile()
	 {
	
		 try {
			 ToggleBatteryOnOff.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleBatteryOnOff);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("BatteryOn");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
		
			
	 }

	public void writeBatteryAlertOffFile()
	 {
	
		 try {
			 ToggleBatteryOnOff.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleBatteryOnOff);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("BatteryOff");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
			
	 }
    public void writeToggleSirenOnSIMchngFile()
	 {
	
		 try {
			 ToggleSirenOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleSirenOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("SirenOn");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 1");
			 
			
	 }

	public void writeToggleSirenOffSIMchngFile()
	 {
	
		 try {
			 ToggleSirenOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleSirenOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("SirenOff");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
			
	 }
	public void writeToggleAutoLockOnSIMchngFile()
	 {
	
		try {
			ToggleAutoLockOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleAutoLockOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("LockOn");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 3");
			
	 }
	public void writeToggleAutoLockOffSIMchngFile()
	 {
	
		try {
			ToggleAutoLockOnSIMchng.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 PrintWriter out1 = null;
			try {
				out1 = new PrintWriter(ToggleAutoLockOnSIMchng);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 out1.write("LockOff");  
			
			 out1.flush();
			 out1.close();
			 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
			
	 }  

}    
      
	    

