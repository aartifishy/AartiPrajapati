package com.micro.mobisecurity;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ParseException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class listActivity extends ListActivity 
{
	
	Thread t;
	private static final int NOTIFY_ME_ID=1337; 
    ProgressDialog dialog;
    String actkeyStr="",response,licennceKey;
    Context context;
    String imsi="",imei="",FullString="";
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	private int count=0,back=0;
	boolean appAct;
	 String[] title;
	  String[] detail; 
	  File appactFile=new File("data/data/com.micro.mobisecurity/actFile");
	//private Integer[] imgid = {R.drawable.backup,R.drawable.backup,R.drawable.lock,R.drawable.wipe,R.drawable.setting,R.drawable.exit};
	   Integer[] imgid;
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		System.out.println("@@@@@ list activity @@@@@@");
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main1);
		if(!appactFile.exists())
		{
			
			System.out.println("after true activate");
			title = new String[] {
				    "Deactivate","Backup/Restore","Lock Device","Wipe Data","Settings","Exit"     	};
			detail = new String[] {
					"Press to deactivate all the functions","Backup/Restore Contacts,Messages,Media","Lock The Device Now !","Wipe all Personal Contacts, Logs , Media & Memory Card.","Manage Your Settings.","Exit application"	};
			 imgid =new Integer[] {R.drawable.deativate,R.drawable.backuprest,R.drawable.lock,R.drawable.wipe,R.drawable.setting,R.drawable.exit1};
		
		}
		else 
		{
			System.out.println("after false activate");
			title = new String[] {
				    "Activate","Exit"     	};
			detail = new String[] {
					"Press to activate all the functions","Exit application"	};
			 imgid =new Integer[] {R.drawable.activate,R.drawable.exit1};
		}
		
		mInflater = (LayoutInflater) getSystemService(
		Activity.LAYOUT_INFLATER_SERVICE);
		
		data = new Vector<RowData>();
		
		for(int i=0;i<title.length;i++)
		{
			try {
			 	rd = new RowData(i,title[i],detail[i]);
			    } 
			catch (ParseException e) 
			{
			    	e.printStackTrace();
			}
		   data.add(rd);
		}
		   CustomAdapter adapter = new CustomAdapter(this, R.layout.firstlist,R.id.title, data);
		   getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		   setListAdapter(adapter);
		  // ListView.setCacheColorHint();

		   getListView().setTextFilterEnabled(true);
		   
	}
	 @Override
	    public void onBackPressed() {
		back++;
		if(back>=2)
		{
        moveTaskToBack(true);
		System.exit(0);
		}
		else
		{
			Toast.makeText(getApplicationContext(), "Press again to exit"
                    ,  Toast.LENGTH_SHORT).show();
	     return;
		}
	    }
	   public void onListItemClick(ListView parent, View v, int position,long id) 
	   {  
		    if(appactFile.exists())
		   {   
			   if (position == 0 )
			   {
				   System.out.println("Titel::"+title[0]);
				   System.out.println("Titel::"+title[1]);
				   if(title[0].equals("Activate"))
				   {   
					   appactFile.delete();
					   System.out.println("All deactivate");
					   Intent intent = new Intent(Intent.ACTION_VIEW);
			   			intent.setClassName(this, listActivity.class.getName());
			   			startActivity(intent);
					   
				   }
				   else
				   {
					  
					   System.out.println("after activate");
					   FileWrite(appactFile,"Activated");
					   Intent intent = new Intent(Intent.ACTION_VIEW);
			   			intent.setClassName(this, listActivity.class.getName());
			   			startActivity(intent);
				   }
			   }
			   else if (position == 1)
		   {
				   System.out.println("exit app");
				   moveTaskToBack(true);
		   			//finish();
		   			this.finish();
		   			
		   			System.exit(0);
		   			/*Intent startMain = new Intent(Intent.ACTION_MAIN);
				     startMain.addCategory(Intent.CATEGORY_HOME);
				     startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				     startActivity(startMain);
				     this.finish();*/
			   /*moveTaskToBack(true);
			  Intent startMain = new Intent(Intent.ACTION_MAIN);
			     startMain.addCategory(Intent.CATEGORY_HOME);
			     startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			     startActivity(startMain);
			     this.finish();
			     
		   			System.exit(0);*/
		   }
		   }
		    else
		    {
		   if (position == 0 )
		   {
			   System.out.println("Titel::"+title[0]);
			   System.out.println("Titel::"+title[1]);
			   if(title[0].equals("Activate"))
			   {   
				   appactFile.delete();
				   System.out.println("All deactivate");
				   Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, listActivity.class.getName());
		   			startActivity(intent);
				   
			   }
			   else
			   {
				  
				   System.out.println("after activate");
				   FileWrite(appactFile,"Activated");
				   Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, listActivity.class.getName());
		   			startActivity(intent);
			   }
			   
			  
		   }
		   else if (position == 1 )
		   {
			   /*Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, TabLayoutActivity.class.getName());
	   			startActivity(intent);*/
			   ServerAuthtication();
	   			/*Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, LoginBackup.class.getName());
	   			startActivity(intent);*/
			   /*Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Data Backup.",  Toast.LENGTH_SHORT).show();*/
		   }
		  /* else if (position == 1)
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Data Restore.",  Toast.LENGTH_SHORT).show();
		   }*/
		   else if (position == 2)
		   {
			   /*Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Lock Device.",  Toast.LENGTH_SHORT).show();*/
			   
			   OkCancelAlertBoxForLock("Mobi Security", "Are you sure you want to lock your mobile? Press Yes to lock and use your password to unlock the mobile.") ;
		   }
		      
		   else if (position ==3)
		   {
			  /* Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Wipe Data.",  Toast.LENGTH_SHORT).show();*/
			   
			   OkCancelAlertBoxForWipe("Mobi Security", "Are you sure want to wipe your phone data ? All your Contacts,Images,Videos,Phone Log will be deleted.Please press yes to continue.  ") ;
		   }
		   else if (position == 4)
		   {
		   			/*Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Setting.",  Toast.LENGTH_SHORT).show();*/
		   			
		   			Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, SettingClick.class.getName());
		   			startActivity(intent);
		   			
		   }
		  else if (position == 5)
		   {
			  //CancelNotification(context, position);
		   			//finish();
			  System.out.println("haaaaaaa exit app");
		   			moveTaskToBack(true);
		   			System.out.println("moveTaskToBack");
		   			//this.finish();
		   			System.out.println("after finish();");
		   			System.exit(0);
		   			
			  
		   }
		    }
		  
	   }
	       
		private class RowData 
	       {
	       protected int mId;
	       protected String mTitle;
	       protected String mDetail;
	       RowData(int id,String title,String detail)
	       	   {
		       mId=id;
		       mTitle = title;
		       mDetail=detail;
		       }
	       
		       @Override
		       public String toString() 
		       {
		               return mId+" "+mTitle+" "+mDetail;
		       }
	       }
	       
	  private class CustomAdapter extends ArrayAdapter<RowData> 
	  {
		  public CustomAdapter(Context context, int resource,int textViewResourceId, List<RowData> objects) 
		  {               
			  super(context, resource, textViewResourceId, objects);
		  }
	       @Override
	       public View getView(int position, View convertView, ViewGroup parent) 
	       {   
	       ViewHolder holder = null;
	       TextView title = null;
	       TextView detail = null;
	       ImageView i11=null;
	       RowData rowData= getItem(position);
	       if(null == convertView)
	       {
	            convertView = mInflater.inflate(R.layout.firstlist, null);
	            holder = new ViewHolder(convertView);
	            convertView.setTag(holder);
	       }
	             holder = (ViewHolder) convertView.getTag();
	             title = holder.gettitle();
	             title.setText(rowData.mTitle);
	             detail = holder.getdetail();
	             detail.setText(rowData.mDetail);                                                     
	             i11=holder.getImage();
	             i11.setImageResource(imgid[rowData.mId]);
	             return convertView;
	       }
	            private class ViewHolder 
	            {
	            private View mRow;
	            private TextView title = null;
	            private TextView detail = null;
	            private ImageView i11=null; 
	            public ViewHolder(View row) 
	            {
	            mRow = row;
	            }
	         public TextView gettitle() 
	         {
	             if(null == title)
	             {
	                 title = (TextView) mRow.findViewById(R.id.title);
	             }
	            return title;
	         }     
	         public TextView getdetail() 
	         {
	             if(null == detail)
	             {
	                  detail = (TextView) mRow.findViewById(R.id.detail);
	             }
	           return detail;
	         }
	        public ImageView getImage() 
	        {
	             if(null == i11)
	             {
	                  i11 = (ImageView) mRow.findViewById(R.id.img);
	             }
	                return i11;
	        }
	     }
	   }
	  
	  
	  protected void OkCancelAlertBoxForWipe(String title, String mymessage)     
		{
		// Code here to display alert box
	       	// Create the alert box
	              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

	              // Set the message to display
	              alertbox.setMessage(mymessage);

	              // Add a neutral button to the alert box and assign a click listener
	              alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
	              {

	                  // Click listener on the neutral button of alert box
	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {
	                	// The neutral button was clicked
	                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	                	  Wipe();
	                      
	                  }
	              }
	              
	              
	              
	              );
	              
	              // Set a negative/no button and create a listener

	              alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                  // Click listener

	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {

	                     // Toast.makeText(getApplicationContext(), "'User Press No button.", Toast.LENGTH_SHORT).show();

	                  }

	              }
	              
	              );
	               // show the alert box
	              alertbox.show();  
		}	 
	  
	  protected void OkCancelAlertBoxForAfterWipe(String title, String mymessage)     
		{
		// Create the alert box
          AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

          // Set the message to display
          alertbox.setMessage(mymessage);

          // Add a neutral button to the alert box and assign a click listener
          alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {

              // Click listener on the neutral button of alert box
              public void onClick(DialogInterface arg0, int arg1) 
              {

                  // The neutral button was clicked
                  //Toast.makeText(getApplicationContext(), "'OK' button clicked", Toast.LENGTH_LONG).show();
            	  //Wipe();
              }
          });

           // show the alert box
          alertbox.show();
      }

		

	  protected void OkCancelAlertBoxForLock(String title, String mymessage)     
		{
		// Code here to display alert box
	       	// Create the alert box
	              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

	              // Set the message to display
	              alertbox.setMessage(mymessage);

	              // Add a neutral button to the alert box and assign a click listener
	              alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
	              {

	                  // Click listener on the neutral button of alert box
	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {
	                	// The neutral button was clicked
	                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	                	  Lock();
	                      
	                  }
	              }
	              
	              
	              
	              );
	              
	              // Set a negative/no button and create a listener

	              alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                  // Click listener

	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {

	                      //Toast.makeText(getApplicationContext(), "'User Press No button.", Toast.LENGTH_SHORT).show();

	                  }

	              }
	              
	              );
	               // show the alert box
	              alertbox.show();  
		}	 
	  
	  public void Lock()
	  {
		  Intent intent = new Intent(Intent.ACTION_VIEW);
 			intent.setClassName(this, BlockOnly.class.getName());
 			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
 			//intent.addFlags(Intent.FLAG_);
 			startActivity(intent);
 			
 			finish();
	  }
	  
	  public void Wipe()
	  {
	     
 			Intent intent1 = new Intent(Intent.ACTION_VIEW);
 			intent1.setClassName(this, WipePhoneData.class.getName());
 			startActivity(intent1);
 			
 			notifyMe();
 			
 			
	  }
	  private void notifyMe()
		{
			final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
			Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
			PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
			
			note.setLatestEventInfo(this, "Mobi Security",	"Your phone is Wiped Successfully.", i);
			note.number=++count;
			
			mgr.notify(NOTIFY_ME_ID, note);
		}
	  /*public void wipecompleted()
	  {
		  
		  Intent intent1 = new Intent(Intent.ACTION_VIEW);
 			intent1.setClassName(this, listActivity.class.getName());
 			startActivity(intent1);
 			
 			finish();
	  }*/
	  public void FileWrite(File aPath,String aBody)
		{
			try 
	    	{
				 System.out.println("@@@@ Inside Try FileWrite @@@@");
				 
				 aPath.createNewFile();
				 PrintWriter out1 = new PrintWriter(aPath);
				 out1.write(aBody);  
				 System.out.println (aBody.trim());
				 out1.flush();
				 out1.close();
	    	}
	    	catch (IOException ioe)
			 {
	    		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
	    		ioe.printStackTrace();
			 }
			
		}
	  
	  @Override
	    protected Dialog onCreateDialog(int id) {
	          switch (id) {
	                case 0: {
	                      dialog = new ProgressDialog(this);
	                      dialog.setMessage("Authenticating...");
	                      dialog.setIndeterminate(true);
	                      dialog.setCancelable(true);
	                      return dialog;
	                }
	          }
	          return null;
	    }
	    private Handler handler = new Handler() {
	          @Override
	          public void handleMessage(Message msg) {
	                String loginmsg=(String)msg.obj;
	                if(loginmsg.equals("SUCCESS")) {
	                      removeDialog(0);
	                      AfterSuccess();
	                      //finish();
	                }
	                else if(loginmsg.equals("Invalid"))
	                {
	                	 removeDialog(0);
	 		    		alertbox("Mobi Security","Oops!Unable to connect with server please try again.");
	                }
	                
	          }
	    };
	    private void ServerAuthtication() {
			// TODO Auto-generated method stub
	    	callIMEI();
			 try
		    	{    	
				 URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/Login.aspx?imei="+imei);
		        		
		    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
		    		// allow inputs 
		    		conn.setDoInput(true); 
		    		
		    		// allow outputs 
		    		conn.setDoOutput(true);
		    		
		    		// don't use a cached copy 
		    		conn.setUseCaches(false); 
		    		
		    		// use a post method 
		    		conn.setRequestMethod("POST");
		    		
		    		// set post headers 
		    		conn.setRequestProperty("Connection","Keep-Alive"); 
		    		  		
		    		// open data output stream 
		    		OutputStream dos ; 
		    		
		    		dos=conn.getOutputStream();
		    		
			    	dos.flush(); 
			        	
			    	InputStream is = conn.getInputStream(); 
			    	int ch; 
			    	StringBuffer b =new StringBuffer(); 
			    	System.out.println ("Before second while loop");
			    	while(( ch = is.read() ) != -1 )
			    	{ 
			    		
			    		b.append( (char)ch);
			    		
			    	} 
			    	response=b.toString(); 
			    	System.out.println ("Response"+response);
			    	actkeyStr = response.substring(0,(response.indexOf(',')));
			    	System.out.println ("********************"+actkeyStr);
			    	dos.close(); 
			    	
			    	 if(response.contains("SUCCESS") || response.contains("FILL"))
			    	{
			    		 Message myMessage=new Message();
	                     myMessage.obj="SUCCESS";
	                     handler.sendMessage(myMessage);
			    		
			    		// addBuddies();
			    	}
			    	
			    	else if(response.contains("Invalid"))
			    	{
			    		Message myMessage=new Message();
	                    myMessage.obj="Invalid";
	                    handler.sendMessage(myMessage);
			    		
			    	}
			    	else
			    	{
			    		    removeDialog(0);
			            	alertbox("Mobi Security","Check your GPRS connection");
			    	}
			    	
			    	
			    	
		    	} 
		    	
		    	catch (UnknownHostException uhe)
		    	{
		    		System.out.println("Inside catch");
		    		
	                removeDialog(0);
	            	alertbox("Mobi Security","Check your GPRS connection");
		    		System.out.println("after alert");
		    	}
		    	catch (MalformedURLException ex)
		    	{ 
		    		
		    		//alertbox("MobiBackup","Check your GPRS connection");
		    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
		    	} 
		    	catch (IOException ioe)
		    	{ 
		    		//alertbox("MobiBackup","Check your GPRS connection");
		    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
		    	} 
			    	
		    	 //alertbox2("Mobi Security", "Registration request sent successfully.Shortly you will be receiving registration password via SMS.");
		}
	    private void AfterSuccess() {
			// TODO Auto-generated method stub
	    	Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setClassName(this, TabLayoutActivity.class.getName());
				startActivity(intent);
	 		
	 		
		}
		
	    
	   
	    private void InvalidIMEI() {
			// TODO Auto-generated method stub
	    	Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setClassName(this, listActivity.class.getName());
				startActivity(intent);
		} 
	   
	    
	    protected void alertbox(String title, String mymessage)     
		{
	    	new AlertDialog.Builder(this)   
			.setMessage(mymessage)   
			//.setTitle(title)   
			.setCancelable(true)   
			.setNeutralButton(android.R.string.ok,   
			new DialogInterface.OnClickListener() {   
			public void onClick(DialogInterface dialog, int whichButton)
			{
				/*moveTaskToBack(true);
			    
			    finish();*/
				 
				InvalidIMEI();

			}

			  
			})   
			.show();   
		}
	    
	   
	  /*  public static void CancelNotification(Context ctx, int notifyId) {
	        String ns = Context.NOTIFICATION_SERVICE;
	        NotificationManager nMgr = (NotificationManager) ctx.getSystemService(ns);
	        nMgr.cancel(notifyId);
	    }*/

	    
	   
	    
	  
	    //calculate imei & imsi
	    public void callIMEI()
		{ 
	    	try
	    	{
		    	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
			    imsi = mTelephonyMgr.getSubscriberId(); 
			    imei = mTelephonyMgr.getDeviceId(); 
			    
			    System.out.println("i am in callimi method");
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.println(e);
	    	}
		}
	    @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	    new MenuInflater(getApplication())
	    .inflate(R.menu.option, menu);
	    return(super.onCreateOptionsMenu(menu));
	    }
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	  /*  if (item.getItemId()==R.id.about) {
	    	System.out.println ("User click on login button");
			Intent loginIntent = new Intent(this,About.class);
			startActivity(loginIntent);
	    //Toast.makeText(this, message, Toast.LENGTH_LONG).show();
	    return(true);
	    }
	    else*/ if (item.getItemId()==R.id.help) {
	    	System.out.println ("User click on login button");
	    	Intent introIntent = new Intent(this, Help.class);
			startActivity(introIntent);
	    //Toast.makeText(this, message, Toast.LENGTH_LONG).show();
	    return(true);
	    }
	   
	    return(super.onOptionsItemSelected(item));
	    }
}