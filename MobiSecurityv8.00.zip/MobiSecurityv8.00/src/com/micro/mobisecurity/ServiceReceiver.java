package com.micro.mobisecurity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

public class ServiceReceiver extends BroadcastReceiver  

{
	  @Override
	  public void onReceive(Context context, Intent intent) 
	  {
		  
		  System.out.println("&&&&&&&&&& Manmay is saying Hello");
		  
		  
	    MyPhoneStateListener phoneListener=new MyPhoneStateListener();
	    TelephonyManager telephony = (TelephonyManager)
	    context.getSystemService(Context.TELEPHONY_SERVICE);
	    telephony.listen(phoneListener,PhoneStateListener.LISTEN_CALL_STATE);
	  }
	
public class MyPhoneStateListener extends PhoneStateListener 
{
	  public void onCallStateChanged(int state,String incomingNumber)
	  {
		  switch(state)
		  {
		    case TelephonyManager.CALL_STATE_IDLE:
		      
		      System.out.println("&&&&&&&&&& CALL_STATE_IDLE");
		    break;
		    case TelephonyManager.CALL_STATE_OFFHOOK:
		    	System.out.println("&&&&&&&&&& OFFHOOK");
		    break;
		    case TelephonyManager.CALL_STATE_RINGING:
		    	System.out.println("&&&&&&&&&& CALL_STATE_RINGING");
		    break;
		    }
		 
	  }
}

}
