package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

public class RestoreContact extends Activity implements OnClickListener
{
	Button yesButton,noButton;
	ImageButton importButton,exportButton;
	int noOfChunks ;
	TextView cardNo;
	String str;
	String inputLine,imei;
	
	String fileName = "data/data/com.micro.mobisecurity/sangram.vcf";
	boolean done = true;
	//data/data/com.micro.lmtselite/TrialRec
	File contactsFile = new File("data/data/com.micro.mobisecurity/sangram.vcf");
	File contactsFile1 = new File("data/data/com.micro.mobisecurity/sangram1.vcf");  
	int size;
	int test=0;
	File myFile;
	private int count=0;
	private static final int NOTIFY_ME_ID=1337;
	

    /** Called when the activity is first created. */
        boolean isActive; 
        
        Handler mHandler = new Handler();
        VCardIO mBoundService = null;
        
        int mLastProgress;
        //TextView mStatusText = null; 
        
        CheckBox mReplaceOnImport = null;

        @Override
        protected void onPause() {
                isActive = false; 

                super.onPause();
        }


        @Override
        protected void onResume() {
                super.onResume();
                
                isActive = true;
                updateProgress(mLastProgress);
        }       
                
        protected void updateProgress(final int progress) {
                // Update the progress bar
                mHandler.post(new Runnable() {
                        public void run() {
                                if (isActive) {
                                        setProgress(progress * 100);
                                        if (done)
                                        {
                                        if (progress == 100)
                                        {
                                        	System.out.println("inside update progress");
                                                //mStatusText.setText("Done");
                                                //setContentView(R.layout.storecontactonserver);
                                        		sendDataToServer();
                                        		System.out.println("after send data to server");
                                        		
                                        }
                                } else {
                                        mLastProgress = progress;
                                }
                                }
                        }
                });
        }

        void updateStatus(final String status) {
                // Update the progress bar
                mHandler.post(new Runnable() {
                        public void run() {
                                if (isActive) {
                                        //mStatusText.setText(status);
                                }
                        }
                });
        }

        
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Request the progress bar to be shown in the title
       requestWindowFeature(Window.FEATURE_PROGRESS);
      setProgress(10000); // Turn it off for now
        
        setContentView(R.layout.restorecontact);

        //importButton = (Button) findViewById(R.id.widget30);
        importButton = (ImageButton) findViewById(R.id.widget31);

        //mStatusText = ((TextView) findViewById(R.id.StatusText));
       mReplaceOnImport = ((CheckBox) findViewById(R.id.widget32));
       calCulateIMEI();
        final Intent app = new Intent(RestoreContact.this, VCardIO.class);
        OnClickListener listenImport = new OnClickListener() {
            public void onClick(View v) 
            {
            //if(v==importcon){ 
            // Make sure the service is started.  It will continue running
            // until someone calls stopService().  The Intent we use to find
            // the service explicitly specifies our service component, because
            // we want it running in our own process and don't want other
            // applications to replace it.
            	setContentView(R.layout.contactrestoreonphone); 
                //setContentView(R.layout.contactfromserver);
            	System.out.println ("!!!!!!!!User click on restore contact from server!!!!!!");
            	//importButton.setText("Importing Contacts...");
            	//setContentView(R.layout.contactsfromserver);
            	//setContentView(R.layout.contactrestoreonphone);
                    if (mBoundService != null) {
                    		try
                    		{   
                    			setContentView(R.layout.contactfromserver);   
                    			contactsFile1.createNewFile();
                    			System.out.println ("After creating contactsFile1");
                    			setProgress(0);
                    			System.out.println ("After set progress");
                    			readWebPage();
                    			System.out.println ("After set read web page");
                    			
                    		}
                    		catch (IOException ioe)
                    		{
                    			ioe.printStackTrace();
                    		}
                    		setContentView(R.layout.contactfromserver);
                    		//setContentView(R.layout.contactrestoreonphone);
                            fileName = contactsFile1.getName();
                            System.out.println ("Name of file is%%%%%%%%"+fileName);
                        // Update the progress bar
                            setProgress(0);
                
                
                         // Start the import
                            mBoundService.doImport(fileName, mReplaceOnImport.isChecked(), RestoreContact.this);
                
                System.out.println ("Contacts imported successfully");
          
                setContentView(R.layout.contactfromserver); 
                System.out.println ("after set layout");    		
               //finish();
            
                    }
            }
    };
        
       /* OnClickListener listenExport = new OnClickListener() {
                public void onClick(View v) { 
                // Make sure the service is started.  It will continue running
                // until someone calls stopService().  The Intent we use to find
                // the service explicitly specifies our service component, because
                // we want it running in our own process and don't want other
                // applications to replace it.
                        
                	System.out.println ("!!!!!!!!!!!!!User click on sore contact on server button!!!!!!!!!!!!!!");
                	System.out.println (mBoundService);
                	setContentView(R.layout.contacttoserver);
                	//importButton.setText("Exporting Contacts...");
                        if (mBoundService != null) {
                           
                        	
                            
                                setProgress(0);
                    
                                mBoundService.doExport(fileName, RestoreContact.this);  
                                
                        }
                }
        };*/
        
        // Start the service using startService so it won't be stopped when activity is in background.
        startService(app);
        bindService(app, mConnection, Context.BIND_AUTO_CREATE);
     importButton.setOnClickListener(listenImport);
        //exportButton.setOnClickListener(listenExport);
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  Because we have bound to a explicit
            // service that we know is running in our own process, we can
            // cast its IBinder to a concrete class and directly access it.
                mBoundService = ((VCardIO.LocalBinder)service).getService();

                // Tell the user about this for our demo.
          // Toast.makeText(RestoreContact.this, "Connected to VCard IO Service", Toast.LENGTH_SHORT).show();
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            // Because it is running in our same process, we should never
            // see this happen.
            mBoundService = null;
           //Toast.makeText(RestoreContact.this, "Disconnected from VCard IO!", Toast.LENGTH_SHORT).show();
        }
    };
    
    
    
    public void onConfigurationChanged(Configuration newConfig)
    {
    	  super.onConfigurationChanged(newConfig);
    	  setContentView(R.layout.first);
    	  if (test==1)
    	  {
    		  setContentView(R.layout.contacttoserver);
    		  System.out.println ("*******************************************");
    	  }
    }
    private void calCulateIMEI() {
		// TODO Auto-generated method stub
    	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	}
    public void readWebPage()
    {
    	setContentView(R.layout.contacttoserver);
    	System.out.println ("%%%%%%%%%%%%%%%%%%%%%%%%%%Inside readWebPage method");
    	   try { 
    		   	   contactsFile1.createNewFile();
    		   	  
    		   	   PrintWriter out = new PrintWriter(contactsFile1);
    		   	   URL yahoo  = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/Backup_1%5Caddressbook.txt");
	               //URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/Backup_1%5Caddressbook.txt"); 
	               //URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/"+Login.licennceKey+"/Backup_1%5Caddressbook.txt"); 
	               BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream())); 
	              
	               System.out.println ("Before while");
	               while ((inputLine = in.readLine()) != null) 
               
	               { 
	           			out.println (inputLine);
	           			
	           			System.out.println ("***"+inputLine);
            	   
	               } 
	               	out.flush();
	       			out.close();
             
	               System.out.println ("####################"+contactsFile.length());
	               in.close(); 
           	}
    	   catch (MalformedURLException me)
    	   { 
               System.out.println(me); 
       
           }
    	   catch (IOException ioe)
    	   {  
               System.out.println(ioe); 
           }  

    	}
    
    public void sendDataToServer()
    {
    	/*yesButton = (Button)findViewById(R.id.widget31);
    	noButton = (Button)findViewById(R.id.widget32);
    	yesButton.setOnClickListener(this);
    	noButton.setOnClickListener(this);*/
    	done = false;
    	setContentView(R.layout.contactfromserver);
	 	test=1;
	 	myFile = new File(fileName);
	 
		 size = (int)myFile.length();
		 noOfChunks = (size/102400);
		 noOfChunks = noOfChunks+1;
		
		 System.out.println ("size of file is "+size);
		 System.out.println ("size is"+noOfChunks);
   		
   		 System.out.println ("User click yes button");
   		 Thread t = new Thread(){
			   public void run()
			   {
				   //firstHit();
				   //sendData(Login.licennceKey+"~A~addressbook.txt~"+size+"~START~"+noOfChunks);
			        
				  //readFile();
		         
				   //sendData(Login.licennceKey+"~A~addressbook.txt~"+size+"~END~"+noOfChunks);
				   
				  mHandler.post(new Runnable() {
			            public void run()
			            {
			            	setContentView(R.layout.contactrestoreonphone);
			            	alertbox("Your "+VCardIO.importcounter+" Contacts Successfully Restored On Phone");
			            	//VCardIO v=new VCardIO();
			            	//Toast.makeText(Restorecontacts.this, "No. Of Contacts Stored On Server::"+v., Toast.LENGTH_SHORT).show();
			            	notifyMe();
			            	contactsFile.delete();
			            	contactsFile1.delete();
			            	//fileName.delete();
			            }
			    	});
				 				   
			   }
			};

			t.start();
    	
    }
   
    private void notifyMe()
	{
		final NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
		Notification note=new Notification(R.drawable.red_ball,	"Status message!",System.currentTimeMillis());
		PendingIntent i=PendingIntent.getActivity(this, 0,new Intent(this, NotifyMessage.class),0);
		
		note.setLatestEventInfo(this, "Mobi Security",	"Your Contacts are stored successfully on server", i);
		note.number=++count;
		
		mgr.notify(NOTIFY_ME_ID, note);
	}
   	    
    public void onClick(View v)
    {
    	System.out.println ("Before setting screen");
    	
    	System.out.println ("after setting screen");
   
   	 	if (v==yesButton)
   	 	{  
   	 		/*setContentView(R.layout.smstoserver);
   	 		test=1;
   	 		myFile = new File(fileName);
		 
			 size = (int)myFile.length();
			 noOfChunks = (size/102400);
			 noOfChunks = noOfChunks+1;
			
			 System.out.println ("size of file is "+size);
			 System.out.println ("size is"+noOfChunks);
	   		
	   		 System.out.println ("User click yes button");
	   		 Thread t = new Thread(){
 			   public void run()
 			   {
 				   firstHit();
 				   sendData("0213456789_A~addressbook.txt~START~10");
 		        
 				   readFile();
 		         
 				   sendData("0213456789_A~addressbook.txt~END~10");
 				   
 				  mHandler.post(new Runnable() {
 			            public void run()
 			            {
 			            	setContentView(R.layout.contactstoreonserver);
 			            	notifyMe();
 			            }
 			    	});
 				 				   
 			   }
 			};

 			t.start(); */
	   		
   	 	}
   	 	else if (v==noButton)
   	 	{
   	 		System.out.println ("User click no button");
   	 		System.exit(0);
   	 	}
   	 
   	 
   	 	
    }
    
    /*public void firstHit()
    {
    	try
    	{    	
    		
    		URL connectURL = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/login.aspx?userID=0213456789"); 
    		
    		
    		// connectURL is a URL object
    		System.out.println ("After heating url from firstHit()");
    		
    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
    		// allow inputs 
    		conn.setDoInput(true); 
    		
    		// allow outputs 
    		conn.setDoOutput(true);
    		
    		// don't use a cached copy 
    		conn.setUseCaches(false); 
    		
    		// use a post method 
    		conn.setRequestMethod("POST");
    		
    		// set post headers 
    		conn.setRequestProperty("Connection","Keep-Alive"); 
    		  		
    		// open data output stream 
    		OutputStream dos ; 
    		
    		dos=conn.getOutputStream();
    		
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 
	    		
	    		b.append( (char)ch);
	    		
	    	} 
	    	String s=b.toString(); 
	    	System.out.println (s);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
    	} 
    	catch (MalformedURLException ex)
    	{ 
    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	} 
    }*/
    
    public void readFile()
    {  	
    	
    	 try
    	 {
    		 int chunkno=1;
    		 byte[] byteArray = new byte[102400];
    		 FileInputStream fstream = new FileInputStream(myFile); 
    		 int bytesRead = 0;
    		 while((bytesRead = fstream.read(byteArray)) != -1)
    		 {  
    			 
    			 str = new String(byteArray,0,bytesRead);  
    			 sendData(imei+"_A~addressbook.txt~"+chunkno+"~"+str);
    			 chunkno++;
    		 }

	                
         }
         catch (IOException ioe)
         {
        	 ioe.printStackTrace(); 
         }
    }
    
    public void sendData(String line)
    {
    	try
    	{
    		
    		URL connectURL = new URL("http://www.mobisecurity.net/phonebackup/DumpData.aspx");
    		
    		
    		// connectURL is a URL object
    		System.out.println ("After heating url");
    		
    		HttpURLConnection conn = (HttpURLConnection)connectURL.openConnection(); 
    		// allow inputs 
    		conn.setDoInput(true); 
    		
    		// allow outputs 
    		conn.setDoOutput(true); 
    		
    		// don't use a cached copy 
    		conn.setUseCaches(false); 
    		
    		// use a post method 
    		conn.setRequestMethod("POST"); 
    		
    		// set post headers 
    		conn.setRequestProperty("Connection","Keep-Alive"); 
    		   		
    		// open data output stream 
    		OutputStream dos ; 
    		
    		dos=conn.getOutputStream();
    		
    		System.out.println ("Before if statement");
    		
    			byte[] arr = line.getBytes();
    		
    			System.out.println ("arr auccesfully created"+arr.length);
    	      	    
    			dos.write(arr);
    	    
    			System.out.println ("write to the page");
    		    	   	   		
    		System.out.println ("After if statement");
	    	dos.flush(); 
	        	
	    	InputStream is = conn.getInputStream(); 
	    	int ch; 
	    	StringBuffer b =new StringBuffer(); 
	    	System.out.println ("Before second while loop");
	    	while(( ch = is.read() ) != -1 )
	    	{ 	    		
	    		b.append( (char)ch);
	    		   
	    	} 
	    	String s=b.toString(); 
	    	System.out.println (s);
	    	dos.close(); 
	    	System.out.println ("at the end of try block");
	    	
    	} 
    	catch (MalformedURLException ex)
    	{ 
    		// Log.e(Tag, "error: " + ex.getMessage(), ex); 
    	} 
    	catch (IOException ioe)
    	{ 
    		// Log.e(Tag, "error: " + ioe.getMessage(), ioe); 
    	}

    }
    
    protected  void alertbox( String mymessage)   
    {   
   	 new AlertDialog.Builder(this)   
       .setMessage(mymessage)   
        
       .setCancelable(true)   
       .setNeutralButton(android.R.string.ok,   
          new DialogInterface.OnClickListener() {   
          public void onClick(DialogInterface dialog, int whichButton){}   
          })   
       .show();   
    }
}
