package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Vector;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ParseException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ShowBuddyList extends ListActivity 
{
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	String recfullString,str1,recname,recno,recid;
	String arr[],arr1[],arrBuddy[];
	CustomAdapter adapter;
	File BuddyListFile=new File("data/data/com.micro.mobisecurity/buddylist");
	/*static final String[] title = new String[] {
	    "General Setting", "Lock Setting"};
	static final String[] detail = new String[] {
		"Manage Your General Setting. ","Manage Your Lock Setting."};
	private Integer[] imgid = {R.drawable.generalsetting,R.drawable.locksetting};*/
	File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		  AddBuddyClick.mPref = getSharedPreferences(AddBuddyClick.PREFS, 0);
		System.out.println("inside onCreate");
		setContentView(R.layout.main1);
		System.out.println("inside main1");
		mInflater = (LayoutInflater) getSystemService(
		Activity.LAYOUT_INFLATER_SERVICE);
		System.out.println("after mInflater");
		data = new Vector<RowData>();
		System.out.println("after data");
		/*for(int i=0;i<title.length;i++)
		{
			try {
			 	rd = new RowData(i,title[i]);
			    } 
			catch (ParseException e) 
			{
			    	e.printStackTrace();
			}
		   data.add(rd);
		}*/
		try
		 {
			System.out.println("inside read file buddylist");
			 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/buddylist");
			 System.out.println("after set path");
			 DataInputStream in = new DataInputStream(fstream);
			 System.out.println("after set in");
			 BufferedReader br = new BufferedReader(new InputStreamReader(in));
			 System.out.println("after set br");
			 String strLine;
			 System.out.println("after set strLine");
			 while ((strLine = br.readLine()) != null)
			 {
				 System.out.println ("@@@@ while STRLINE is "+strLine);
				 recfullString = strLine.toString();
				 System.out.println("after recfullString");
			 }
		     in.close();
		     System.out.println("after close");
		     arr = recfullString.split("\\?");
		     System.out.println("arr"+arr);		
		    
		     
		     for (int i=1;i<arr.length;i++)
		     {	
		    	 try {
		    	   System.out.println("arr"+arr);	
		    	 rd = new RowData(i,arr[i]);
		    	  System.out.println("rd"+rd);	
		    	 } 
					catch (ParseException e) 
					{
					    	e.printStackTrace();
					}
		    	 //SendMultiPartSms(arr[i],uname+ " has added you as recipient on Micro Secure. You will get alert message in case of his/her phone lost or stolen.For More Info Visit www.microsecure.net" );
		    	  data.add(rd);	
		     }
		     
		     System.out.println("before adaptor");
		    adapter = new CustomAdapter(this, R.layout.addbuddyfirstlist,R.id.title, data);
		     System.out.println("after adaptor");  
		     setListAdapter(adapter);
		     System.out.println("after  setListAdapter");  
			   getListView().setTextFilterEnabled(true);
			   System.out.println("after getListView()");  
		  }
		  catch (IOException ioe)
		  {
			  ioe.printStackTrace(); 
		  }
		   
	}
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		alertboxBuddyDelete("Mobi Security","Are you sure delete buddy!!!!!!!!!");
		// Get the item that was clicked 
		Object o = this.getListAdapter().getItem(position);
		/*Builder abd = new AlertDialog.Builder(ShowBuddyList.this);

        abd.setMessage("" + l.getItemAtPosition(position));

        abd.show();*/

		 str1 = o.toString();
		 System.out.println("all String::"+str1);
		// arr1 = str1.split("\\+");
			
	    /* for (int i=0;i<arr1.length;i++)
	     {
	    	 if(arr1[i]!=null)
	     	{
	    		 recid=arr1[i];
		    	 System.out.println("Rec Id::"+recid);
		    	 recname=arr1[i];
		    	 System.out.println("Rec Name::"+recname); 
	     	}
	     
	    	 
	    	 //recno=arr1[2];
	    	// System.out.println("Rec No::"+recno);
				
	     }*/
		  /* if (position == 0 )
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"General Setting.",  Toast.LENGTH_SHORT).show();
			   
			   Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, GeneralSetting.class.getName());
	   			startActivity(intent);
		   }
		   else if (position == 1)
		   {
			   Toast.makeText(getApplicationContext(), "You have selected "
	                    +"Lock Setting.",  Toast.LENGTH_SHORT).show();
			   
			   Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, LockSetting.class.getName());
	   			startActivity(intent);
			   Intent intent = new Intent(Intent.ACTION_VIEW);
	   			intent.setClassName(this, PreferenceExample.class.getName());
	   			startActivity(intent);
		   }*/
		 
	   }
	       private class RowData 
	       {
	       //protected int mId;
	       protected String mTitle;
	       //protected String mDetail;
	       RowData(int id,String title)
	       	   {
		       //mId=id;
		       mTitle = title;
		       //mDetail=detail;
		       }
	       
		       @Override
		       public String toString() 
		       {
		               return mTitle;
		       }
	       }
	       
	  private class CustomAdapter extends ArrayAdapter<RowData> 
	  {
		  public CustomAdapter(Context context, int resource,int textViewResourceId, List<RowData> objects) 
		  {               
			  super(context, resource, textViewResourceId, objects);
		  }
	       @Override
	       public View getView(int position, View convertView, ViewGroup parent) 
	       {   
	       ViewHolder holder = null;
	       TextView title = null;
	       //TextView detail = null;
	      // ImageView i11=null;
	       RowData rowData= getItem(position);
	       if(null == convertView)
	       {
	            convertView = mInflater.inflate(R.layout.addbuddyfirstlist, null);
	            holder = new ViewHolder(convertView);
	            convertView.setTag(holder);
	       }
	             holder = (ViewHolder) convertView.getTag();
	             title = holder.gettitle();
	             title.setText(rowData.mTitle);
	            // detail = holder.getdetail();
	             //detail.setText(rowData.mDetail);                                                     
	             //i11=holder.getImage();
	             //i11.setImageResource(imgid[rowData.mId]);
	             return convertView;
	       }
	            private class ViewHolder 
	            {
	            private View mRow;
	            private TextView title = null;
	            //private TextView detail = null;
	            //private ImageView i11=null; 
	            public ViewHolder(View row) 
	            {
	            mRow = row;
	            }
	         public TextView gettitle() 
	         {
	             if(null == title)
	             {
	                 title = (TextView) mRow.findViewById(R.id.title);
	             }
	            return title;
	         }     
	        /* public TextView getdetail() 
	         {
	             if(null == detail)
	             {
	                  detail = (TextView) mRow.findViewById(R.id.detail);
	             }
	           return detail;
	         }
	        public ImageView getImage() 
	        {
	             if(null == i11)
	             {
	                  i11 = (ImageView) mRow.findViewById(R.id.img);
	             }
	                return i11;
	        }*/
	     }
	   }
	  protected void alertboxPlzAddBuddy(String title, String mymessage)     
		{
		// Code here to display alert box
	       	// Create the alert box
	              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

	              // Set the message to display
	              alertbox.setMessage(mymessage);
	              //alertbox.setTitle(title);
	              // Add a neutral button to the alert box and assign a click listener
	              alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() 
	              {

	                  // Click listener on the neutral button of alert box
	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {
	                	// The neutral button was clicked
	                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	                	  //Wipe();
	                	  finish();
	                  }
	              }
	              
	              
	              
	              );
	              
	              // Set a negative/no button and create a listener

	              /*alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                  // Click listener

	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {

	                      Toast.makeText(getApplicationContext(), "'User Press No button.", Toast.LENGTH_SHORT).show();

	                  }

	              }*/
	              
	              //);
	               // show the alert box
	              alertbox.show();  
		}	 
	  protected void alertboxBuddyDelete(String title, String mymessage)     
	  {
	  // Code here to display alert box
	     	// Create the alert box
	            AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
	            //alertbox.setTitle(mymessage);
	            // Set the message to display
	            alertbox.setMessage(mymessage);

	            // Add a neutral button to the alert box and assign a click listener
	            alertbox.setNeutralButton("Yes", new DialogInterface.OnClickListener() 
	            {

	                // Click listener on the neutral button of alert box
	                public void onClick(DialogInterface arg0, int arg1) 
	                {
	              	// The neutral button was clicked
	                    //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	              	 // Lock();
	              	  //moveTaskToBack(true);
	                	AddBuddyClick.cnt = AddBuddyClick.mPref.getInt("numRun",0);
	            		//AddBuddyClick.cnt++;
	                	System.out.println("before minus buddy"+AddBuddyClick.cnt);
	                	
	                	if(AddBuddyClick.cnt>1)
	                	{
	                		System.out.println("counter::"+AddBuddyClick.cnt);
	                		AddBuddyClick.cnt--;
	                		System.out.println("counter::"+AddBuddyClick.cnt);
	                		AddBuddyClick.mPref.edit().putInt("numRun",AddBuddyClick.cnt).commit();
		                	System.out.println("minus buddy"+AddBuddyClick.cnt);
	                	 adapter.remove(adapter.getItem(adapter.getCount() - 1));
	                	 String[] buddy =new String[adapter.getCount()];
	                	 BuddyListFile.delete();
	                	 BuddyFile.delete();
	                	 for(int i=0;i<adapter.getCount();i++)
	                	 {
	                		 buddy[i]= adapter.getItem(i).toString();
	                		 System.out.println("new buddy List---"+buddy[i]);
	                		 
	                		 
	                		 try
	         		    	{
	                			
	         		    		//cnt++;
	         		    		//ad.RegisterButton.setEnabled(true);
	         		    		BuddyListFile.createNewFile();
	         		    	
	         				  FileWriter out1 = new FileWriter(BuddyListFile,true);
	         				 out1.write("?"+buddy[i]);  
	         				 System.out.println ("?"+buddy[i]);
	         				 out1.flush();
	         				 out1.close();
	         				 //System.out.println ("Name is?"+name);
	         				 //System.out.println ("Number is?"+recno);
	         		    	}
	         		    	 catch (IOException ioe)
	         		    	 {
	         		    		 ioe.printStackTrace();
	         		    	 }
	         		    	arrBuddy = buddy[i].split("\\+");
	         			     System.out.println("arr after split after +::"+arrBuddy);		
	         			    
	         			     
	         			     for (int i1=0;i1<arrBuddy.length;i1++)
	         			     {	
	         			    	try
	         			    	{
	         			    		//cnt++;
	         			    		//ad.RegisterButton.setEnabled(true);
	         			    		BuddyFile.createNewFile();
	         			    	
	         					  FileWriter out1 = new FileWriter(BuddyFile,true);
	         					 out1.write(";+"+arrBuddy[i1]+";");  
	         					 System.out.println (";+"+arrBuddy[i1]);
	         					 out1.flush();
	         					 out1.close();
	         					 //System.out.println ("Name is?"+name);
	         					 System.out.println ("Number is?"+arrBuddy[i1]);
	         			    	}
	         			    	 catch (IOException ioe)
	         			    	 {
	         			    		 ioe.printStackTrace();
	         			    	 }  
	         			     }
	                	 }
	                	// System.out.println("adaptor data::"+adapter);
	                }
	                	else
		                {
	                		alertboxPlzAddBuddy("Mobi Security","A Minimum of one buddy is required to use Mobi Security .Please add another buddy first if you wish to delete this one.");
		                	System.out.println("Minimum one buddy is requred to use m2m");
		                }
	                }
	                
	            }
	            
	            
	            
	            );
	            
	            // Set a negative/no button and create a listener

	            alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                // Click listener

	                public void onClick(DialogInterface arg0, int arg1) 
	                {

	                    finish();
	                }

	            }
	            
	            );
	             // show the alert box
	            alertbox.show();  
	  }	
}