package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import com.micro.mobisecurity.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TextView;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.Window;
 
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
 
public class MusicRestore extends Activity  {
    /** Called when the activity is first created. */
 
    //initialize a button and a counter
    Button btn,firstBackup;
    String inputLine1,wholemusic;
    String str1,str2,str3,imei;
    int counter = 0,p=0;  
    String[] strArr;
    static Vector vct1;
    String folderName,bkuFolder,type,fileName,newFileName;          
    String strLine,str;
	File music = new File("data/data/com.micro.mobisecurity/music.mp3");
    File musicFile = new File("data/data/com.micro.mobisecurity/musicFile.txt");
    int a,size,total;
    FileOutputStream out1;
    @SuppressWarnings({ "rawtypes", "unused" })
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
    	System.out.println ("Inside oncreate");
        super.onCreate(savedInstanceState);
     // Request the progress bar to be shown in the title
	       requestWindowFeature(Window.FEATURE_PROGRESS);
	       setProgress(10000); // Turn it off for now
        calCulateIMEI();
        // setup the layout
        setContentView(R.layout.restoreimage);
        System.out.println ("****Counter is "+counter);
        Vector test = countBackup();
      
        //new MyList(test);
        System.out.println ("after countBackup");
		Intent MusicListIntent = new Intent(this,MusicList.class);
		startActivity(MusicListIntent);
       
 
    }
    
    private void calCulateIMEI() {
		// TODO Auto-generated method stub
   	TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
	} 

	public void onSaveInstanceState(Bundle savedInstanceState)
    {
    	super.onSaveInstanceState(savedInstanceState);
    }
    
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
    	  super.onRestoreInstanceState(savedInstanceState);
    }
    
   
    
 
  
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector countBackup()
    {
    	//int p = 0;
    	vct1=new Vector();
    	try
    	{
    	 	System.out.println ("Inside countBackup");
    		    	
    	  	URL yahoo = new URL("http://www.mobisecurity.net/phonebackup/users/"+imei+"/masterlist.txt");
    	   	//URL yahoo = new URL("http://www.microfms.net/mobilefms/tempphonebackup/phonebackup/users/0213456789/masterlist.txt"); 
            BufferedReader in = new BufferedReader(new InputStreamReader(yahoo.openStream()));
            
            System.out.println ("Before while");
            
            while((inputLine1 = in.readLine()) != null) 
        
            {   
            	if(inputLine1.endsWith(".mp3"))
            	{
            	str1=inputLine1.trim();
            	vct1.addElement(str1);
            	System.out.println("string array--->"+p+" is "+str1);
            	str1="";
            	p++;
            	}
            	
            } 
           
            	//out.flush();
    			//out.close();
            System.out.println("vector size-->"+vct1.size());
            
           System.out.println ("At the end of try");
           
         
          
    	}
    	catch (Exception e)
    	{
    		e.printStackTrace();
    	}
    	  return vct1;
    }
    
    protected void alertbox(String title, String mymessage)   
    {   
   	 new AlertDialog.Builder(this)   
       .setMessage(mymessage)   
       //.setTitle(title)   
       .setCancelable(true)   
       .setNeutralButton(android.R.string.cancel,   
          new DialogInterface.OnClickListener() {   
          public void onClick(DialogInterface dialog, int whichButton){}   
          })   
       .show();   
    }
}