package com.micro.mobisecurity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Vector;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.micro.mobisecurity.Contact.RowData;

public class AddBuddiesPinRegTime extends Activity implements OnClickListener{
	
	ImageButton RegAddBuddiesButton,RegisterButton,passcodeButton;
	//public static EditText RegPin,RegConfirmPin;
	String regnmStr;
	private Drawable error_indicator;
	EditText RegName;
	private LayoutInflater mInflater;
	private Vector<RowData> data;
	RowData rd;
	String ConfrmNewPINText ,recfullString;
	String recno,FullString,mobnumber,ReadFilePin,recMessageFormat;
	//static final int DIALOG_Rec = 1;
	static final int DIALOG_ChangePIN = 1;
	private Dialog editorDialog = null;
	 File ToggleBatteryOnOff=new File("data/data/com.micro.mobisecurity/BattInfo");
	File BuddyFile=new File("data/data/com.micro.mobisecurity/arpfile");
	File PinFile=new File("data/data/com.micro.mobisecurity/PIN");
	File unPinFile=new File("data/data/com.micro.android.unlock/PIN");
	File sdpinFile=new File("/sdcard/PIN");
	File SettingFileNameField=new File("data/data/com.micro.mobisecurity/NameField");
	File ToggleSirenOnSIMchng=new File("data/data/com.micro.mobisecurity/SirenToggle");
	File ToggleAutoLockOnSIMchng=new File("data/data/com.micro.mobisecurity/LockToggle");
	    public void onCreate(Bundle savedInstanceState)
	    
	    
	    {	
	    	super.onCreate(savedInstanceState);
	    	
		       
	    	pinAdd();
	    	// RegName.setEnabled(false);
		    RegisterButton.setEnabled(false);
		    //RegPin.setEnabled(false);
		    //RegConfirmPin.setEnabled(false);
	    }
	    private void pinAdd() {
			// TODO Auto-generated method stub
	    	setContentView(R.layout.addbuddiespin);
	    	 // Setting custom drawable instead of red error indicator,
	    	 error_indicator = getResources().getDrawable(R.drawable.emo_im_yelling);

		        int left = 0;
		        int top = 0;

		        int right = error_indicator.getIntrinsicHeight();
		        int bottom = error_indicator.getIntrinsicWidth();

		        error_indicator.setBounds(new Rect(left, top, right, bottom));
	        System.out.println("inside retrieveFormField");
	    
	 
	        RegName= (EditText)this.findViewById(R.id.name);
	        // Called when user type in EditText
		    RegName.addTextChangedListener(new InputValidator(RegName));
	       // mPassword.addTextChangedListener(new InputValidator(mPassword));

	        // Called when an action is performed on the EditText
		    RegName.setOnEditorActionListener(new EmptyTextListener(RegName));
	        //mPassword.setOnEditorActionListener(new EmptyTextListener(mPassword));
	        //RegPin = (EditText)this.findViewById(R.id.pin);
	        //RegConfirmPin= (EditText)this.findViewById(R.id.confirmpin);
	        passcodeButton=(ImageButton)this.findViewById(R.id.ChangePinButton);
		    RegAddBuddiesButton = (ImageButton)this.findViewById(R.id.AddBuddiesButton);
		    RegisterButton = (ImageButton)this.findViewById(R.id.SubmitButton);
		    
		    passcodeButton.setOnClickListener(this);
		    RegAddBuddiesButton.setOnClickListener(this);
		    RegisterButton.setOnClickListener(this);
		   
		}
		public void onClick(View v)
	    {
	    	if(v==RegAddBuddiesButton)
	    	{
	    		regnmStr=RegName.getText().toString();
	    		//RegName.setEnabled(true);
	    		try
	    		{
	    		FileWrite(SettingFileNameField,regnmStr);
	    		}
	    		catch(Exception e)
	    		{
	    			System.out.println("file write exception"+e);
	    		}
	  		    //RegPin.setEnabled(true);
	  		    //RegConfirmPin.setEnabled(true);
	    		RegisterButton.setEnabled(true);
	    		 Intent intent = new Intent(Intent.ACTION_VIEW);
		   			intent.setClassName(this, AddBuddyClick.class.getName());
		   			startActivity(intent);
	    		/*Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setClassName(this, AddEditBuddies.class.getName());
				startActivity(intent);*/
	    	}
	    	else if(v==RegisterButton)
	    	{
	    		
	    		/*RegisterButton.setEnabled(true);
	  		    RegPin.setEnabled(true);
	  		    RegConfirmPin.setEnabled(true);*/
	    		regnmStr=RegName.getText().toString();
	  		    //regpinStr=RegPin.getText().toString();
	  		    //regconfirmpinStr=RegConfirmPin.getText().toString();
	  		  if(regnmStr.length()<4 || regnmStr.length()>16 )
	  		    {
	  		    	alertbox("Mobi Security","Please enter valid name");
	  		    }
	  		    if(!BuddyFile.exists())
	    		{
	  			 alertboxPlzAddBuddy("Mobi Security","A Minimum of one buddy is required to use Mobi Security please add buddy");
	    		}
	  		    else
	  		    {
	  		    	
		    		 try
	   	        	{
		    			 readPinFile();
		    			 ReadScoutRecFile();
		    			 /*if(AddBuddyClick.firsttimerecselect>=1)
		    			 {
		    			 //System.out.println("Server Rec:L:"+AddBuddyClick.serverRec+);
		    				 System.out.println("manual add buddy");
		    			 recMessageFormat=ReadFilePin+";"+AddBuddyClick.serverRec;
		    			 }
		    			 else
		    			 {
		    				 System.out.println("automatic add buddy");
				    		recMessageFormat=ReadFilePin+";"+ContactListDemo.serverRec;
		    			 }*/
	   	        	//SendMultiPartSms("+919223187878","M2MRecp;"+ReadFilePin+recfullString+";");
		    		//TODO: Registration successful
	   	        	}
	   	        	catch(Exception e)
	   	        	{
	   	        		System.out.println(e);
	   	        	}
	  		    	try
	  		    	{
	  		    	writeToggleSirenOffSIMchngFile();
	  		    	writeToggleAutoLockOffSIMchngFile();
	  		    	writeBatteryAlertOffFile();
	  		    	//FileWrite(PinFile,regpinStr);
	  		    	//FileWrite(SettingFileNameField,regnmStr);
	  		    	alertboxcallListActivity("Mobi Security","Congratulations! Now your mobile is secure with Mobi Security.Please go to Settings to configure the features as per your requirement.");
	  		    	}
	  		    	catch(Exception e)
	  		    	{
	  		    		System.out.println(e);
	  		    	}
	  		    }
	    	}
	    	else if(v==passcodeButton)
	    	{
	    		showDialog(DIALOG_ChangePIN);
	    	}
	    
	    }
		public void ReadScoutRecFile()
		{
			
			try
			 {
				    
				 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/arpfile");
				 DataInputStream in = new DataInputStream(fstream);
				 BufferedReader br = new BufferedReader(new InputStreamReader(in));
				 String strLine;
				 while ((strLine = br.readLine()) != null)
				 {
					 System.out.println ("@@@@ while STRLINE is "+strLine);
					 recfullString = strLine.toString();
				 }
			     in.close();
			     
			   
			     
			  }
			  catch (IOException ioe)
			  {
				  ioe.printStackTrace(); 
			  }
		}
		
		public  void FileWrite(File aPath,String aBody)
		{
			try 
	    	{
				 System.out.println("@@@@ Inside Try FileWrite @@@@");
				 
				 aPath.createNewFile();
				 PrintWriter out1 = new PrintWriter(aPath);
				 out1.write(aBody);  
				 System.out.println (aBody.trim());
				 out1.flush();
				 out1.close();
	    	}
	    	catch (IOException ioe)
			 {
	    		 System.out.println("@@@@ Inside Catch FileWrite @@@@"); 
	    		ioe.printStackTrace();
			 }
			
		}
		public void writeToggleSirenOffSIMchngFile()
		 {
		
			 try {
				 ToggleSirenOnSIMchng.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 PrintWriter out1 = null;
				try {
					out1 = new PrintWriter(ToggleSirenOnSIMchng);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out1.write("SirenOff");  
				
				 out1.flush();
				 out1.close();
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
				
		 }
		
		public void writeToggleAutoLockOffSIMchngFile()
		 {
		
			try {
				ToggleAutoLockOnSIMchng.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 PrintWriter out1 = null;
				try {
					out1 = new PrintWriter(ToggleAutoLockOnSIMchng);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out1.write("LockOff");  
				
				 out1.flush();
				 out1.close();
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 4");
				 
		 }  
	    protected void alertbox(String title, String mymessage)     
		{
	    	new AlertDialog.Builder(this)   
			.setMessage(mymessage)   
			//.setTitle(title)   
			.setCancelable(true)   
			.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
			
			{   
			public void onClick(DialogInterface dialog, int whichButton)
				{
				
				}   
			}
			)   
			.show();   
		}
	    protected void EnterPassWrongalertbox(String title, String mymessage)     
		{
	    	new AlertDialog.Builder(this)   
			.setMessage(mymessage)   
			//.setTitle(title)   
			.setCancelable(true)   
			.setNeutralButton(android.R.string.ok,new DialogInterface.OnClickListener() 
			
			{   
			public void onClick(DialogInterface dialog, int whichButton)
				{
				showDialog(DIALOG_ChangePIN);
				}   
			}
			)   
			.show();   
		}
	   
	    protected void alertboxcallListActivity(String title, String mymessage)     
		{
		// Code here to display alert box
	       	// Create the alert box
	              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

	              // Set the message to display
	              alertbox.setMessage(mymessage);
	              //alertbox.setTitle(title);
	              // Add a neutral button to the alert box and assign a click listener
	              alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() 
	              {

	                  // Click listener on the neutral button of alert box
	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {
	                	// The neutral button was clicked
	                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	                	  //Wipe();
	                	finish();
	                	 //System.exit(0);
	                	  callListActivity();
	                  }
	              }
	              
	              
	              
	              );
	              
	              // Set a negative/no button and create a listener

	              /*alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                  // Click listener

	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {

	                      Toast.makeText(getApplicationContext(), "'User Press No button.", Toast.LENGTH_SHORT).show();

	                  }

	              }*/
	              
	              //);
	               // show the alert box
	              alertbox.show();  
		}	 
	    protected void alertboxPlzAddBuddy(String title, String mymessage)     
		{
		// Code here to display alert box
	       	// Create the alert box
	              AlertDialog.Builder alertbox = new AlertDialog.Builder(this);

	              // Set the message to display
	              alertbox.setMessage(mymessage);
	              //alertbox.setTitle(title);
	              // Add a neutral button to the alert box and assign a click listener
	              alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() 
	              {

	                  // Click listener on the neutral button of alert box
	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {
	                	// The neutral button was clicked
	                      //Toast.makeText(getApplicationContext(), "'Yes' button clicked", Toast.LENGTH_LONG).show();
	                	  //Wipe();
	                	  CallLayout();
	                  }
	              }
	              
	              
	              
	              );
	              
	              // Set a negative/no button and create a listener

	              /*alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() {

	                  // Click listener

	                  public void onClick(DialogInterface arg0, int arg1) 
	                  {

	                      Toast.makeText(getApplicationContext(), "'User Press No button.", Toast.LENGTH_SHORT).show();

	                  }

	              }*/
	              
	              //);
	               // show the alert box
	              alertbox.show();  
		}	 
	
	    private void CallLayout() {
			// TODO Auto-generated method stub
	    	Intent intent1 = new Intent(Intent.ACTION_VIEW);
			intent1.setClassName(this, AddBuddiesPinRegTime.class.getName());
			startActivity(intent1);
		}

	    private void callListActivity() {
			// TODO Auto-generated method stub
	    	
	    	Intent intent1 = new Intent(Intent.ACTION_VIEW);
			intent1.setClassName(this, listActivity.class.getName());
			startActivity(intent1);
		}  
	    @Override
	    protected Dialog onCreateDialog(int id)
	    {
	        Dialog editor = editorDialog;
	        
	       
	        
	        if (editorDialog == null)
	        {
	        	 switch(id)
	        	 {
	        	 
	        	 /*case DIALOG_Rec:
	        	 editor = createEditorDialogForRec();*/
	        	 //ChangeEmail();
	             //break;
	        	 case DIALOG_ChangePIN:
		 		        editor = createEditorDialogForPinChange();
		 		       break;

	        	 }
	            
	        }
	        return editor;
	    }
	    public void writeBatteryAlertOffFile()
		 {
		
			 try {
				 ToggleBatteryOnOff.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 PrintWriter out1 = null;
				try {
					out1 = new PrintWriter(ToggleBatteryOnOff);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 out1.write("BatteryOff");  
				
				 out1.flush();
				 out1.close();
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
				 System.out.println("$$$$$$$$$$$$$$$$$$$file write 2");
		 }
	    private Dialog createEditorDialogForPinChange()
	    {
	        AlertDialog.Builder builder = new AlertDialog.Builder(this);
	        builder.setTitle(R.string.addDialogTitlePIN);

	        View content = getLayoutInflater().inflate(R.layout.changepin,
	        (ViewGroup) findViewById(R.id.editLayout));
	        builder.setView(content);
	        
	        
	        builder.setPositiveButton(R.string.OkButton,
	            new DialogInterface.OnClickListener()
	            {
	        		
	                public void onClick(DialogInterface dialog, int which)
	                {
	                    
	                	
	                	Dialog source = (Dialog) dialog;
	                	
	                    EditText CurrentPIN = (EditText) source
	                        .findViewById(R.id.CurrentPINText);
	                   
	                    readPinFile();
	                    String CurrentPINText = CurrentPIN.getText().toString();
	                    
	                    EditText NewPIN = (EditText) source
	                    .findViewById(R.id.NewPINText);
	                
	                    String NewPINText = NewPIN.getText().toString();
	                    
	                    EditText ConfrmNewPIN = (EditText) source
	                    .findViewById(R.id.RetypeNewPINText);
	                
	                    ConfrmNewPINText = ConfrmNewPIN.getText().toString();
	                  
	                    if(CurrentPINText.equals("") || NewPINText.equals("") || ConfrmNewPINText.equals(""))
	                    {
	                    	EnterPassWrongalertbox("Mobi Security","Please enter all details.");
	                    }
	                 else if(CurrentPINText.equals(""))
	                 {
	                	 EnterPassWrongalertbox("Mobi Security","Please enter current password.");
	                 }
	                 else if(NewPINText.equals(""))
	                 {
	                	 EnterPassWrongalertbox("Mobi Security","Please enter new password.");
	                 }
	                 else if(ConfrmNewPINText.equals(""))
	                 {
	                	 EnterPassWrongalertbox("Mobi Security","Please enter confirm new password.");
	                 }
	                 else if(!CurrentPINText.equals(ReadFilePin))
	                       {
	                	 EnterPassWrongalertbox("Mobi Security","Please enter correct old password.");
	                       }
	                       else if(!NewPINText.equals(ConfrmNewPINText))
	                       {
	                    	   EnterPassWrongalertbox("Mobi Security","Please enter same new password & confirm password.");
	                       }
	                    else
	                    {
	                    	try
	                    	{
	                    	  FileWrite(PinFile,ConfrmNewPINText);
	                    	}
	                    	catch(Exception e)
	                    	{
	                    		System.out.println("file writing probvlem"+e);
	                    	}
	                    	try
	                    	{
	                    	  FileWrite(unPinFile,ConfrmNewPINText);
	                    	}
	                    	catch(Exception e)
	                    	{
	                    		System.out.println("file writing probvlem"+e);
	                    	}
	                    	try
	                    	{
	                    	  FileWrite(sdpinFile,ConfrmNewPINText);
	                    	}
	                    	catch(Exception e)
	                    	{
	                    		System.out.println("file writing probvlem"+e);
	                    	}
	                    	  alertbox("Mobi Security","Password updated successfully.");
	                    }
	                  
	                    dialog.dismiss();
	                }

	    			
	            });

	        builder.setNegativeButton(R.string.CancelButton,
	            new DialogInterface.OnClickListener()
	            {

	                public void onClick(DialogInterface dialog, int which)
	                {
	                    dialog.dismiss();
	                	
	                	
	                }
	            });

	        return builder.create();
	    }
	    @Override
	    protected void onPrepareDialog(int id, Dialog dialog)
	    {
	    	switch (id)
	    	{
	    		case DIALOG_ChangePIN:
	    		{
	    			readPinFile();
	    			//dialog.setTitle("Custom dialog 1");
	    			EditText CurrentPIN = (EditText)dialog
	                .findViewById(R.id.CurrentPINText);
	    			/*EditText cdField1Edit = (EditText)dialog.findViewById(R.id.cdField1Edit);
	    			EditText cdField2Edit = (EditText)dialog.findViewById(R.id.cdField2Edit);*/

	    			// Set the default values for Field 1 and 2
	    			//cdField1Edit.setText("");
	    			CurrentPIN.setText(ReadFilePin != null ? ReadFilePin : "");
	    		}
	    		break;
	    	}
	    }
	  //read password
	    public void readPinFile()
	    {
	     
	    	try
	    	 {
	    		 System.out.println ("INSIDE THE READRECFILE");
	    		 FileInputStream fstream = new FileInputStream("data/data/com.micro.mobisecurity/PIN");
	    		 System.out.println ("INSIDE THE READRECFILE2");	
	    		 DataInputStream in = new DataInputStream(fstream);
	    		 System.out.println ("INSIDE THE READRECFILE3");	
	    		 BufferedReader br = new BufferedReader(new InputStreamReader(in));
	    		 String strLine;
	    		 System.out.println ("INSIDE THE READRECFILE4");	
	    		 while ((strLine = br.readLine()) != null)
	    		 {
	    			 System.out.println (strLine);
	    			 ReadFilePin = strLine.toString();
	    		 }
	    	     in.close();
	    	     System.out.println ("Full String is:- " +ReadFilePin);
	    	    
	    	    
	    	     
	    	  }
	    	  catch (IOException ioe)
	    	  {
	    		  ioe.printStackTrace(); 
	    	  }
	    

	    	  
	    }
	    //edit text validator
	    private class InputValidator implements TextWatcher {
	        private EditText et;

	        private InputValidator(EditText editText) {
	            this.et = editText;
	        }

	        @Override
	        public void afterTextChanged(Editable s) {

	        }

	        @Override
	        public void beforeTextChanged(CharSequence s, int start, int count,
	                int after) {

	        }

	        @Override
	        public void onTextChanged(CharSequence s, int start, int before,
	                int count) {
	            if (s.length() != 0) {
	                switch (et.getId()) {
	                case R.id.name: {
	                    if (!Pattern.matches("^[ a-z A-Z ]{1,16}$", s) ) {
	                        et.setError("Oops! Username must have only a-z and A-Z");
	                    }
	                }
	                    break;

	              
	                }
	            }
	        }
	    }
	    //name edit text listener
	    private class EmptyTextListener implements OnEditorActionListener {
	        private EditText et;

	        public EmptyTextListener(EditText editText) {
	            this.et = editText;
	        }

	        @Override
	        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

	            if (actionId == EditorInfo.IME_ACTION_NEXT) {
	                // Called when user press Next button on the soft keyboard
                      System.out.println(et.getText().toString());
	                if (et.getText().toString().equals("") || et.getText().toString().equals("Your Name"))
	                    et.setError("Oops! empty.", error_indicator);
	            }
	            return false;
	        }
	    }
	    //sms send function
	    public void SendMultiPartSms(String add,String msgbdy)
		{
			
	    	SmsManager smsManager = SmsManager.getDefault();
	    	
	        String destAddr = add, scAddr = null, mMessageText =msgbdy;
	        
	        System.out.println ("******** Destination Address is "+destAddr+" sms is " + mMessageText);
	        
	        PendingIntent sentIntent = null, deliveryIntent = null;
	        
	        try 
	        {
	        	
	        	ArrayList<PendingIntent> listOfIntents = new ArrayList<PendingIntent>(0);
	        	
	        	
	        	//PendingIntent il = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
	        	ArrayList<String> messages = smsManager.divideMessage(mMessageText);

	        
	        	

	        for (int i=0; i < messages.size(); i++)
	        {

	        	
	        	PendingIntent pi = PendingIntent.getBroadcast(this, 0, new Intent(), 0);
		        listOfIntents.add(pi);
	        }
	        System.out.println ("******** inside TRY FOR SendMultiPartSms10");
	        smsManager.sendMultipartTextMessage(destAddr, null, messages, listOfIntents, null);

	        } catch (Exception e) 
	        {
	        Log.i("TEST", e.toString());
	        }
	    
		}	
}
