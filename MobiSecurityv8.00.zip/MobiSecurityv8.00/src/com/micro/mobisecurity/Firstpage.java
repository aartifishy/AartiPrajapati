package com.micro.mobisecurity;




import com.micro.mobisecurity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;

public class Firstpage extends Activity 
{
	 protected boolean _active = true;
	    protected int _splashTime = 3000;
    /** Called when the activity is first created. */
    @SuppressWarnings("unused")
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
    	System.out.println ("Inside onCreate");
        super.onCreate(savedInstanceState);
        //window set full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.splash);
        int ht;
        int wt;
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        ht = displaymetrics.heightPixels;
        wt = displaymetrics.widthPixels;
               
    
    
    // thread for displaying the SplashScreen
    Thread splashTread = new Thread() {
        @Override
        public void run() {
            try {
                int waited = 0;
                while(_active && (waited < _splashTime)) {
                    sleep(100);
                    if(_active) {
                        waited += 100;
                    }
                }
            } catch(InterruptedException e) {
                // do nothing
            } finally {
                finish();
                System.out.println("+++++++++++++++++++++Hello");
                //startActivity(new Intent("com.micro.ers.Spleshscreen.MicroERS"));
                
               // startActivity(new Intent(".MicroERS"));
                splashStart();
                /*Intent firstIntent = new Intent(this,Firstpage.class);
    			startActivity(firstIntent);*/
               // stop();
            }
        }
    };
    splashTread.start();
}
    @Override
    public void onBackPressed() {

       return;
    }

//screen touch event
@Override
public boolean onTouchEvent(MotionEvent event) {
    if (event.getAction() == MotionEvent.ACTION_DOWN) {
        _active = false;
    }
    return true;
}
//after splash strat acivity
public void splashStart()
{
	
	Intent intent = new Intent(Intent.ACTION_VIEW);
    intent.setClassName(this, MicroScout.class.getName());
    startActivity(intent);
}
   
	
}