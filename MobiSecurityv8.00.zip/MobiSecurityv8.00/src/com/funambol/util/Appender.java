package com.funambol.util;

import com.funambol.storage.DataAccessException;

public interface Appender {
    
    /**
     * Initialize Log File
     */
    void initLogFile();
    
    /**
     * Open Log file
     */
    void openLogFile();
    
    /**
     * Close Log file
     */
    void closeLogFile();
    
    /**
     * Delete Log file
     */
    void deleteLogFile();
    
    /**
     * Append a message to the Log file
     */
    void writeLogMessage(String level, String msg) throws DataAccessException;
}
