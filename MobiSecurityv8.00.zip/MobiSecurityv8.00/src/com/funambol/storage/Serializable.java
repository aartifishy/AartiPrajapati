package com.funambol.storage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * A simple interface to serialize objects on j2ME platform
 */
public interface Serializable {

    /**
     * Write object fields to the output stream.
     * @param out Output stream
     * @throws IOException
     */
    void serialize(DataOutputStream out) throws IOException;

    /**
     * Read object field from the input stream.
     * @param in Input stream
     * @throws IOException
     */
    void deserialize(DataInputStream in) throws IOException;
}

