package com.funambol.storage; 
  
 /** 
  * Represents a <i>"update"</i> error on device database. 
  */ 
 public class DataAccessException extends Exception { 
  
     /** 
          *  
          */ 
         private static final long serialVersionUID = -6695128856314376170L; 
  
  
         /** 
      * Creates a new instance of <code>DataAccessException</code> 
      * without detail message. 
      */ 
     public DataAccessException() { 
     } 
  
  
     /** 
      * Constructs an instance of <p><code>DataAccessException</code></p> 
      * with the specified detail message. 
      * @param msg the detail message. 
      */ 
     public DataAccessException(String msg) { 
         super(msg); 
     } 
 } 
 